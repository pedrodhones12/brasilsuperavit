import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Bell,
  Rocket,
  TrendingUp,
  Heart,
  MessageCircle,
  Award,
  DollarSign,
  Users,
  CheckCircle,
  Trash2,
  Settings,
  Filter,
  Calendar,
  Sparkles
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useNavigate } from "react-router-dom";
import NotificationPreferences from "../components/notifications/NotificationPreferences";

const iconMap = {
  new_project: Rocket,
  funding_milestone: TrendingUp,
  project_deadline: Calendar,
  project_update: Bell,
  comment: MessageCircle,
  like: Heart,
  investment_received: DollarSign,
  follow: Users,
  achievement: Award,
  investment_recommendation: Sparkles
};

const colorMap = {
  new_project: "from-blue-500 to-blue-600",
  funding_milestone: "from-emerald-500 to-emerald-600",
  project_deadline: "from-orange-500 to-red-600",
  project_update: "from-purple-500 to-purple-600",
  comment: "from-indigo-500 to-indigo-600",
  like: "from-red-500 to-pink-600",
  investment_received: "from-yellow-500 to-yellow-600",
  follow: "from-cyan-500 to-cyan-600",
  achievement: "from-orange-500 to-orange-600",
  investment_recommendation: "from-purple-500 to-pink-600"
};

const typeLabels = {
  new_project: "Novo Projeto",
  funding_milestone: "Marco de Financiamento",
  project_deadline: "Prazo Próximo",
  project_update: "Atualização de Projeto",
  comment: "Comentário",
  like: "Curtida",
  investment_received: "Investimento Recebido",
  follow: "Novo Seguidor",
  achievement: "Conquista",
  investment_recommendation: "Recomendação IA"
};

export default function Notifications() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState("all");
  const [activeSection, setActiveSection] = useState("notifications"); // notifications or settings

  React.useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ['all-notifications', user?.email],
    queryFn: () => base44.entities.Notification.filter(
      { user_email: user?.email },
      '-created_date',
      100
    ),
    enabled: !!user?.email,
  });

  const { data: followedProjects = [] } = useQuery({
    queryKey: ['followed-projects', user?.email],
    queryFn: () => base44.entities.ProjectFollow.filter(
      { user_email: user?.email }
    ),
    enabled: !!user?.email,
  });

  const markAsReadMutation = useMutation({
    mutationFn: (notificationId) => 
      base44.entities.Notification.update(notificationId, { is_read: true }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-notifications'] });
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      const unreadNotifications = notifications.filter(n => !n.is_read);
      await Promise.all(
        unreadNotifications.map(n => 
          base44.entities.Notification.update(n.id, { is_read: true })
        )
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-notifications'] });
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  const deleteNotificationMutation = useMutation({
    mutationFn: (notificationId) => 
      base44.entities.Notification.delete(notificationId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-notifications'] });
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  const handleNotificationClick = (notification) => {
    if (!notification.is_read) {
      markAsReadMutation.mutate(notification.id);
    }
    if (notification.link) {
      navigate(notification.link);
    }
  };

  const filteredNotifications = notifications.filter(n => {
    if (activeTab === 'all') return true;
    if (activeTab === 'unread') return !n.is_read;
    if (activeTab === 'important') return ['funding_milestone', 'project_deadline', 'investment_recommendation'].includes(n.type);
    return n.type === activeTab;
  });

  const unreadCount = notifications.filter(n => !n.is_read).length;
  const importantCount = notifications.filter(n => 
    ['funding_milestone', 'project_deadline', 'investment_recommendation'].includes(n.type) && !n.is_read
  ).length;

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-blue-50/30 via-purple-50/30 to-emerald-50/30">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500 via-purple-500 to-emerald-500 shadow-xl">
              <Bell className="w-10 h-10 text-white" />
            </div>
            <div>
              <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-emerald-600 bg-clip-text text-transparent">
                Central de Notificações
              </h1>
              <p className="text-xl text-gray-600 mt-1">
                Mantenha-se atualizado sobre seus investimentos
              </p>
            </div>
          </div>
        </motion.div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="border-none shadow-xl bg-gradient-to-br from-blue-50 to-white">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-blue-100">
                  <Bell className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Não Lidas</p>
                  <p className="text-3xl font-bold text-gray-900">{unreadCount}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-xl bg-gradient-to-br from-orange-50 to-white">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-orange-100">
                  <TrendingUp className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Importantes</p>
                  <p className="text-3xl font-bold text-gray-900">{importantCount}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-xl bg-gradient-to-br from-emerald-50 to-white">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-emerald-100">
                  <Rocket className="w-6 h-6 text-emerald-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Projetos Seguindo</p>
                  <p className="text-3xl font-bold text-gray-900">{followedProjects.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Section Tabs */}
        <Tabs value={activeSection} onValueChange={setActiveSection} className="mb-6">
          <TabsList className="bg-white shadow-lg">
            <TabsTrigger value="notifications" className="px-6">
              <Bell className="w-4 h-4 mr-2" />
              Notificações
            </TabsTrigger>
            <TabsTrigger value="settings" className="px-6">
              <Settings className="w-4 h-4 mr-2" />
              Preferências
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Notifications Section */}
        {activeSection === "notifications" && (
          <div>
            <Card className="border-none shadow-xl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Filter className="w-5 h-5" />
                    Todas as Notificações
                  </CardTitle>
                  {unreadCount > 0 && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => markAllAsReadMutation.mutate()}
                    >
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Marcar todas como lidas
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="w-full justify-start rounded-none border-b px-6">
                    <TabsTrigger value="all">Todas</TabsTrigger>
                    <TabsTrigger value="unread">
                      Não Lidas {unreadCount > 0 && `(${unreadCount})`}
                    </TabsTrigger>
                    <TabsTrigger value="important">
                      <span className="flex items-center gap-1">
                        Importantes
                        {importantCount > 0 && (
                          <Badge className="bg-orange-500 text-white ml-1">{importantCount}</Badge>
                        )}
                      </span>
                    </TabsTrigger>
                    <TabsTrigger value="funding_milestone">Financiamento</TabsTrigger>
                    <TabsTrigger value="new_project">Novos Projetos</TabsTrigger>
                  </TabsList>

                  <TabsContent value={activeTab} className="p-0 m-0">
                    <div className="max-h-[600px] overflow-y-auto">
                      {isLoading ? (
                        <div className="p-12 text-center">
                          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4" />
                          <p className="text-gray-600">Carregando notificações...</p>
                        </div>
                      ) : filteredNotifications.length > 0 ? (
                        <AnimatePresence>
                          {filteredNotifications.map((notification) => {
                            const Icon = iconMap[notification.type] || Bell;
                            const gradient = colorMap[notification.type] || "from-gray-500 to-gray-600";
                            const isImportant = ['funding_milestone', 'project_deadline', 'investment_recommendation'].includes(notification.type);
                            
                            return (
                              <motion.div
                                key={notification.id}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: 20 }}
                                className={`p-4 border-b cursor-pointer transition-all group relative ${
                                  notification.is_read 
                                    ? 'bg-white hover:bg-gray-50' 
                                    : `${isImportant ? 'bg-orange-50' : 'bg-blue-50'} hover:bg-blue-100 border-l-4 ${isImportant ? 'border-l-orange-500' : 'border-l-blue-500'}`
                                }`}
                                onClick={() => handleNotificationClick(notification)}
                              >
                                <div className="flex gap-4">
                                  <div className={`p-3 rounded-xl bg-gradient-to-br ${gradient} flex-shrink-0 shadow-lg`}>
                                    <Icon className="w-6 h-6 text-white" />
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                                      <p className="font-bold text-gray-900">
                                        {notification.title}
                                      </p>
                                      <Badge variant="outline" className="text-xs">
                                        {typeLabels[notification.type]}
                                      </Badge>
                                      {isImportant && !notification.is_read && (
                                        <Badge className="bg-orange-500 text-white text-xs">
                                          Importante
                                        </Badge>
                                      )}
                                    </div>
                                    <p className="text-sm text-gray-600 mb-2">
                                      {notification.message}
                                    </p>
                                    <p className="text-xs text-gray-400">
                                      {format(new Date(notification.created_date), "dd 'de' MMMM 'às' HH:mm", { locale: ptBR })}
                                    </p>
                                  </div>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      deleteNotificationMutation.mutate(notification.id);
                                    }}
                                  >
                                    <Trash2 className="w-4 h-4 text-red-500" />
                                  </Button>
                                </div>
                              </motion.div>
                            );
                          })}
                        </AnimatePresence>
                      ) : (
                        <div className="p-12 text-center">
                          <Bell className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                          <h3 className="text-lg font-semibold text-gray-900 mb-2">
                            Nenhuma notificação
                          </h3>
                          <p className="text-gray-600">
                            {activeTab === 'unread' 
                              ? 'Todas as notificações foram lidas!' 
                              : activeTab === 'important'
                              ? 'Nenhuma notificação importante no momento.'
                              : 'Você não tem notificações ainda.'}
                          </p>
                        </div>
                      )}
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Settings Section */}
        {activeSection === "settings" && user && (
          <NotificationPreferences user={user} />
        )}
      </div>
    </div>
  );
}