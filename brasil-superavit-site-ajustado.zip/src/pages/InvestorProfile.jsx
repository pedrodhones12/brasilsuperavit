
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  User,
  Camera,
  Briefcase,
  Facebook,
  Instagram,
  Linkedin,
  Mail,
  MessageCircle,
  Plus,
  X,
  CheckCircle,
  Sparkles,
  TrendingUp,
  Award,
  DollarSign,
  Target,
  Globe,
  Rocket,
  Building2,
  GraduationCap,
  Heart,
  Palmtree,
  ShoppingBag,
  Lightbulb,
  Leaf,
  MapPin,
  Shield // Added Shield icon
} from "lucide-react";
import { motion } from "framer-motion";

const sectorIcons = {
  tecnologico: Rocket,
  cultural: Sparkles,
  sustentabilidade: Leaf,
  infraestrutura: Building2,
  educacao: GraduationCap,
  saude: Heart,
  turismo: Palmtree,
  comercio: ShoppingBag,
  inovacao: Lightbulb
};

const sectorColors = {
  tecnologico: "from-blue-500 to-blue-600",
  cultural: "from-purple-500 to-purple-600",
  sustentabilidade: "from-emerald-500 to-emerald-600",
  infraestrutura: "from-orange-500 to-orange-600",
  educacao: "from-indigo-500 to-indigo-600",
  saude: "from-red-500 to-pink-600",
  turismo: "from-cyan-500 to-teal-600",
  comercio: "from-amber-500 to-yellow-600",
  inovacao: "from-violet-500 to-fuchsia-600"
};

const sectorNames = {
  tecnologico: "Tecnológico",
  cultural: "Cultural",
  sustentabilidade: "Sustentabilidade",
  infraestrutura: "Infraestrutura",
  educacao: "Educação",
  saude: "Saúde",
  turismo: "Turismo",
  comercio: "Comércio",
  inovacao: "Inovação"
};

export default function InvestorProfile() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [newCertification, setNewCertification] = useState("");
  const [newHighlight, setNewHighlight] = useState("");
  
  const [formData, setFormData] = useState({
    profile_photo_url: "",
    bio: "",
    location: "",
    nationality: "", // New field
    bank_name: "", 
    bank_code: "", 
    bank_agency: "", 
    bank_account: "", 
    bank_account_type: "", 
    pix_key: "", 
    pix_key_type: "", 
    facebook_url: "",
    instagram_url: "",
    linkedin_url: "",
    website_url: "",
    whatsapp: "",
    gmail: "",
    investment_sectors: [],
    investment_budget_range: "",
    investment_experience: "",
    investor_type: "",
    investment_goal: "",
    portfolio_highlights: [],
    certifications: []
  });

  const queryClient = useQueryClient();

  // Fetch investments for statistics
  const { data: myInvestments = [] } = useQuery({
    queryKey: ['my-investments-stats', user?.email],
    queryFn: () => base44.entities.Investment.filter({ 
      investor_email: user?.email,
      status: 'confirmado' 
    }),
    enabled: !!user?.email,
  });

  const totalInvested = myInvestments.reduce((sum, inv) => sum + (inv.amount || 0), 0);
  const projectsCount = new Set(myInvestments.map(inv => inv.project_id)).size;

  useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
        
        setFormData({
          profile_photo_url: userData.profile_photo_url || "",
          bio: userData.bio || "",
          location: userData.location || "",
          nationality: userData.nationality || "", // Initialize new field
          bank_name: userData.bank_name || "", 
          bank_code: userData.bank_code || "", 
          bank_agency: userData.bank_agency || "", 
          bank_account: userData.bank_account || "", 
          bank_account_type: userData.bank_account_type || "", 
          pix_key: userData.pix_key || "", 
          pix_key_type: userData.pix_key_type || "", 
          facebook_url: userData.facebook_url || "",
          instagram_url: userData.instagram_url || "",
          linkedin_url: userData.linkedin_url || "",
          website_url: userData.website_url || "",
          whatsapp: userData.whatsapp || "",
          gmail: userData.gmail || userData.email || "",
          investment_sectors: userData.investment_sectors || [],
          investment_budget_range: userData.investment_budget_range || "",
          investment_experience: userData.investment_experience || "",
          investor_type: userData.investor_type || "",
          investment_goal: userData.investment_goal || "",
          portfolio_highlights: userData.portfolio_highlights || [],
          certifications: userData.certifications || []
        });
      } catch (error) {
        console.error("Error loading user:", error);
      } finally {
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  const updateProfileMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: (updatedUser) => {
      setUser(updatedUser);
      alert("Perfil de investidor atualizado com sucesso! ✅");
      queryClient.invalidateQueries({ queryKey: ['user'] });
    },
  });

  const handlePhotoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploadingPhoto(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData(prev => ({ ...prev, profile_photo_url: file_url }));
    } catch (error) {
      alert("Erro ao fazer upload da foto");
    } finally {
      setUploadingPhoto(false);
    }
  };

  const toggleSector = (sector) => {
    setFormData(prev => ({
      ...prev,
      investment_sectors: prev.investment_sectors.includes(sector)
        ? prev.investment_sectors.filter(s => s !== sector)
        : [...prev.investment_sectors, sector]
    }));
  };

  const addCertification = () => {
    if (newCertification.trim()) {
      setFormData(prev => ({
        ...prev,
        certifications: [...prev.certifications, newCertification.trim()]
      }));
      setNewCertification("");
    }
  };

  const removeCertification = (index) => {
    setFormData(prev => ({
      ...prev,
      certifications: prev.certifications.filter((_, i) => i !== index)
    }));
  };

  const addHighlight = () => {
    if (newHighlight.trim()) {
      setFormData(prev => ({
        ...prev,
        portfolio_highlights: [...prev.portfolio_highlights, newHighlight.trim()]
      }));
      setNewHighlight("");
    }
  };

  const removeHighlight = (index) => {
    setFormData(prev => ({
      ...prev,
      portfolio_highlights: prev.portfolio_highlights.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    updateProfileMutation.mutate(formData);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-emerald-600 mx-auto mb-4" />
          <p className="text-gray-600">Carregando perfil de investidor...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-blue-50/30 via-purple-50/30 to-emerald-50/30">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 text-center"
        >
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 via-purple-500 to-emerald-500 mb-4 shadow-2xl">
            <TrendingUp className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-emerald-600 bg-clip-text text-transparent mb-2">
            Perfil de Investidor
          </h1>
          <p className="text-xl text-gray-600">
            Mostre sua experiência e áreas de interesse para projetos
          </p>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="border-none shadow-xl bg-gradient-to-br from-blue-50 to-white">
              <CardContent className="p-6 text-center">
                <DollarSign className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                <p className="text-3xl font-bold text-gray-900 mb-1">
                  R$ {totalInvested.toLocaleString('pt-BR')}
                </p>
                <p className="text-gray-600">Total Investido</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="border-none shadow-xl bg-gradient-to-br from-purple-50 to-white">
              <CardContent className="p-6 text-center">
                <Briefcase className="w-12 h-12 text-purple-600 mx-auto mb-3" />
                <p className="text-3xl font-bold text-gray-900 mb-1">{projectsCount}</p>
                <p className="text-gray-600">Projetos Apoiados</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="border-none shadow-xl bg-gradient-to-br from-emerald-50 to-white">
              <CardContent className="p-6 text-center">
                <Award className="w-12 h-12 text-emerald-600 mx-auto mb-3" />
                <p className="text-3xl font-bold text-gray-900 mb-1">
                  {formData.investment_sectors.length}
                </p>
                <p className="text-gray-600">Setores de Interesse</p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="space-y-6">
            {/* Photo & Basic Info */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <Card className="border-none shadow-2xl">
                <CardHeader className="bg-gradient-to-r from-blue-50 via-purple-50 to-emerald-50">
                  <CardTitle className="flex items-center gap-3">
                    <User className="w-6 h-6 text-blue-600" />
                    Informações Básicas
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-8">
                  <div className="flex flex-col md:flex-row gap-8 items-start">
                    {/* Photo */}
                    <div className="flex flex-col items-center gap-4">
                      <Avatar className="w-32 h-32 border-4 border-white shadow-xl">
                        {formData.profile_photo_url ? (
                          <AvatarImage src={formData.profile_photo_url} alt="Profile" />
                        ) : (
                          <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-500 text-white text-4xl font-bold">
                            {user?.full_name?.substring(0, 2).toUpperCase() || 'IN'}
                          </AvatarFallback>
                        )}
                      </Avatar>
                      <div>
                        <Input
                          type="file"
                          accept="image/*"
                          onChange={handlePhotoUpload}
                          disabled={uploadingPhoto}
                          className="hidden"
                          id="photo-upload"
                        />
                        <Label htmlFor="photo-upload">
                          <Button
                            type="button"
                            variant="outline"
                            disabled={uploadingPhoto}
                            className="cursor-pointer"
                            onClick={() => document.getElementById('photo-upload').click()}
                          >
                            <Camera className="w-4 h-4 mr-2" />
                            {uploadingPhoto ? "Enviando..." : "Alterar Foto"}
                          </Button>
                        </Label>
                      </div>
                    </div>

                    {/* Basic Info */}
                    <div className="flex-1 space-y-4 w-full">
                      <div>
                        <Label className="text-base font-semibold mb-2 block">Nome Completo</Label>
                        <Input value={user?.full_name || ""} disabled className="bg-gray-50" />
                      </div>
                      <div>
                        <Label className="text-base font-semibold mb-2 block">Email</Label>
                        <Input value={user?.email || ""} disabled className="bg-gray-50" />
                      </div>
                      
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="location" className="text-base font-semibold mb-2 block">
                            <MapPin className="w-4 h-4 inline mr-2" />
                            Localização
                          </Label>
                          <Input
                            id="location"
                            value={formData.location}
                            onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                            placeholder="Cidade, Estado"
                          />
                        </div>

                        <div>
                          <Label htmlFor="nationality" className="text-base font-semibold mb-2 block">
                            <Globe className="w-4 h-4 inline mr-2" />
                            Nacionalidade
                          </Label>
                          <select
                            id="nationality"
                            value={formData.nationality}
                            onChange={(e) => setFormData(prev => ({ ...prev, nationality: e.target.value }))}
                            className="w-full h-10 px-4 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200" // Adjusted h-10 to match Input height
                          >
                            <option value="">Selecione</option>
                            <option value="Brasileira">🇧🇷 Brasileira</option>
                            <option value="Americana">🇺🇸 Americana</option>
                            <option value="Portuguesa">🇵🇹 Portuguesa</option>
                            <option value="Espanhola">🇪🇸 Espanhola</option>
                            <option value="Italiana">🇮🇹 Italiana</option>
                            <option value="Francesa">🇫🇷 Francesa</option>
                            <option value="Alemã">🇩🇪 Alemã</option>
                            <option value="Britânica">🇬🇧 Britânica</option>
                            <option value="Canadense">🇨🇦 Canadense</option>
                            <option value="Argentina">🇦🇷 Argentina</option>
                            <option value="Chilena">🇨🇱 Chilena</option>
                            <option value="Colombiana">🇨🇴 Colombiana</option>
                            <option value="Mexicana">🇲🇽 Mexicana</option>
                            <option value="Chinesa">🇨🇳 Chinesa</option>
                            <option value="Japonesa">🇯🇵 Japonesa</option>
                            <option value="Indiana">🇮🇳 Indiana</option>
                            <option value="Russa">🇷🇺 Russa</option>
                            <option value="Australiana">🇦🇺 Australiana</option>
                            <option value="Sul-Africana">🇿🇦 Sul-Africana</option>
                            <option value="Outra">🌍 Outra</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="bio" className="text-base font-semibold mb-2 block">
                          Sobre Você
                        </Label>
                        <Textarea
                          id="bio"
                          value={formData.bio}
                          onChange={(e) => setFormData(prev => ({ ...prev, bio: e.target.value }))}
                          placeholder="Conte sobre sua experiência como investidor, motivações e objetivos..."
                          className="min-h-32"
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Investment Profile */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
            >
              <Card className="border-none shadow-2xl">
                <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                  <CardTitle className="flex items-center gap-3">
                    <Target className="w-6 h-6 text-emerald-600" />
                    Perfil de Investimento
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="investor_type" className="text-base font-semibold">
                        Tipo de Investidor
                      </Label>
                      <Select
                        value={formData.investor_type}
                        onValueChange={(value) => setFormData(prev => ({ ...prev, investor_type: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione o tipo" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="anjo">Investidor Anjo</SelectItem>
                          <SelectItem value="institucional">Investidor Institucional</SelectItem>
                          <SelectItem value="venture_capital">Venture Capital</SelectItem>
                          <SelectItem value="crowdfunding">Crowdfunding Enthusiast</SelectItem>
                          <SelectItem value="pessoal">Investidor Pessoal</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="investment_experience" className="text-base font-semibold">
                        Experiência em Investimentos
                      </Label>
                      <Select
                        value={formData.investment_experience}
                        onValueChange={(value) => setFormData(prev => ({ ...prev, investment_experience: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Nível de experiência" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="iniciante">Iniciante</SelectItem>
                          <SelectItem value="intermediario">Intermediário</SelectItem>
                          <SelectItem value="avancado">Avançado</SelectItem>
                          <SelectItem value="expert">Expert</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="investment_budget_range" className="text-base font-semibold">
                        Faixa de Orçamento
                      </Label>
                      <Select
                        value={formData.investment_budget_range}
                        onValueChange={(value) => setFormData(prev => ({ ...prev, investment_budget_range: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione a faixa" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="5k-10k">R$ 5.000 - R$ 10.000</SelectItem>
                          <SelectItem value="10k-50k">R$ 10.000 - R$ 50.000</SelectItem>
                          <SelectItem value="50k-100k">R$ 50.000 - R$ 100.000</SelectItem>
                          <SelectItem value="100k-500k">R$ 100.000 - R$ 500.000</SelectItem>
                          <SelectItem value="500k+">R$ 500.000+</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="investment_goal" className="text-base font-semibold">
                        Objetivo Principal
                      </Label>
                      <Input
                        id="investment_goal"
                        value={formData.investment_goal}
                        onChange={(e) => setFormData(prev => ({ ...prev, investment_goal: e.target.value }))}
                        placeholder="Ex: Apoiar inovação social"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* NEW Banking Details Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.55 }}
            >
              <Card className="border-none shadow-2xl">
                <CardHeader className="bg-gradient-to-r from-emerald-50 to-teal-50">
                  <CardTitle className="flex items-center gap-3">
                    <DollarSign className="w-6 h-6 text-emerald-600" />
                    Dados Bancários para Recebimentos
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-6">
                  <Alert className="border-emerald-200 bg-emerald-50">
                    <Shield className="h-4 w-4 text-emerald-600" />
                    <AlertDescription className="text-emerald-900">
                      <strong>💰 Importante:</strong> Cadastre seus dados bancários para receber dividendos, retornos de investimentos e outros pagamentos.
                    </AlertDescription>
                  </Alert>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="bank_name">Nome do Banco *</Label>
                      <Input
                        id="bank_name"
                        value={formData.bank_name}
                        onChange={(e) => setFormData(prev => ({ ...prev, bank_name: e.target.value }))}
                        placeholder="Ex: Banco do Brasil, Itaú..."
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="bank_code">Código do Banco</Label>
                      <Input
                        id="bank_code"
                        value={formData.bank_code}
                        onChange={(e) => setFormData(prev => ({ ...prev, bank_code: e.target.value }))}
                        placeholder="Ex: 001, 237, 341..."
                        maxLength={3}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="bank_agency">Agência (com dígito) *</Label>
                      <Input
                        id="bank_agency"
                        value={formData.bank_agency}
                        onChange={(e) => setFormData(prev => ({ ...prev, bank_agency: e.target.value }))}
                        placeholder="Ex: 1234-5"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="bank_account">Conta (com dígito) *</Label>
                      <Input
                        id="bank_account"
                        value={formData.bank_account}
                        onChange={(e) => setFormData(prev => ({ ...prev, bank_account: e.target.value }))}
                        placeholder="Ex: 98765-4"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Tipo de Conta *</Label>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div
                        onClick={() => setFormData(prev => ({ ...prev, bank_account_type: 'corrente' }))}
                        className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                          formData.bank_account_type === 'corrente'
                            ? 'border-emerald-500 bg-emerald-50 shadow-lg'
                            : 'border-gray-200 hover:border-emerald-300'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <span className="text-3xl">💳</span>
                          <div>
                            <h4 className="font-bold text-gray-900">Conta Corrente</h4>
                            <p className="text-xs text-gray-600">Movimentação diária</p>
                          </div>
                        </div>
                      </div>

                      <div
                        onClick={() => setFormData(prev => ({ ...prev, bank_account_type: 'poupanca' }))}
                        className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                          formData.bank_account_type === 'poupanca'
                            ? 'border-blue-500 bg-blue-50 shadow-lg'
                            : 'border-gray-200 hover:border-blue-300'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <span className="text-3xl">🏦</span>
                          <div>
                            <h4 className="font-bold text-gray-900">Poupança</h4>
                            <p className="text-xs text-gray-600">Rendimento automático</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                      <MessageCircle className="w-5 h-5 text-emerald-600" />
                      Chave PIX (Opcional)
                    </h3>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="pix_key_type">Tipo de Chave</Label>
                        <Select
                          value={formData.pix_key_type}
                          onValueChange={(value) => setFormData(prev => ({ ...prev, pix_key_type: value }))}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o tipo" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="cpf">CPF</SelectItem>
                            <SelectItem value="cnpj">CNPJ</SelectItem>
                            <SelectItem value="email">Email</SelectItem>
                            <SelectItem value="telefone">Telefone</SelectItem>
                            <SelectItem value="aleatoria">Chave Aleatória</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="pix_key">Chave PIX</Label>
                        <Input
                          id="pix_key"
                          value={formData.pix_key}
                          onChange={(e) => setFormData(prev => ({ ...prev, pix_key: e.target.value }))}
                          placeholder="Digite sua chave PIX"
                        />
                      </div>
                    </div>

                    <p className="text-xs text-gray-500 mt-2">
                      💡 Com PIX você recebe pagamentos instantaneamente, 24 horas por dia, 7 dias por semana
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Investment Sectors */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
            >
              <Card className="border-none shadow-2xl">
                <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
                  <CardTitle className="flex items-center gap-3">
                    <Sparkles className="w-6 h-6 text-purple-600" />
                    Setores de Interesse
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <Alert className="border-purple-200 bg-purple-50 mb-6">
                    <Lightbulb className="h-4 w-4 text-purple-600" />
                    <AlertDescription className="text-purple-900">
                      Selecione os setores em que você tem interesse em investir. Projetos nesses setores aparecerão em destaque para você!
                    </AlertDescription>
                  </Alert>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {Object.entries(sectorNames).map(([key, name]) => {
                      const Icon = sectorIcons[key];
                      const isSelected = formData.investment_sectors.includes(key);
                      return (
                        <div
                          key={key}
                          onClick={() => toggleSector(key)}
                          className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                            isSelected
                              ? 'border-purple-500 bg-purple-50 shadow-lg'
                              : 'border-gray-200 hover:border-purple-300'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <div className={`p-3 rounded-lg bg-gradient-to-br ${sectorColors[key]}`}>
                              <Icon className="w-5 h-5 text-white" />
                            </div>
                            <div className="flex-1">
                              <h4 className="font-bold text-gray-900">{name}</h4>
                            </div>
                            {isSelected && (
                              <CheckCircle className="w-5 h-5 text-purple-600" />
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Portfolio Highlights */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 }}
            >
              <Card className="border-none shadow-2xl">
                <CardHeader className="bg-gradient-to-r from-yellow-50 to-orange-50">
                  <CardTitle className="flex items-center gap-3">
                    <Award className="w-6 h-6 text-yellow-600" />
                    Destaques do Portfólio
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                  <div className="flex gap-2">
                    <Input
                      value={newHighlight}
                      onChange={(e) => setNewHighlight(e.target.value)}
                      placeholder="Ex: Investidor em 5 startups de tecnologia educacional"
                      onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addHighlight())}
                    />
                    <Button type="button" onClick={addHighlight} variant="outline">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>

                  {formData.portfolio_highlights.length > 0 && (
                    <div className="space-y-2">
                      {formData.portfolio_highlights.map((highlight, index) => (
                        <div key={index} className="flex items-center gap-3 p-3 bg-yellow-50 rounded-lg">
                          <Award className="w-4 h-4 text-yellow-600" />
                          <span className="flex-1 text-gray-900">{highlight}</span>
                          <button
                            type="button"
                            onClick={() => removeHighlight(index)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Certifications */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
            >
              <Card className="border-none shadow-2xl">
                <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50">
                  <CardTitle className="flex items-center gap-3">
                    <GraduationCap className="w-6 h-6 text-blue-600" />
                    Certificações e Qualificações
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                  <div className="flex gap-2">
                    <Input
                      value={newCertification}
                      onChange={(e) => setNewCertification(e.target.value)}
                      placeholder="Ex: CFA (Chartered Financial Analyst)"
                      onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addCertification())}
                    />
                    <Button type="button" onClick={addCertification} variant="outline">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>

                  {formData.certifications.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {formData.certifications.map((cert, index) => (
                        <Badge key={index} className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white px-4 py-2 text-sm">
                          📜 {cert}
                          <button
                            type="button"
                            onClick={() => removeCertification(index)}
                            className="ml-2 hover:text-red-200"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Social Media */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.9 }}
            >
              <Card className="border-none shadow-2xl">
                <CardHeader className="bg-gradient-to-r from-pink-50 to-purple-50">
                  <CardTitle className="flex items-center gap-3">
                    <Globe className="w-6 h-6 text-pink-600" />
                    Redes Sociais e Contatos
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="linkedin" className="flex items-center gap-2">
                        <Linkedin className="w-4 h-4 text-blue-700" />
                        LinkedIn
                      </Label>
                      <Input
                        id="linkedin"
                        type="url"
                        value={formData.linkedin_url}
                        onChange={(e) => setFormData(prev => ({ ...prev, linkedin_url: e.target.value }))}
                        placeholder="https://linkedin.com/in/seu-perfil"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="website" className="flex items-center gap-2">
                        <Globe className="w-4 h-4 text-purple-600" />
                        Website
                      </Label>
                      <Input
                        id="website"
                        type="url"
                        value={formData.website_url}
                        onChange={(e) => setFormData(prev => ({ ...prev, website_url: e.target.value }))}
                        placeholder="https://seu-site.com"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="facebook" className="flex items-center gap-2">
                        <Facebook className="w-4 h-4 text-blue-600" />
                        Facebook
                      </Label>
                      <Input
                        id="facebook"
                        type="url"
                        value={formData.facebook_url}
                        onChange={(e) => setFormData(prev => ({ ...prev, facebook_url: e.target.value }))}
                        placeholder="https://facebook.com/seu-perfil"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="instagram" className="flex items-center gap-2">
                        <Instagram className="w-4 h-4 text-pink-600" />
                        Instagram
                      </Label>
                      <Input
                        id="instagram"
                        type="url"
                        value={formData.instagram_url}
                        onChange={(e) => setFormData(prev => ({ ...prev, instagram_url: e.target.value }))}
                        placeholder="https://instagram.com/seu-usuario"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="whatsapp" className="flex items-center gap-2">
                        <MessageCircle className="w-4 h-4 text-green-600" />
                        WhatsApp
                      </Label>
                      <Input
                        id="whatsapp"
                        type="tel"
                        value={formData.whatsapp}
                        onChange={(e) => setFormData(prev => ({ ...prev, whatsapp: e.target.value }))}
                        placeholder="+55 11 99999-9999"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="gmail" className="flex items-center gap-2">
                        <Mail className="w-4 h-4 text-red-600" />
                        Email de Contato
                      </Label>
                      <Input
                        id="gmail"
                        type="email"
                        value={formData.gmail}
                        onChange={(e) => setFormData(prev => ({ ...prev, gmail: e.target.value }))}
                        placeholder="seu-email@gmail.com"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Submit */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.0 }}
            >
              <Button
                type="submit"
                disabled={updateProfileMutation.isPending}
                className="w-full h-16 text-lg bg-gradient-to-r from-blue-500 via-purple-500 to-emerald-500 hover:from-blue-600 hover:via-purple-600 hover:to-emerald-600 shadow-2xl"
              >
                {updateProfileMutation.isPending ? (
                  "Salvando..."
                ) : (
                  <>
                    <CheckCircle className="w-6 h-6 mr-2" />
                    Salvar Perfil de Investidor
                  </>
                )}
              </Button>
            </motion.div>
          </div>
        </form>
      </div>
    </div>
  );
}
