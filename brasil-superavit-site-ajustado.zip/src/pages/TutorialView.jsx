import React, { useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  ArrowLeft,
  Play,
  BookOpen,
  Target,
  Lightbulb,
  CheckCircle,
  Clock,
  Eye,
  Share2,
  Rocket,
  AlertCircle,
  VideoOff
} from "lucide-react";
import { motion } from "framer-motion";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

const categoryInfo = {
  empreendedorismo: {
    name: "Empreendedorismo & Sustentabilidade",
    color: "from-emerald-500 to-emerald-600",
    icon: Lightbulb
  },
  tecnologia: {
    name: "Tecnologia & Startups",
    color: "from-blue-500 to-purple-600",
    icon: Rocket
  }
};

export default function TutorialView() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const tutorialId = urlParams.get('id');
  const [user, setUser] = React.useState(null);
  const [userInputs, setUserInputs] = React.useState({
    interests: [],
    problems: []
  });
  const [showInputForm, setShowInputForm] = React.useState(false);

  React.useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  const { data: tutorial, isLoading } = useQuery({
    queryKey: ['tutorial', tutorialId],
    queryFn: async () => {
      const tutorials = await base44.entities.Tutorial.list();
      return tutorials.find(t => t.id === tutorialId);
    },
    enabled: !!tutorialId,
  });

  const { data: allTutorials = [] } = useQuery({
    queryKey: ['tutorials'],
    queryFn: () => base44.entities.Tutorial.list('order'),
  });

  const incrementViewMutation = useMutation({
    mutationFn: () => base44.entities.Tutorial.update(tutorialId, {
      views: (tutorial?.views || 0) + 1
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tutorial', tutorialId] });
      queryClient.invalidateQueries({ queryKey: ['tutorials'] });
    },
  });

  const saveUserInputsMutation = useMutation({
    mutationFn: async (inputs) => {
      const completedTutorials = user?.completed_tutorials || [];
      if (!completedTutorials.includes(tutorialId)) {
        completedTutorials.push(tutorialId);
      }

      return await base44.auth.updateMe({
        interests: inputs.interests,
        problems_to_solve: inputs.problems,
        completed_tutorials: completedTutorials
      });
    },
    onSuccess: () => {
      setShowInputForm(false);
      alert('Suas respostas foram salvas! Agora você pode usar a IA para gerar ideias personalizadas ao criar projetos.');
    },
  });

  React.useEffect(() => {
    if (tutorial && !sessionStorage.getItem(`tutorial_viewed_${tutorialId}`)) {
      incrementViewMutation.mutate();
      sessionStorage.setItem(`tutorial_viewed_${tutorialId}`, 'true');
      
      // Show input form for "Descobrindo Seu Potencial" tutorial
      if (tutorial.title === "Descobrindo Seu Potencial" && user) {
        setShowInputForm(true);
      }
    }
  }, [tutorial, tutorialId, user]);

  const handleSaveInputs = () => {
    if (userInputs.interests.length === 0 || userInputs.problems.length === 0) {
      alert('Por favor, preencha pelo menos um interesse e um problema');
      return;
    }
    saveUserInputsMutation.mutate(userInputs);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-emerald-600 mx-auto mb-4" />
          <p className="text-gray-600">Carregando tutorial...</p>
        </div>
      </div>
    );
  }

  if (!tutorial) {
    return (
      <div className="min-h-screen p-8 flex items-center justify-center">
        <Card className="max-w-md w-full p-8 text-center">
          <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Tutorial não encontrado</h2>
          <p className="text-gray-600 mb-6">O tutorial que você procura não existe ou foi removido.</p>
          <Link to={createPageUrl("Education")}>
            <Button className="bg-gradient-to-r from-emerald-500 to-blue-500">
              Voltar para Tutoriais
            </Button>
          </Link>
        </Card>
      </div>
    );
  }

  const categoryData = categoryInfo[tutorial.category];
  const Icon = categoryData.icon;
  
  const currentIndex = allTutorials.findIndex(t => t.id === tutorial.id);
  const nextTutorial = allTutorials[currentIndex + 1];
  const prevTutorial = allTutorials[currentIndex - 1];

  const contentSections = tutorial.content?.split('\n\n').filter(s => s.trim()) || [];

  // Function to get embeddable video URL
  const getEmbedUrl = (url) => {
    if (!url) return null;
    
    // YouTube
    if (url.includes('youtube.com/watch')) {
      const videoId = url.split('v=')[1]?.split('&')[0];
      return videoId ? `https://www.youtube.com/embed/${videoId}` : null;
    }
    if (url.includes('youtu.be/')) {
      const videoId = url.split('youtu.be/')[1]?.split('?')[0];
      return videoId ? `https://www.youtube.com/embed/${videoId}` : null;
    }
    
    // Vimeo
    if (url.includes('vimeo.com/')) {
      const videoId = url.split('vimeo.com/')[1]?.split('?')[0];
      return videoId ? `https://player.vimeo.com/video/${videoId}` : null;
    }
    
    // If already an embed URL, return as is
    if (url.includes('embed')) {
      return url;
    }
    
    return null;
  };

  const embedUrl = getEmbedUrl(tutorial.video_url);

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-emerald-50/30 via-blue-50/30 to-purple-50/30">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Button
            variant="outline"
            onClick={() => navigate(createPageUrl("Education"))}
            className="mb-6"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar para Tutoriais
          </Button>

          <div className="flex items-start gap-6 mb-6">
            <div className={`p-5 rounded-2xl bg-gradient-to-br ${categoryData.color} shadow-xl`}>
              <Icon className="w-12 h-12 text-white" />
            </div>
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-3 mb-3">
                <Badge className={`bg-gradient-to-r ${categoryData.color} text-white border-none font-semibold text-base px-4 py-1`}>
                  Roteiro {tutorial.order}
                </Badge>
                <Badge variant="outline" className="font-medium">
                  {categoryData.name}
                </Badge>
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-3">
                {tutorial.title}
              </h1>
              <div className="flex flex-wrap items-center gap-4 text-gray-600">
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  <span className="font-medium">{tutorial.duration || '3-5 min'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Eye className="w-5 h-5" />
                  <span className="font-medium">{tutorial.views || 0} visualizações</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Video/Media Section */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 }}
            >
              <Card className="border-none shadow-xl overflow-hidden">
                {embedUrl ? (
                  <div className="relative aspect-video bg-gray-900">
                    <iframe
                      src={embedUrl}
                      className="w-full h-full"
                      allowFullScreen
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    />
                  </div>
                ) : (
                  <div className={`relative aspect-video bg-gradient-to-br ${categoryData.color} flex flex-col items-center justify-center p-8`}>
                    <VideoOff className="w-20 h-20 text-white/60 mb-4" />
                    <p className="text-white text-center text-lg font-semibold mb-2">
                      Vídeo em breve
                    </p>
                    <p className="text-white/80 text-center text-sm max-w-md">
                      O conteúdo escrito completo está disponível abaixo. 
                      Em breve adicionaremos vídeos para enriquecer sua experiência de aprendizado.
                    </p>
                  </div>
                )}
              </Card>
            </motion.div>

            {/* Theme & Objective */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card className="border-none shadow-xl">
                <CardHeader className={`bg-gradient-to-r ${categoryData.color} text-white`}>
                  <CardTitle className="flex items-center gap-3">
                    <Target className="w-6 h-6" />
                    Tema e Objetivo
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                      <Lightbulb className="w-5 h-5 text-yellow-500" />
                      Tema
                    </h3>
                    <p className="text-gray-700 text-lg">{tutorial.theme}</p>
                  </div>
                  <div className="pt-4 border-t border-gray-200">
                    <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                      <Target className="w-5 h-5 text-emerald-500" />
                      Objetivo
                    </h3>
                    <p className="text-gray-700 text-lg">{tutorial.objective}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Interactive Exercise Form for "Descobrindo Seu Potencial" */}
            {tutorial.title === "Descobrindo Seu Potencial" && showInputForm && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                <Card className="border-none shadow-xl bg-gradient-to-r from-yellow-50 to-emerald-50">
                  <CardHeader className="bg-gradient-to-r from-yellow-500 to-emerald-500 text-white">
                    <CardTitle className="flex items-center gap-3">
                      <Lightbulb className="w-6 h-6" />
                      Exercício Prático
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6 space-y-6">
                    <Alert className="border-blue-200 bg-blue-50">
                      <AlertCircle className="h-4 w-4 text-blue-600" />
                      <AlertDescription className="text-blue-900">
                        Suas respostas serão usadas pela nossa IA para gerar ideias de projetos personalizadas!
                      </AlertDescription>
                    </Alert>

                    <div className="space-y-4">
                      <div>
                        <Label className="text-base font-semibold mb-3 block">
                          Liste 3 coisas que você faz bem:
                        </Label>
                        {[0, 1, 2].map((index) => (
                          <Input
                            key={index}
                            placeholder={`Habilidade ${index + 1}`}
                            className="mb-2"
                            value={userInputs.interests[index] || ''}
                            onChange={(e) => {
                              const newInterests = [...userInputs.interests];
                              newInterests[index] = e.target.value;
                              setUserInputs(prev => ({ ...prev, interests: newInterests }));
                            }}
                          />
                        ))}
                      </div>

                      <div>
                        <Label className="text-base font-semibold mb-3 block">
                          Liste 3 problemas que gostaria de resolver na sua cidade:
                        </Label>
                        {[0, 1, 2].map((index) => (
                          <Input
                            key={index}
                            placeholder={`Problema ${index + 1}`}
                            className="mb-2"
                            value={userInputs.problems[index] || ''}
                            onChange={(e) => {
                              const newProblems = [...userInputs.problems];
                              newProblems[index] = e.target.value;
                              setUserInputs(prev => ({ ...prev, problems: newProblems }));
                            }}
                          />
                        ))}
                      </div>

                      <Button
                        onClick={handleSaveInputs}
                        disabled={saveUserInputsMutation.isPending}
                        className="w-full bg-gradient-to-r from-yellow-500 to-emerald-500 hover:from-yellow-600 hover:to-emerald-600"
                      >
                        {saveUserInputsMutation.isPending ? (
                          "Salvando..."
                        ) : (
                          <>
                            <CheckCircle className="w-5 h-5 mr-2" />
                            Salvar Respostas
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Content Sections */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Card className="border-none shadow-xl">
                <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                  <CardTitle className="flex items-center gap-3">
                    <BookOpen className="w-6 h-6 text-emerald-600" />
                    Roteiro Completo
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="prose prose-lg max-w-none">
                    {contentSections.map((section, index) => (
                      <div key={index} className="mb-6">
                        <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                          {section}
                        </p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Navigation */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="flex gap-4"
            >
              {prevTutorial && (
                <Link to={createPageUrl(`TutorialView?id=${prevTutorial.id}`)} className="flex-1">
                  <Button variant="outline" className="w-full h-auto py-4 justify-start">
                    <div className="text-left">
                      <p className="text-xs text-gray-500 mb-1">Anterior</p>
                      <p className="font-semibold line-clamp-1">{prevTutorial.title}</p>
                    </div>
                  </Button>
                </Link>
              )}
              {nextTutorial && (
                <Link to={createPageUrl(`TutorialView?id=${nextTutorial.id}`)} className="flex-1">
                  <Button className={`w-full h-auto py-4 justify-end bg-gradient-to-r ${categoryData.color}`}>
                    <div className="text-right">
                      <p className="text-xs text-white/80 mb-1">Próximo</p>
                      <p className="font-semibold line-clamp-1">{nextTutorial.title}</p>
                    </div>
                  </Button>
                </Link>
              )}
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Key Points */}
            {tutorial.key_points && tutorial.key_points.length > 0 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
              >
                <Card className="border-none shadow-xl">
                  <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                    <CardTitle className="text-lg">Principais Tópicos</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <ul className="space-y-3">
                      {tutorial.key_points.map((point, index) => (
                        <li key={index} className="flex items-start gap-3">
                          <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-700">{point}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Share */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Card className="border-none shadow-xl">
                <CardContent className="p-6">
                  <Button variant="outline" className="w-full" onClick={() => {
                    navigator.clipboard.writeText(window.location.href);
                    alert('Link copiado!');
                  }}>
                    <Share2 className="w-4 h-4 mr-2" />
                    Compartilhar Tutorial
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            {/* Motivation */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              <Alert className="border-none shadow-xl bg-gradient-to-br from-emerald-50 to-blue-50">
                <Rocket className="h-5 w-5 text-emerald-600" />
                <AlertDescription className="text-gray-700 mt-2">
                  <strong className="block mb-2">Continue Aprendendo!</strong>
                  Cada tutorial é um passo na construção do seu futuro empreendedor. 
                  Pratique o que aprendeu e compartilhe com sua comunidade.
                </AlertDescription>
              </Alert>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}