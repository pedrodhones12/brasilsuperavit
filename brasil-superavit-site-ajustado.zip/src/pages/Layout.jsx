
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  LayoutDashboard, 
  Rocket, 
  TrendingUp, 
  Briefcase,
  PlusCircle,
  ChartBar,
  LogOut,
  User,
  GraduationCap,
  Shield,
  Users,
  Globe,
  Handshake,
  Video,
  Lightbulb,
  UserCircle,
  Bell,
  Menu,
  Crown,
  X
} from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { base44 } from "@/api/base44Client";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import NotificationBell from "@/components/notifications/NotificationBell";

const navigationItems = [
  { title: "Painel Geral", url: createPageUrl("Dashboard"), icon: LayoutDashboard },
  { title: "Projetos", url: createPageUrl("Projects"), icon: Rocket },
  { title: "Investir", url: createPageUrl("Invest"), icon: TrendingUp },
  { title: "🌍 Feed Global", url: createPageUrl("GlobalFeed"), icon: Globe },
  { title: "Criar Projeto", url: createPageUrl("CreateProject"), icon: PlusCircle, requiresAuth: true },
  { title: "Meus Investimentos", url: createPageUrl("MyInvestments"), icon: Briefcase, requiresAuth: true },
  { title: "Meu Portfólio", url: createPageUrl("InvestorDashboard"), icon: TrendingUp, requiresAuth: true },
  { title: "👑 Premium", url: createPageUrl("Subscriptions"), icon: Crown, badge: "Premium", requiresAuth: true },
  { title: "Investidor Internacional", url: createPageUrl("InternationalInvestor"), icon: Globe },
  { title: "Parcerias", url: createPageUrl("Partnerships"), icon: Handshake },
  { title: "Reuniões", url: createPageUrl("Meetings"), icon: Video, requiresAuth: true },
  { title: "Educação", url: createPageUrl("Education"), icon: GraduationCap },
  { title: "Proteção Legal", url: createPageUrl("IntellectualProperty"), icon: Shield, requiresAuth: true },
  { title: "Perfil", url: createPageUrl("UserProfile"), icon: UserCircle, requiresAuth: true },
  { title: "Transparência", url: createPageUrl("Transparency"), icon: ChartBar },
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = React.useState(null);
  const [isAuthenticated, setIsAuthenticated] = React.useState(false);
  const [isLoading, setIsLoading] = React.useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const authenticated = await base44.auth.isAuthenticated();
        setIsAuthenticated(authenticated);
        
        if (authenticated) {
          const userData = await base44.auth.me();
          setUser(userData);
        }
      } catch (error) {
        console.log("User not authenticated");
        setIsAuthenticated(false);
      } finally {
        setIsLoading(false);
      }
    };
    loadUser();
  }, []);

  const handleLogout = () => {
    base44.auth.logout();
  };

  const handleNavClick = (item, e) => {
    if (item.requiresAuth && !isAuthenticated) {
      e.preventDefault();
      base44.auth.redirectToLogin(item.url);
    }
    setIsMobileMenuOpen(false);
  };

  const MobileMenu = () => (
    <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
      <SheetTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="lg:hidden hover:bg-emerald-50 rounded-lg"
        >
          <Menu className="w-6 h-6 text-gray-700" />
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-[280px] p-0">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="p-4 border-b bg-gradient-to-r from-emerald-50 to-blue-50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-blue-600 rounded-xl flex items-center justify-center">
                <Rocket className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-gray-900 text-base">Brasil Superávit</h2>
                <p className="text-xs text-gray-600">Cidades Conectadas</p>
              </div>
            </div>
          </div>

          {/* Menu Items */}
          <div className="flex-1 overflow-y-auto p-2">
            {navigationItems.map((item) => {
              const isActive = location.pathname === item.url;
              const needsAuth = item.requiresAuth && !isAuthenticated;
              const isPremium = item.badge === "Premium";
              
              return (
                <Link
                  key={item.title}
                  to={item.url}
                  onClick={(e) => handleNavClick(item, e)}
                  className={`
                    flex items-center gap-3 px-3 py-3 rounded-lg mb-1 transition-all
                    ${isActive 
                      ? 'bg-gradient-to-r from-emerald-500 to-blue-500 text-white shadow-md' 
                      : isPremium
                      ? 'bg-gradient-to-r from-amber-50 to-yellow-50 border border-amber-200 hover:from-amber-100 hover:to-yellow-100'
                      : 'hover:bg-emerald-50 text-gray-700'
                    }
                  `}
                >
                  <item.icon className={`w-5 h-5 ${isPremium && !isActive ? 'text-amber-600' : ''}`} />
                  <span className={`font-medium text-sm ${isPremium && !isActive ? 'text-amber-900' : ''}`}>
                    {item.title}
                  </span>
                  {isPremium && !isActive && (
                    <Crown className="w-4 h-4 text-amber-600 ml-auto" />
                  )}
                </Link>
              );
            })}
          </div>

          {/* User Section */}
          <div className="p-3 border-t bg-gray-50">
            {isAuthenticated && user ? (
              <div className="space-y-2">
                <div className="flex items-center gap-2 p-2 rounded-lg bg-white">
                  <Avatar className="w-8 h-8 border border-emerald-300">
                    {user.profile_photo_url ? (
                      <AvatarImage src={user.profile_photo_url} alt={user.full_name} />
                    ) : (
                      <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-blue-500 text-white text-xs font-semibold">
                        {user.full_name?.substring(0, 2).toUpperCase() || 'US'}
                      </AvatarFallback>
                    )}
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm text-gray-900 truncate">{user.full_name || 'Usuário'}</p>
                    <p className="text-xs text-gray-500 truncate">{user.email}</p>
                  </div>
                </div>
                <Button
                  onClick={handleLogout}
                  variant="outline"
                  size="sm"
                  className="w-full"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sair
                </Button>
              </div>
            ) : (
              <Button
                onClick={() => base44.auth.redirectToLogin(window.location.pathname)}
                className="w-full bg-gradient-to-r from-emerald-500 to-blue-500 text-sm"
              >
                Entrar / Cadastrar
              </Button>
            )}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );

  return (
    <div className="min-h-screen flex bg-gradient-to-br from-gray-50 via-emerald-50/30 to-blue-50/30">
      <style>
        {`
          :root {
            --primary-green: #059669;
            --primary-blue: #0284c7;
            --primary-gold: #f59e0b;
          }

          * {
            -webkit-tap-highlight-color: transparent;
          }

          body {
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
          }

          @media (max-width: 768px) {
            * {
              transition-duration: 0.15s !important;
              animation-duration: 0.15s !important;
            }
          }
        `}
      </style>

      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:flex-col w-72 bg-white border-r border-gray-200 shadow-lg">
        {/* Logo */}
        <div className="p-6 border-b bg-gradient-to-r from-emerald-50 to-blue-50">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
              <Rocket className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-gray-900 text-lg">Brasil Superávit</h2>
              <p className="text-xs text-gray-600">Cidades Conectadas</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto p-4">
          {navigationItems.map((item) => {
            const isActive = location.pathname === item.url;
            const isPremium = item.badge === "Premium";
            
            return (
              <Link
                key={item.title}
                to={item.url}
                onClick={(e) => handleNavClick(item, e)}
                className={`
                  flex items-center gap-3 px-4 py-3 rounded-xl mb-2 transition-all font-medium
                  ${isActive 
                    ? 'bg-gradient-to-r from-emerald-500 to-blue-500 text-white shadow-lg' 
                    : isPremium
                    ? 'bg-gradient-to-r from-amber-50 to-yellow-50 border-2 border-amber-200 hover:from-amber-100 hover:to-yellow-100 text-amber-900'
                    : 'hover:bg-emerald-50 text-gray-700'
                  }
                `}
              >
                <item.icon className={`w-5 h-5 ${isPremium && !isActive ? 'text-amber-600' : ''}`} />
                <span className="flex-1">{item.title}</span>
                {isPremium && !isActive && (
                  <Crown className="w-4 h-4 text-amber-600" />
                )}
              </Link>
            );
          })}
        </nav>

        {/* User Section Desktop */}
        <div className="p-4 border-t bg-gray-50">
          {isAuthenticated && user ? (
            <div className="space-y-3">
              <div className="flex items-center gap-3 p-3 rounded-xl bg-white shadow-sm">
                <Avatar className="w-10 h-10 border-2 border-emerald-300">
                  {user.profile_photo_url ? (
                    <AvatarImage src={user.profile_photo_url} alt={user.full_name} />
                  ) : (
                    <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-blue-500 text-white font-semibold">
                      {user.full_name?.substring(0, 2).toUpperCase() || 'US'}
                    </AvatarFallback>
                  )}
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm text-gray-900 truncate">{user.full_name || 'Usuário'}</p>
                  <p className="text-xs text-gray-500 truncate">{user.email}</p>
                </div>
              </div>
              <Button
                onClick={handleLogout}
                variant="outline"
                className="w-full"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sair
              </Button>
            </div>
          ) : (
            <Button
              onClick={() => base44.auth.redirectToLogin(window.location.pathname)}
              className="w-full bg-gradient-to-r from-emerald-500 to-blue-500"
            >
              Entrar / Cadastrar
            </Button>
          )}
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Header (Mobile + Desktop) */}
        <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-lg border-b border-gray-200 shadow-sm">
          <div className="flex items-center justify-between px-4 lg:px-8 py-3">
            {/* Mobile: Menu + Logo */}
            <div className="flex items-center gap-3 lg:hidden">
              <MobileMenu />
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-blue-600 rounded-lg flex items-center justify-center">
                  <Rocket className="w-4 h-4 text-white" />
                </div>
                <h1 className="text-base font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
                  Brasil Superávit
                </h1>
              </div>
            </div>

            {/* Desktop: Page Title (optional) */}
            <div className="hidden lg:block">
              <h1 className="text-xl font-bold text-gray-900">
                {currentPageName || 'Dashboard'}
              </h1>
            </div>

            {/* Right Side: Notifications + User (both mobile and desktop) */}
            <div className="flex items-center gap-3">
              {isAuthenticated && user && (
                <>
                  <NotificationBell user={user} />
                  
                  {/* Desktop User Avatar (clickable) */}
                  <div className="hidden lg:block">
                    <Link to={createPageUrl("UserProfile")}>
                      <Avatar className="w-9 h-9 border-2 border-emerald-300 cursor-pointer hover:border-emerald-500 transition-all">
                        {user.profile_photo_url ? (
                          <AvatarImage src={user.profile_photo_url} alt={user.full_name} />
                        ) : (
                          <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-blue-500 text-white font-semibold text-sm">
                            {user.full_name?.substring(0, 2).toUpperCase() || 'US'}
                          </AvatarFallback>
                        )}
                      </Avatar>
                    </Link>
                  </div>
                </>
              )}
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-x-hidden">
          {children}
        </main>
      </div>
    </div>
  );
}
