import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Lightbulb,
  DollarSign,
  Users,
  TrendingUp,
  Handshake,
  ShoppingBag,
  Target,
  Zap,
  Award,
  CheckCircle,
  ArrowRight,
  Sparkles,
  Info,
  Heart
} from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const options = [
  {
    id: "fundraising",
    title: "Captar Investimento",
    description: "Busque investidores para financiar seu projeto e fazer ele decolar",
    icon: TrendingUp,
    color: "from-emerald-500 to-emerald-600",
    benefits: [
      "Mantenha o controle do seu projeto",
      "Receba capital para crescer rapidamente",
      "Acesso a investidores nacionais e internacionais",
      "Acompanhamento transparente da captação"
    ],
    idealFor: "Projetos que precisam de capital inicial para começar ou escalar",
    minAmount: "R$ 10.000",
    action: "Criar Campanha de Captação",
    link: "CreateProject",
    example: "Startup de tecnologia limpa captou R$ 500k em 60 dias"
  },
  {
    id: "partnership",
    title: "Formar Parcerias",
    description: "Encontre sócios que tragam capital, conhecimento ou recursos",
    icon: Handshake,
    color: "from-blue-500 to-blue-600",
    benefits: [
      "Divida riscos e responsabilidades",
      "Acesso a expertise complementar",
      "Rede de contatos expandida",
      "Crescimento conjunto sustentável"
    ],
    idealFor: "Quem precisa de mais que dinheiro: experiência, contatos e trabalho conjunto",
    minAmount: "R$ 5.000 por sócio",
    action: "Buscar Parceiros",
    link: "Partnerships",
    example: "3 empreendedores criaram app de turismo dividindo 100% das tarefas"
  },
  {
    id: "sell",
    title: "Vender o Projeto/Ideia",
    description: "Transfira sua ideia ou projeto para quem tem capital para executar",
    icon: ShoppingBag,
    color: "from-purple-500 to-purple-600",
    benefits: [
      "Monetize sua ideia imediatamente",
      "Sem necessidade de gestão operacional",
      "Proteção legal da propriedade intelectual",
      "Receba valor justo pela criação"
    ],
    idealFor: "Ideias validadas mas sem tempo/recursos para executar",
    minAmount: "Valor negociável",
    action: "Anunciar para Venda",
    link: "CreateProject",
    example: "Designer vendeu conceito de app educativo por R$ 80k"
  }
];

const successCases = [
  {
    title: "App de Mobilidade Sustentável",
    amount: 350000,
    type: "fundraising",
    city: "São Paulo",
    result: "Lançado em 3 cidades, 50mil usuários"
  },
  {
    title: "Plataforma de Turismo Regional",
    amount: 120000,
    type: "partnership",
    city: "Porto Seguro",
    result: "Parceria de 4 sócios, faturamento R$ 40k/mês"
  },
  {
    title: "Sistema de Reciclagem Inteligente",
    amount: 200000,
    type: "sell",
    city: "Curitiba",
    result: "Vendido para startup de tecnologia limpa"
  }
];

const OptionCard = ({ option }) => {
  const Icon = option.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -8 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="border-none shadow-2xl h-full hover:shadow-3xl transition-all duration-300 overflow-hidden">
        <div className={`h-2 bg-gradient-to-r ${option.color}`} />
        <CardHeader className="pb-4">
          <div className={`inline-block p-4 rounded-2xl bg-gradient-to-br ${option.color} shadow-lg mb-4`}>
            <Icon className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl mb-2">{option.title}</CardTitle>
          <p className="text-gray-600">{option.description}</p>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-3">
            <p className="text-sm font-semibold text-gray-700">Benefícios:</p>
            {option.benefits.map((benefit, index) => (
              <div key={index} className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                <span className="text-sm text-gray-700">{benefit}</span>
              </div>
            ))}
          </div>

          <Alert className="border-blue-200 bg-blue-50">
            <Info className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-sm text-blue-900">
              <strong>Ideal para:</strong> {option.idealFor}
            </AlertDescription>
          </Alert>

          <div className="p-4 bg-gray-50 rounded-lg">
            <p className="text-xs text-gray-500 mb-1">Valor mínimo</p>
            <p className="text-xl font-bold text-gray-900">{option.minAmount}</p>
          </div>

          <div className="p-3 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border border-emerald-200">
            <p className="text-xs text-emerald-700 font-semibold mb-1">✨ Caso de Sucesso</p>
            <p className="text-sm text-emerald-900">{option.example}</p>
          </div>

          <Link to={createPageUrl(option.link)}>
            <Button className={`w-full h-12 bg-gradient-to-r ${option.color} hover:shadow-lg transition-all`}>
              {option.action}
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default function FundingOptions() {
  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-emerald-50/30 via-blue-50/30 to-purple-50/30">
      <div className="max-w-7xl mx-auto">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12 text-center"
        >
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-emerald-500 via-blue-500 to-purple-500 mb-6 shadow-2xl">
            <Lightbulb className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-emerald-600 via-blue-600 to-purple-600 bg-clip-text text-transparent">
            Você Tem a Ideia. Nós Temos as Soluções.
          </h1>
          <p className="text-2xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Não deixe a falta de capital parar seu projeto. Escolha a melhor forma de tirar sua ideia do papel.
          </p>
        </motion.div>

        {/* Problem Statement */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mb-16"
        >
          <Card className="border-none shadow-2xl overflow-hidden">
            <div className="h-2 bg-gradient-to-r from-red-500 via-orange-500 to-yellow-500" />
            <CardContent className="p-8 md:p-12">
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div>
                  <h2 className="text-3xl font-bold text-gray-900 mb-4 flex items-center gap-3">
                    <Heart className="w-8 h-8 text-red-500" />
                    O Problema
                  </h2>
                  <p className="text-lg text-gray-700 leading-relaxed mb-4">
                    Você tem uma <strong>ideia brilhante</strong>, um projeto que pode mudar sua cidade, gerar empregos e impacto social positivo.
                  </p>
                  <p className="text-lg text-gray-700 leading-relaxed">
                    Mas falta o <strong>capital inicial</strong> para tirar do papel. E agora?
                  </p>
                </div>
                <div className="p-8 bg-gradient-to-br from-red-50 to-orange-50 rounded-2xl border-2 border-red-200">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-red-500 flex items-center justify-center">
                        <span className="text-white font-bold text-xl">!</span>
                      </div>
                      <div>
                        <p className="font-bold text-gray-900">Sem dinheiro para começar</p>
                        <p className="text-sm text-gray-600">Capital inicial limitado</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-orange-500 flex items-center justify-center">
                        <span className="text-white font-bold text-xl">!</span>
                      </div>
                      <div>
                        <p className="font-bold text-gray-900">Sem sócios ou parceiros</p>
                        <p className="text-sm text-gray-600">Precisa de ajuda especializada</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-yellow-500 flex items-center justify-center">
                        <span className="text-white font-bold text-xl">!</span>
                      </div>
                      <div>
                        <p className="font-bold text-gray-900">Sem tempo para executar</p>
                        <p className="text-sm text-gray-600">Outras prioridades na vida</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Solutions */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="mb-16"
        >
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4 flex items-center justify-center gap-3">
              <Sparkles className="w-10 h-10 text-yellow-500" />
              3 Soluções para Você
            </h2>
            <p className="text-xl text-gray-600">Escolha a que melhor se adapta ao seu momento</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {options.map((option, index) => (
              <OptionCard key={option.id} option={option} />
            ))}
          </div>
        </motion.div>

        {/* Success Cases */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mb-16"
        >
          <Card className="border-none shadow-2xl">
            <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
              <CardTitle className="text-3xl flex items-center gap-3">
                <Award className="w-8 h-8 text-emerald-600" />
                Casos Reais de Sucesso
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8">
              <div className="grid md:grid-cols-3 gap-6">
                {successCases.map((case_, index) => (
                  <div key={index} className="p-6 rounded-xl bg-gradient-to-br from-gray-50 to-white border-2 border-gray-200 hover:border-emerald-400 transition-all">
                    <h3 className="font-bold text-gray-900 mb-2">{case_.title}</h3>
                    <p className="text-sm text-gray-600 mb-3">{case_.city}</p>
                    <div className="p-3 bg-emerald-50 rounded-lg mb-3">
                      <p className="text-xs text-emerald-700">Valor</p>
                      <p className="text-2xl font-bold text-emerald-900">
                        R$ {case_.amount.toLocaleString('pt-BR')}
                      </p>
                    </div>
                    <p className="text-sm text-gray-700">
                      <strong>Resultado:</strong> {case_.result}
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="text-center"
        >
          <Card className="border-none shadow-2xl overflow-hidden">
            <div className="bg-gradient-to-r from-emerald-600 via-blue-600 to-purple-600 p-12 text-white">
              <h2 className="text-4xl font-bold mb-4">Pronto para Começar?</h2>
              <p className="text-xl mb-8 text-white/90">
                Escolha sua estratégia e tire seu projeto do papel hoje mesmo
              </p>
              <div className="flex flex-wrap gap-4 justify-center">
                <Link to={createPageUrl("CreateProject")}>
                  <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-6 text-lg">
                    <Rocket className="w-6 h-6 mr-2" />
                    Criar Meu Projeto
                  </Button>
                </Link>
                <Link to={createPageUrl("Projects")}>
                  <Button size="lg" variant="outline" className="bg-transparent border-2 border-white text-white hover:bg-white/10 px-8 py-6 text-lg">
                    <Target className="w-6 h-6 mr-2" />
                    Ver Projetos Ativos
                  </Button>
                </Link>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}