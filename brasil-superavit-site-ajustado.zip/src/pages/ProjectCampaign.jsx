import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  TrendingUp,
  Users,
  DollarSign,
  Calendar,
  Target,
  CheckCircle,
  Share2,
  BarChart3,
  Award,
  Rocket,
  Clock,
  Globe
} from "lucide-react";
import { motion } from "framer-motion";
import { format, formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ProjectCampaign() {
  const [user, setUser] = useState(null);
  const urlParams = new URLSearchParams(window.location.search);
  const projectId = urlParams.get('id');

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  const { data: project } = useQuery({
    queryKey: ['project', projectId],
    queryFn: async () => {
      const projects = await base44.entities.Project.list();
      return projects.find(p => p.id === projectId);
    },
    enabled: !!projectId,
  });

  const { data: investments = [] } = useQuery({
    queryKey: ['project-investments', projectId],
    queryFn: () => base44.entities.Investment.filter({ 
      project_id: projectId,
      status: 'confirmado'
    }, '-created_date'),
    enabled: !!projectId,
  });

  if (!project) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
      </div>
    );
  }

  const progress = (project.current_funding / project.funding_goal) * 100;
  const maxTarget = project.funding_goal * 1.25; // 125% do objetivo
  const totalRequests = investments.reduce((sum, inv) => sum + inv.amount, 0);
  const requestsProgress = (totalRequests / project.funding_goal) * 100;
  const daysLeft = project.end_date 
    ? Math.max(0, Math.ceil((new Date(project.end_date) - new Date()) / (1000 * 60 * 60 * 24)))
    : 0;

  const recentInvestors = investments.slice(0, 10);

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-emerald-50/30 to-blue-50/30">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <Badge className="mb-3 bg-gradient-to-r from-emerald-500 to-blue-500 text-white">
                Campanha Ativa
              </Badge>
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-2">
                {project.title}
              </h1>
              <p className="text-lg text-gray-600">
                {project.city}/{project.state} • {project.sector}
              </p>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" size="lg">
                <Share2 className="w-4 h-4 mr-2" />
                Compartilhar
              </Button>
              <Link to={createPageUrl(`Invest?project=${project.id}`)}>
                <Button size="lg" className="bg-gradient-to-r from-emerald-500 to-blue-500 shadow-lg">
                  <DollarSign className="w-5 h-5 mr-2" />
                  Investir Agora
                </Button>
              </Link>
            </div>
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Campaign Progress */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Card className="border-none shadow-2xl overflow-hidden">
                <div className="h-2 bg-gradient-to-r from-emerald-500 to-blue-500" />
                <CardContent className="p-8">
                  <div className="mb-6">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-sm font-semibold text-gray-600">Total Investido</h3>
                      <span className="text-3xl font-bold text-emerald-600">
                        {progress.toFixed(0)}%
                      </span>
                    </div>
                    <Progress value={progress} className="h-4 mb-2" />
                    <div className="flex justify-between text-sm text-gray-500">
                      <span>R$ 0</span>
                      <span>R$ {project.funding_goal.toLocaleString('pt-BR')}</span>
                      <span>R$ {maxTarget.toLocaleString('pt-BR')}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-6 mb-6">
                    <div className="text-center p-4 bg-emerald-50 rounded-xl">
                      <p className="text-xs text-emerald-700 mb-1">Arrecadado</p>
                      <p className="text-2xl font-bold text-emerald-900">
                        R$ {project.current_funding.toLocaleString('pt-BR')}
                      </p>
                    </div>
                    <div className="text-center p-4 bg-blue-50 rounded-xl">
                      <p className="text-xs text-blue-700 mb-1">Objetivo</p>
                      <p className="text-2xl font-bold text-blue-900">
                        R$ {project.funding_goal.toLocaleString('pt-BR')}
                      </p>
                    </div>
                    <div className="text-center p-4 bg-purple-50 rounded-xl">
                      <p className="text-xs text-purple-700 mb-1">Máximo</p>
                      <p className="text-2xl font-bold text-purple-900">
                        R$ {maxTarget.toLocaleString('pt-BR')}
                      </p>
                    </div>
                  </div>

                  <div className="mb-6">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-sm font-semibold text-gray-600">Pedidos de Investimento</h3>
                      <span className="text-lg font-bold text-blue-600">
                        {requestsProgress.toFixed(0)}%
                      </span>
                    </div>
                    <Progress value={requestsProgress} className="h-3" />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                      {progress >= 100 ? (
                        <CheckCircle className="w-8 h-8 text-emerald-600" />
                      ) : (
                        <Target className="w-8 h-8 text-blue-600" />
                      )}
                      <div>
                        <p className="text-2xl font-bold text-gray-900">
                          {progress >= 100 ? (
                            <span className="text-emerald-600">✅ {progress.toFixed(0)}%</span>
                          ) : (
                            `${progress.toFixed(0)}%`
                          )}
                        </p>
                        <p className="text-xs text-gray-500">investido</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                      {requestsProgress >= 100 ? (
                        <CheckCircle className="w-8 h-8 text-blue-600" />
                      ) : (
                        <Users className="w-8 h-8 text-purple-600" />
                      )}
                      <div>
                        <p className="text-2xl font-bold text-gray-900">
                          {requestsProgress >= 100 ? (
                            <span className="text-blue-600">✅ {requestsProgress.toFixed(0)}%</span>
                          ) : (
                            `${requestsProgress.toFixed(0)}%`
                          )}
                        </p>
                        <p className="text-xs text-gray-500">de pedidos</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Project Details */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card className="border-none shadow-xl">
                <CardHeader>
                  <CardTitle>Sobre o Projeto</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-700 leading-relaxed">{project.description}</p>
                  
                  {project.expected_impact && (
                    <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-200">
                      <h4 className="font-semibold text-emerald-900 mb-2">Impacto Esperado</h4>
                      <p className="text-sm text-emerald-800">{project.expected_impact}</p>
                    </div>
                  )}

                  {project.budget_details && (
                    <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                      <h4 className="font-semibold text-blue-900 mb-2">Uso do Investimento</h4>
                      <p className="text-sm text-blue-800">{project.budget_details}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Recent Investors */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Card className="border-none shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-6 h-6 text-blue-600" />
                    Investidores Recentes
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {recentInvestors.length > 0 ? (
                    <div className="space-y-3">
                      {recentInvestors.map((investment, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500 to-blue-500 flex items-center justify-center text-white font-bold">
                              {investment.investor_name?.substring(0, 2).toUpperCase()}
                            </div>
                            <div>
                              <p className="font-semibold text-gray-900">{investment.investor_name}</p>
                              <p className="text-xs text-gray-500">
                                {format(new Date(investment.created_date), "dd MMM yyyy", { locale: ptBR })}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-emerald-600">
                              R$ {investment.amount.toLocaleString('pt-BR')}
                            </p>
                            <Badge variant="outline" className="text-xs">
                              {investment.category}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-center text-gray-500 py-8">
                      Seja o primeiro investidor!
                    </p>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Stats */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card className="border-none shadow-xl">
                <CardContent className="p-6 space-y-4">
                  <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-lg">
                    <Users className="w-8 h-8 text-blue-600" />
                    <div>
                      <p className="text-2xl font-bold text-gray-900">{project.investors_count}</p>
                      <p className="text-sm text-gray-600">Investidores</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-4 bg-purple-50 rounded-lg">
                    <Clock className="w-8 h-8 text-purple-600" />
                    <div>
                      <p className="text-2xl font-bold text-gray-900">{daysLeft}</p>
                      <p className="text-sm text-gray-600">Dias restantes</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-4 bg-emerald-50 rounded-lg">
                    <DollarSign className="w-8 h-8 text-emerald-600" />
                    <div>
                      <p className="text-lg font-bold text-gray-900">
                        R$ {project.minimum_investment.toLocaleString('pt-BR')}
                      </p>
                      <p className="text-sm text-gray-600">Investimento mínimo</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Campaign Info */}
            <Card className="border-none shadow-xl">
              <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                <CardTitle className="text-lg">Informações da Campanha</CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="w-4 h-4 text-gray-500" />
                  <div>
                    <p className="text-xs text-gray-500">Início</p>
                    <p className="font-semibold text-gray-900">
                      {format(new Date(project.start_date), "dd MMM yyyy", { locale: ptBR })}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="w-4 h-4 text-gray-500" />
                  <div>
                    <p className="text-xs text-gray-500">Término</p>
                    <p className="font-semibold text-gray-900">
                      {format(new Date(project.end_date), "dd MMM yyyy", { locale: ptBR })}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* CTA */}
            <Card className="border-none shadow-xl overflow-hidden">
              <div className="bg-gradient-to-r from-emerald-600 to-blue-600 p-6 text-white text-center">
                <Award className="w-12 h-12 mx-auto mb-3" />
                <h3 className="font-bold text-xl mb-2">Faça Parte!</h3>
                <p className="text-sm text-white/90 mb-4">
                  Invista e ajude a transformar {project.city}
                </p>
                <Link to={createPageUrl(`Invest?project=${project.id}`)}>
                  <Button size="lg" className="w-full bg-white text-blue-600 hover:bg-gray-100">
                    <Rocket className="w-5 h-5 mr-2" />
                    Investir Agora
                  </Button>
                </Link>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}