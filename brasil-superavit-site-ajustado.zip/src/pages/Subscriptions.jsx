import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  CreditCard, 
  CheckCircle, 
  Star, 
  Zap, 
  Shield,
  Globe,
  TrendingUp,
  Users,
  Sparkles,
  Crown,
  DollarSign,
  Info,
  Lock,
  Banknote,
  Gift,
  Clock,
  Percent,
  Check,
  Loader2,
  AlertTriangle,
  Building2,
  ExternalLink,
  Smartphone,
  Mail,
  Phone,
  Copy
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

const SUBSCRIPTION_PLANS = {
  monthly: {
    BRL: { amount: 50.00, symbol: "R$", period: "mês" },
    USD: { amount: 9.30, symbol: "$", period: "month" },
    EUR: { amount: 8.50, symbol: "€", period: "month" }
  },
  yearly: {
    BRL: { amount: 528.00, symbol: "R$", period: "ano", monthlyEquivalent: 44.00, discount: 12 },
    USD: { amount: 99.00, symbol: "$", period: "year", monthlyEquivalent: 8.25, discount: 11 },
    EUR: { amount: 91.00, symbol: "€", period: "year", monthlyEquivalent: 7.58, discount: 11 }
  }
};

const CURRENCY_COUNTRIES = {
  USD: { name: "USD", country: "Internacional", flag: "🌎" },
  EUR: { name: "EUR", country: "Europa", flag: "🇪🇺" },
  BRL: { name: "BRL", country: "Brasil", flag: "🇧🇷" }
};

const FREE_TRIAL_DAYS = 7;

const BENEFITS = [
  { icon: Zap, text: "Acesso prioritário a novos projetos", color: "text-yellow-600", bgColor: "bg-yellow-50" },
  { icon: TrendingUp, text: "Dashboard de análise avançado", color: "text-blue-600", bgColor: "bg-blue-50" },
  { icon: Shield, text: "Proteção legal premium", color: "text-emerald-600", bgColor: "bg-emerald-50" },
  { icon: Users, text: "Networking exclusivo", color: "text-purple-600", bgColor: "bg-purple-50" },
  { icon: Sparkles, text: "IA para recomendações", color: "text-pink-600", bgColor: "bg-pink-50" },
  { icon: Crown, text: "Badge de membro premium", color: "text-amber-600", bgColor: "bg-amber-50" },
  { icon: Globe, text: "Feed internacional", color: "text-cyan-600", bgColor: "bg-cyan-50" },
  { icon: Star, text: "Suporte 24/7", color: "text-orange-600", bgColor: "bg-orange-50" }
];

const PAYMENT_CONTACT_INFO = {
  email: "suporte@brasilsuperavit.com.br",
  whatsapp: "+55 11 99999-9999",
  bank: {
    name: "Banco do Brasil",
    code: "001",
    agency: "1234-5",
    account: "98765-4",
    cnpj: "12.345.678/0001-90",
    holder: "Brasil Superávit Ltda"
  },
  pix: {
    type: "CNPJ",
    key: "12.345.678/0001-90"
  }
};

const detectUserCurrency = (userLocation, userNationality) => {
  const location = (userLocation || userNationality || "").toLowerCase();
  
  if (location.includes('brasil') || location.includes('brazil')) return 'BRL';
  if (location.includes('europa') || location.includes('europe') || 
      location.includes('portugal') || location.includes('espanha') || 
      location.includes('italia') || location.includes('frança')) return 'EUR';
  
  return 'USD';
};

const PaymentMethodsModal = ({ open, onClose, planType, currency, amount, user }) => {
  const [selectedMethod, setSelectedMethod] = useState("transfer");
  const [copied, setCopied] = useState(false);

  const currentPrice = SUBSCRIPTION_PLANS[planType][currency];

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    toast.success("Copiado para área de transferência!");
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
            Método de Pagamento
          </DialogTitle>
          <DialogDescription className="text-lg">
            <div className="flex flex-wrap items-center gap-2 mt-2">
              <span>Plano: <strong className="text-purple-600">{planType === 'monthly' ? 'Mensal' : 'Anual'}</strong></span>
              <span className="text-gray-400">|</span>
              <span>Valor: <strong className="text-emerald-600">{currentPrice.symbol}{currentPrice.amount.toFixed(2)}/{currentPrice.period}</strong></span>
              <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white border-none">
                <Gift className="w-4 h-4 mr-1" />
                {FREE_TRIAL_DAYS} dias GRÁTIS
              </Badge>
              {planType === 'yearly' && (
                <Badge className="bg-gradient-to-r from-emerald-400 to-green-500 text-white border-none">
                  <Percent className="w-4 h-4 mr-1" />
                  -{currentPrice.discount}%
                </Badge>
              )}
            </div>
          </DialogDescription>
        </DialogHeader>

        <Alert className="border-yellow-300 bg-gradient-to-r from-yellow-50 to-orange-50">
          <Gift className="h-5 w-5 text-yellow-600" />
          <AlertDescription className="text-yellow-900">
            <strong>🎁 OFERTA ESPECIAL:</strong> {FREE_TRIAL_DAYS} dias GRÁTIS para testar todas as funcionalidades!
            {planType === 'yearly' && (
              <span className="font-bold text-emerald-700 block mt-1">
                💰 + Economize {currentPrice.discount}% no plano anual!
              </span>
            )}
          </AlertDescription>
        </Alert>

        <Tabs value={selectedMethod} onValueChange={setSelectedMethod} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="transfer" className="gap-2">
              <Banknote className="w-4 h-4" />
              Transferência/PIX
            </TabsTrigger>
            <TabsTrigger value="contact" className="gap-2">
              <Phone className="w-4 h-4" />
              Falar com Suporte
            </TabsTrigger>
          </TabsList>

          {/* Transferência/PIX Tab */}
          <TabsContent value="transfer" className="space-y-6">
            <Card className="border-emerald-200 bg-gradient-to-br from-emerald-50 to-green-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-emerald-900">
                  <Smartphone className="w-6 h-6 text-emerald-600" />
                  Pagamento via PIX (Recomendado)
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert className="border-blue-200 bg-blue-50">
                  <Sparkles className="h-5 w-5 text-blue-600" />
                  <AlertDescription className="text-blue-900">
                    <strong>✨ Mais Rápido!</strong> Pagamento instantâneo e ativação em minutos.
                  </AlertDescription>
                </Alert>

                <div className="bg-white p-6 rounded-xl border-2 border-emerald-200 space-y-4">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm font-semibold text-gray-700">Tipo de Chave:</span>
                    <span className="text-sm text-gray-900">{PAYMENT_CONTACT_INFO.pix.type}</span>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-gradient-to-r from-emerald-100 to-green-100 rounded-lg border-2 border-emerald-300">
                    <div className="flex-1">
                      <p className="text-xs text-emerald-700 mb-1">Chave PIX:</p>
                      <p className="text-lg font-bold text-emerald-900 font-mono">
                        {PAYMENT_CONTACT_INFO.pix.key}
                      </p>
                    </div>
                    <Button
                      onClick={() => copyToClipboard(PAYMENT_CONTACT_INFO.pix.key)}
                      variant="outline"
                      size="sm"
                      className="ml-3"
                    >
                      {copied ? <Check className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm font-semibold text-gray-700">Valor:</span>
                    <span className="text-xl font-bold text-gray-900">
                      {currentPrice.symbol} {currentPrice.amount.toFixed(2)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm font-semibold text-gray-700">Beneficiário:</span>
                    <span className="text-sm text-gray-900">{PAYMENT_CONTACT_INFO.bank.holder}</span>
                  </div>
                </div>

                <Alert className="border-yellow-200 bg-yellow-50">
                  <Clock className="h-5 w-5 text-yellow-600" />
                  <AlertDescription className="text-yellow-900 text-sm">
                    <strong>⏱️ Após o Pagamento:</strong> Envie o comprovante para <strong>{PAYMENT_CONTACT_INFO.email}</strong> com seu email cadastrado. Ativação em até 2 horas úteis.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>

            <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-indigo-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-blue-900">
                  <Building2 className="w-6 h-6 text-blue-600" />
                  Transferência Bancária
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-white p-6 rounded-xl border-2 border-blue-200 space-y-3">
                  <h4 className="font-bold text-gray-900 mb-4">Dados Bancários:</h4>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 bg-gray-50 rounded-lg">
                      <p className="text-xs text-gray-600 mb-1">Banco:</p>
                      <p className="font-semibold text-gray-900">{PAYMENT_CONTACT_INFO.bank.name} ({PAYMENT_CONTACT_INFO.bank.code})</p>
                    </div>
                    
                    <div className="p-3 bg-gray-50 rounded-lg">
                      <p className="text-xs text-gray-600 mb-1">Agência:</p>
                      <p className="font-semibold text-gray-900">{PAYMENT_CONTACT_INFO.bank.agency}</p>
                    </div>
                    
                    <div className="p-3 bg-gray-50 rounded-lg">
                      <p className="text-xs text-gray-600 mb-1">Conta:</p>
                      <p className="font-semibold text-gray-900">{PAYMENT_CONTACT_INFO.bank.account}</p>
                    </div>
                    
                    <div className="p-3 bg-gray-50 rounded-lg">
                      <p className="text-xs text-gray-600 mb-1">Titular:</p>
                      <p className="font-semibold text-gray-900 text-sm">{PAYMENT_CONTACT_INFO.bank.holder}</p>
                    </div>
                  </div>

                  <div className="p-3 bg-gray-50 rounded-lg mt-3">
                    <p className="text-xs text-gray-600 mb-1">CNPJ:</p>
                    <p className="font-semibold text-gray-900">{PAYMENT_CONTACT_INFO.bank.cnpj}</p>
                  </div>

                  <div className="p-4 bg-gradient-to-r from-blue-100 to-indigo-100 rounded-lg border-2 border-blue-300 mt-4">
                    <p className="text-xs text-blue-700 mb-1">Valor a Transferir:</p>
                    <p className="text-2xl font-bold text-blue-900">
                      {currentPrice.symbol} {currentPrice.amount.toFixed(2)}
                    </p>
                  </div>
                </div>

                <Alert className="border-yellow-200 bg-yellow-50">
                  <Clock className="h-5 w-5 text-yellow-600" />
                  <AlertDescription className="text-yellow-900 text-sm">
                    <strong>⏱️ Importante:</strong> Transferências bancárias podem levar 1-2 dias úteis para compensar.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>

            <div className="p-6 bg-gradient-to-r from-emerald-50 to-blue-50 rounded-xl border-2 border-emerald-200">
              <h4 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-600" />
                Próximos Passos:
              </h4>
              <ol className="space-y-2 text-sm text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="font-bold text-emerald-600 flex-shrink-0">1.</span>
                  <span>Faça o pagamento via PIX ou transferência</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-bold text-emerald-600 flex-shrink-0">2.</span>
                  <span>Envie o comprovante para: <strong className="text-emerald-700">{PAYMENT_CONTACT_INFO.email}</strong></span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-bold text-emerald-600 flex-shrink-0">3.</span>
                  <span>Inclua seu email cadastrado: <strong className="text-purple-700">{user?.email}</strong></span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-bold text-emerald-600 flex-shrink-0">4.</span>
                  <span>Aguarde a confirmação (até 2 horas úteis para PIX, 1-2 dias para TED)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-bold text-emerald-600 flex-shrink-0">5.</span>
                  <span>Comece seu período de teste GRÁTIS de {FREE_TRIAL_DAYS} dias! 🎉</span>
                </li>
              </ol>
            </div>
          </TabsContent>

          {/* Contato Tab */}
          <TabsContent value="contact" className="space-y-6">
            <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-purple-900">
                  <Phone className="w-6 h-6 text-purple-600" />
                  Fale com Nossa Equipe
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <Alert className="border-purple-200 bg-white">
                  <Users className="h-5 w-5 text-purple-600" />
                  <AlertDescription className="text-purple-900">
                    <strong>🤝 Atendimento Personalizado:</strong> Nossa equipe está pronta para ajudar você com dúvidas sobre pagamento, planos e funcionalidades.
                  </AlertDescription>
                </Alert>

                <div className="space-y-4">
                  <a
                    href={`https://wa.me/${PAYMENT_CONTACT_INFO.whatsapp.replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block"
                  >
                    <div className="p-6 bg-white rounded-xl border-2 border-green-300 hover:border-green-500 transition-all cursor-pointer hover:shadow-lg">
                      <div className="flex items-center gap-4">
                        <div className="p-4 rounded-full bg-green-100">
                          <Phone className="w-8 h-8 text-green-600" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-bold text-gray-900 text-lg mb-1">WhatsApp</h4>
                          <p className="text-green-600 font-semibold text-xl">{PAYMENT_CONTACT_INFO.whatsapp}</p>
                          <p className="text-sm text-gray-600 mt-1">Resposta rápida • Disponível 24/7</p>
                        </div>
                        <ExternalLink className="w-5 h-5 text-gray-400" />
                      </div>
                    </div>
                  </a>

                  <a
                    href={`mailto:${PAYMENT_CONTACT_INFO.email}`}
                    className="block"
                  >
                    <div className="p-6 bg-white rounded-xl border-2 border-blue-300 hover:border-blue-500 transition-all cursor-pointer hover:shadow-lg">
                      <div className="flex items-center gap-4">
                        <div className="p-4 rounded-full bg-blue-100">
                          <Mail className="w-8 h-8 text-blue-600" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-bold text-gray-900 text-lg mb-1">Email</h4>
                          <p className="text-blue-600 font-semibold">{PAYMENT_CONTACT_INFO.email}</p>
                          <p className="text-sm text-gray-600 mt-1">Envie seu comprovante aqui</p>
                        </div>
                        <ExternalLink className="w-5 h-5 text-gray-400" />
                      </div>
                    </div>
                  </a>
                </div>

                <div className="p-6 bg-white rounded-xl border-2 border-gray-200">
                  <h4 className="font-bold text-gray-900 mb-4">💬 O que nossa equipe pode fazer por você:</h4>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">Esclarecer dúvidas sobre os planos e benefícios</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">Ajudar com o processo de pagamento</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">Processar seu pagamento manualmente</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">Oferecer planos personalizados para empresas</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">Ativar sua assinatura imediatamente</span>
                    </li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex items-center justify-end gap-3 pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Voltar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default function Subscriptions() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCurrency, setSelectedCurrency] = useState('USD');
  const [selectedPlan, setSelectedPlan] = useState('yearly');
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const isAuthenticated = await base44.auth.isAuthenticated();
        
        if (!isAuthenticated) {
          base44.auth.redirectToLogin(window.location.pathname);
          return;
        }

        const userData = await base44.auth.me();
        setUser(userData);
        
        const detectedCurrency = detectUserCurrency(userData.location, userData.nationality);
        setSelectedCurrency(detectedCurrency);
        
        setIsLoading(false);
      } catch (error) {
        console.error("Auth error:", error);
        base44.auth.redirectToLogin(window.location.pathname);
      }
    };
    loadUser();
  }, []);

  const { data: subscription } = useQuery({
    queryKey: ['subscription', user?.email],
    queryFn: async () => {
      const subs = await base44.entities.Subscription.filter({ 
        user_email: user?.email 
      });
      return subs[0] || null;
    },
    enabled: !!user?.email
  });

  const hasActiveSubscription = subscription && (subscription.status === 'authorized' || subscription.status === 'pending');

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50/50 to-blue-50/50">
        <Card className="p-12 max-w-md">
          <div className="text-center space-y-4">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 animate-pulse">
              <Lock className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900">Carregando...</h2>
          </div>
        </Card>
      </div>
    );
  }

  const monthlyPrice = SUBSCRIPTION_PLANS.monthly[selectedCurrency];
  const yearlyPrice = SUBSCRIPTION_PLANS.yearly[selectedCurrency];
  
  const yearlyTotalMonthly = monthlyPrice.amount * 12;
  const yearlySavings = yearlyTotalMonthly - yearlyPrice.amount;

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-purple-50/50 via-blue-50/50 to-emerald-50/50">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-500 via-blue-500 to-emerald-500 shadow-2xl">
              <Crown className="w-12 h-12 text-white" />
            </div>
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-3">
                <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-600 via-blue-600 to-emerald-600 bg-clip-text text-transparent">
                  Premium
                </h1>
                <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white border-none text-lg px-5 py-2 animate-pulse shadow-lg">
                  <Gift className="w-5 h-5 mr-2" />
                  {FREE_TRIAL_DAYS} DIAS GRÁTIS!
                </Badge>
              </div>
              <p className="text-lg text-gray-600 mt-2">
                Desbloqueie todo o potencial da plataforma
              </p>
            </div>
          </div>
        </motion.div>

        {/* Free Trial Banner */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }}>
          <Alert className="mb-8 border-2 border-yellow-300 bg-gradient-to-r from-yellow-50 via-orange-50 to-yellow-50 shadow-xl">
            <Gift className="h-7 w-7 text-yellow-600" />
            <AlertDescription className="text-yellow-900 text-lg">
              <strong className="block mb-2 text-2xl">🎁 TESTE GRÁTIS POR {FREE_TRIAL_DAYS} DIAS!</strong>
              <p className="mb-2">✨ Experimente todos os benefícios Premium <strong>sem compromisso</strong></p>
              <p className="text-sm">💡 Cancele quando quiser • Sem taxas ocultas • Sem burocracia</p>
            </AlertDescription>
          </Alert>
        </motion.div>

        {/* Currency Selector */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mb-8">
          <Card className="border-none shadow-2xl bg-gradient-to-r from-blue-50 to-purple-50 overflow-hidden">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <Globe className="w-7 h-7 text-blue-600" />
                <h3 className="text-2xl font-bold text-gray-900">Escolha sua Moeda</h3>
              </div>
              <div className="grid grid-cols-3 gap-4">
                {Object.entries(CURRENCY_COUNTRIES).map(([currency, data]) => (
                  <motion.div 
                    key={currency} 
                    whileHover={{ scale: 1.05 }} 
                    whileTap={{ scale: 0.95 }}
                  >
                    <button 
                      onClick={() => setSelectedCurrency(currency)} 
                      className={`w-full p-6 rounded-2xl border-3 transition-all ${
                        selectedCurrency === currency 
                          ? 'border-purple-500 bg-purple-50 shadow-2xl scale-105' 
                          : 'border-gray-200 hover:border-purple-300 bg-white'
                      }`}
                    >
                      <div className="text-center">
                        <div className="text-5xl mb-3">{data.flag}</div>
                        <p className="text-2xl font-bold text-gray-900 mb-2">
                          {SUBSCRIPTION_PLANS.monthly[currency].symbol}
                        </p>
                        <p className="text-sm font-semibold text-gray-700 mb-1">{data.name}</p>
                        <p className="text-xs text-gray-500">{data.country}</p>
                        {selectedCurrency === currency && (
                          <CheckCircle className="w-6 h-6 text-purple-600 mx-auto mt-3" />
                        )}
                      </div>
                    </button>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Plan Comparison */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="mb-8">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Monthly Plan */}
            <motion.div
              whileHover={{ scale: 1.02 }}
              onClick={() => setSelectedPlan('monthly')}
            >
              <Card className={`border-3 transition-all cursor-pointer h-full ${
                selectedPlan === 'monthly' 
                  ? 'border-blue-500 shadow-2xl scale-105' 
                  : 'border-gray-200 hover:border-blue-300'
              }`}>
                <div className="h-3 bg-gradient-to-r from-blue-400 to-indigo-500" />
                <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 pb-8">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <CardTitle className="text-3xl font-bold text-gray-900 mb-2">Mensal</CardTitle>
                      <p className="text-gray-600">Flexibilidade total</p>
                    </div>
                    {selectedPlan === 'monthly' && (
                      <Badge className="bg-blue-500 text-white text-lg px-4 py-2">
                        <Check className="w-5 h-5 mr-1" />
                        Selecionado
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-6xl font-bold text-gray-900">
                      {monthlyPrice.symbol}{monthlyPrice.amount.toFixed(0)}
                    </span>
                    <span className="text-2xl text-gray-600">/{monthlyPrice.period}</span>
                  </div>
                  <p className="text-sm text-gray-500 mt-3">Cobrado mensalmente • Cancele quando quiser</p>
                </CardHeader>
                <CardContent className="p-8">
                  <div className="space-y-4">
                    {BENEFITS.slice(0, 4).map((benefit, idx) => (
                      <div key={idx} className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${benefit.bgColor}`}>
                          <benefit.icon className={`w-5 h-5 ${benefit.color}`} />
                        </div>
                        <span className="text-gray-700">{benefit.text}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Yearly Plan */}
            <motion.div
              whileHover={{ scale: 1.02 }}
              onClick={() => setSelectedPlan('yearly')}
            >
              <Card className={`border-3 transition-all cursor-pointer relative overflow-hidden h-full ${
                selectedPlan === 'yearly' 
                  ? 'border-emerald-500 shadow-2xl scale-105' 
                  : 'border-gray-200 hover:border-emerald-300'
              }`}>
                <div className="absolute top-6 right-6 z-10">
                  <Badge className="bg-gradient-to-r from-emerald-500 to-green-500 text-white text-xl px-6 py-3 shadow-2xl animate-pulse">
                    <Sparkles className="w-6 h-6 mr-2" />
                    -{yearlyPrice.discount}% OFF
                  </Badge>
                </div>
                <div className="h-3 bg-gradient-to-r from-emerald-400 via-green-500 to-emerald-600" />
                <CardHeader className="bg-gradient-to-r from-emerald-50 to-green-50 pb-8">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <CardTitle className="text-3xl font-bold text-gray-900 mb-2">Anual</CardTitle>
                      <p className="text-emerald-700 font-bold">🏆 Melhor Valor!</p>
                    </div>
                    {selectedPlan === 'yearly' && (
                      <Badge className="bg-emerald-500 text-white text-lg px-4 py-2">
                        <Check className="w-5 h-5 mr-1" />
                        Selecionado
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-baseline gap-2 mb-4">
                    <span className="text-6xl font-bold text-gray-900">
                      {yearlyPrice.symbol}{yearlyPrice.amount.toFixed(0)}
                    </span>
                    <span className="text-2xl text-gray-600">/{yearlyPrice.period}</span>
                  </div>
                  <div className="p-4 bg-emerald-100 rounded-xl border-2 border-emerald-300">
                    <p className="text-sm font-bold text-emerald-900 mb-1">
                      💰 Apenas {yearlyPrice.symbol}{yearlyPrice.monthlyEquivalent.toFixed(2)}/mês
                    </p>
                    <p className="text-xs text-emerald-700">
                      Economize {yearlyPrice.symbol}{yearlySavings.toFixed(2)} por ano!
                    </p>
                  </div>
                </CardHeader>
                <CardContent className="p-8">
                  <div className="space-y-4">
                    {BENEFITS.slice(0, 4).map((benefit, idx) => (
                      <div key={idx} className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${benefit.bgColor}`}>
                          <benefit.icon className={`w-5 h-5 ${benefit.color}`} />
                        </div>
                        <span className="text-gray-700">{benefit.text}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </motion.div>

        {/* All Benefits */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="mb-8">
          <Card className="border-none shadow-2xl">
            <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
              <CardTitle className="text-2xl font-bold text-center">
                ✨ Todos os Benefícios Premium
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8">
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {BENEFITS.map((benefit, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 + idx * 0.05 }}
                    className="text-center"
                  >
                    <div className={`inline-flex p-4 rounded-2xl ${benefit.bgColor} mb-3`}>
                      <benefit.icon className={`w-8 h-8 ${benefit.color}`} />
                    </div>
                    <p className="text-sm font-semibold text-gray-900">{benefit.text}</p>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Subscribe Button / Active Subscription */}
        {!hasActiveSubscription ? (
          <div className="text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5 }}
            >
              <Button
                onClick={() => setShowPaymentModal(true)}
                className="w-full max-w-3xl h-24 text-2xl bg-gradient-to-r from-purple-500 via-blue-500 to-emerald-500 hover:from-purple-600 hover:via-blue-600 hover:to-emerald-600 shadow-2xl hover:shadow-3xl transition-all"
              >
                <Gift className="w-8 h-8 mr-3" />
                {selectedPlan === 'monthly' 
                  ? `Começar ${FREE_TRIAL_DAYS} Dias GRÁTIS - ${monthlyPrice.symbol}${monthlyPrice.amount.toFixed(2)}/mês`
                  : `Começar ${FREE_TRIAL_DAYS} Dias GRÁTIS - ${yearlyPrice.symbol}${yearlyPrice.amount.toFixed(2)}/ano (${yearlyPrice.discount}% OFF!)`
                }
              </Button>
              <div className="mt-6 space-y-2">
                <p className="text-gray-600">
                  🎁 Sem compromisso • Cancele quando quiser • Sem taxas de adesão
                </p>
                {selectedPlan === 'yearly' && (
                  <p className="text-emerald-700 font-bold text-lg">
                    💰 Economize {yearlyPrice.symbol}{yearlySavings.toFixed(2)} no plano anual!
                  </p>
                )}
              </div>
            </motion.div>
          </div>
        ) : (
          <Card className="border-2 border-emerald-500 shadow-2xl">
            <CardContent className="p-12 text-center">
              <CheckCircle className="w-20 h-20 text-emerald-600 mx-auto mb-6" />
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                Você é Premium! 🎉
              </h2>
              <p className="text-xl text-gray-600 mb-6">
                Status: <Badge className={`text-white text-xl px-6 py-2 ${
                  subscription.status === 'pending' ? 'bg-yellow-500' : 'bg-emerald-500'
                }`}>
                  {subscription.status === 'pending' ? '⏳ Aguardando Pagamento' : '✅ Ativo'}
                </Badge>
              </p>
              {subscription.status === 'pending' && (
                <Alert className="max-w-2xl mx-auto border-yellow-300 bg-yellow-50">
                  <Clock className="h-5 w-5 text-yellow-600" />
                  <AlertDescription className="text-yellow-900">
                    Aguardando confirmação do pagamento. Geralmente leva até 2 horas úteis.
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      <PaymentMethodsModal
        open={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        planType={selectedPlan}
        currency={selectedCurrency}
        amount={SUBSCRIPTION_PLANS[selectedPlan][selectedCurrency].amount}
        user={user}
      />
    </div>
  );
}