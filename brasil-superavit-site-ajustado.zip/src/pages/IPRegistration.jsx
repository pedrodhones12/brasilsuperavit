import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  ArrowLeft,
  ArrowRight,
  Shield,
  Search,
  FileText,
  Users,
  CheckCircle,
  AlertTriangle,
  ExternalLink,
  Download,
  Lightbulb
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

const projectTypes = [
  { id: "app", label: "Aplicativo", description: "Apps mobile ou web" },
  { id: "jogo", label: "Jogo", description: "Jogos digitais ou físicos" },
  { id: "produto_fisico", label: "Produto Físico", description: "Produtos tangíveis" },
  { id: "design", label: "Design", description: "Design gráfico ou industrial" },
  { id: "servico", label: "Serviço", description: "Serviços e metodologias" },
  { id: "startup", label: "Startup", description: "Modelo de negócio inovador" },
  { id: "conteudo", label: "Conteúdo", description: "Obras artísticas e literárias" }
];

const protectionMapping = {
  app: "software",
  jogo: "software",
  produto_fisico: "patente",
  design: "marca",
  servico: "marca",
  startup: "marca",
  conteudo: "direito_autoral"
};

const registrationGuides = {
  marca: {
    title: "Registro de Marca no INPI",
    steps: [
      "Acesse o site do INPI (www.gov.br/inpi)",
      "Faça login ou cadastre-se no sistema",
      "Realize a pesquisa de marca para verificar disponibilidade",
      "Classifique sua marca conforme a atividade (NCL)",
      "Preencha o formulário de depósito",
      "Pague a GRU (Guia de Recolhimento da União)",
      "Acompanhe o processo pelo número de protocolo"
    ],
    documents: [
      "CPF ou CNPJ do titular",
      "Comprovante de endereço",
      "Especificação dos produtos/serviços",
      "Arte da marca (se figurativa ou mista)"
    ],
    cost: "R$ 142,00 a R$ 415,00",
    time: "12 a 24 meses",
    link: "https://www.gov.br/inpi/pt-br/servicos/marcas"
  },
  patente: {
    title: "Registro de Patente no INPI",
    steps: [
      "Realize busca de anterioridade no banco de patentes",
      "Prepare a documentação técnica completa",
      "Faça o pedido de patente no INPI",
      "Submeta relatório descritivo, reivindicações e desenhos",
      "Pague as taxas de depósito",
      "Aguarde exame técnico e publicação",
      "Responda às exigências, se houver"
    ],
    documents: [
      "Relatório descritivo da invenção",
      "Reivindicações",
      "Desenhos técnicos (se aplicável)",
      "Resumo da invenção",
      "CPF/CNPJ do inventor"
    ],
    cost: "R$ 70,00 a R$ 680,00",
    time: "3 a 7 anos",
    link: "https://www.gov.br/inpi/pt-br/servicos/patentes"
  },
  software: {
    title: "Registro de Software no INPI",
    steps: [
      "Prepare a documentação do programa",
      "Acesse o sistema e-Software do INPI",
      "Preencha os dados do programa",
      "Anexe código-fonte (primeiras 50 e últimas 50 páginas)",
      "Anexe documentação técnica",
      "Pague a taxa de registro",
      "Receba o certificado (15 a 30 dias)"
    ],
    documents: [
      "Código-fonte do software",
      "Manual técnico ou documentação",
      "Declaração de autoria",
      "CPF/CNPJ do titular"
    ],
    cost: "R$ 185,00 a R$ 415,00",
    time: "15 a 30 dias",
    link: "https://www.gov.br/inpi/pt-br/servicos/programas-de-computador"
  },
  direito_autoral: {
    title: "Registro na Biblioteca Nacional",
    steps: [
      "Acesse o site da Biblioteca Nacional",
      "Cadastre-se no sistema",
      "Preencha o formulário de registro",
      "Anexe a obra completa (PDF, áudio, vídeo)",
      "Pague a taxa de registro",
      "Receba o certificado de registro"
    ],
    documents: [
      "Obra completa em formato digital",
      "Declaração de autoria",
      "CPF do autor",
      "Formulário preenchido"
    ],
    cost: "R$ 20,00 a R$ 50,00",
    time: "30 a 60 dias",
    link: "https://www.bn.gov.br/servicos/direitos-autorais"
  }
};

export default function IPRegistration() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [step, setStep] = useState(1);
  const [user, setUser] = useState(null);
  const [searchPerformed, setSearchPerformed] = useState(false);
  const [nameAvailable, setNameAvailable] = useState(null);

  const urlParams = new URLSearchParams(window.location.search);
  const registrationId = urlParams.get('id');

  const [formData, setFormData] = useState({
    project_name: "",
    project_type: "",
    description: "",
    protection_type: "",
    needs_professional_help: false,
    inpi_protocol: "",
    status: "analise"
  });

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  const { data: existingRegistration } = useQuery({
    queryKey: ['ip-registration', registrationId],
    queryFn: async () => {
      const registrations = await base44.entities.IntellectualProperty.list();
      return registrations.find(r => r.id === registrationId);
    },
    enabled: !!registrationId,
  });

  useEffect(() => {
    if (existingRegistration) {
      setFormData(existingRegistration);
      setStep(4); // Go to guide step if editing
    }
  }, [existingRegistration]);

  const createRegistrationMutation = useMutation({
    mutationFn: (data) => base44.entities.IntellectualProperty.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ip-registrations'] });
      navigate(createPageUrl("IntellectualProperty"));
    },
  });

  const updateRegistrationMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.IntellectualProperty.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ip-registrations'] });
      navigate(createPageUrl("IntellectualProperty"));
    },
  });

  const handleNext = () => {
    if (step === 1 && formData.project_name && formData.project_type) {
      const protectionType = protectionMapping[formData.project_type];
      setFormData(prev => ({ ...prev, protection_type: protectionType }));
      setStep(2);
    } else if (step === 2 && searchPerformed) {
      setStep(3);
    } else if (step === 3 && formData.description) {
      setStep(4);
    }
  };

  const handleSimulateSearch = () => {
    // Simulate INPI search
    setTimeout(() => {
      const random = Math.random();
      setNameAvailable(random > 0.3); // 70% chance of being available
      setSearchPerformed(true);
    }, 1500);
  };

  const handleSave = () => {
    const data = {
      ...formData,
      owner_email: user?.email,
      owner_name: user?.full_name,
    };

    if (registrationId) {
      updateRegistrationMutation.mutate({ id: registrationId, data });
    } else {
      createRegistrationMutation.mutate(data);
    }
  };

  const guideInfo = registrationGuides[formData.protection_type];

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-blue-50/30 via-purple-50/30 to-emerald-50/30">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Button
            variant="outline"
            onClick={() => navigate(createPageUrl("IntellectualProperty"))}
            className="mb-6"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </Button>

          <div className="flex items-center gap-4 mb-6">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 shadow-xl">
              <Shield className="w-10 h-10 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Assistente de Registro
              </h1>
              <p className="text-gray-600 mt-1">Proteja sua ideia em 4 etapas simples</p>
            </div>
          </div>

          {/* Progress Steps */}
          <div className="flex items-center justify-between mb-8">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="flex items-center flex-1">
                <div className={`flex items-center justify-center w-10 h-10 rounded-full font-bold transition-all ${
                  step >= i 
                    ? 'bg-gradient-to-br from-blue-500 to-purple-600 text-white shadow-lg' 
                    : 'bg-gray-200 text-gray-500'
                }`}>
                  {step > i ? <CheckCircle className="w-6 h-6" /> : i}
                </div>
                {i < 4 && (
                  <div className={`flex-1 h-1 mx-2 transition-all ${
                    step > i ? 'bg-gradient-to-r from-blue-500 to-purple-600' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </motion.div>

        <AnimatePresence mode="wait">
          {/* Step 1: Identification */}
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card className="border-none shadow-2xl">
                <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50">
                  <CardTitle className="flex items-center gap-3">
                    <Lightbulb className="w-6 h-6 text-blue-600" />
                    Etapa 1: Identificação
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-8 space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="project_name" className="text-base font-semibold">
                      Qual o nome do seu projeto? *
                    </Label>
                    <Input
                      id="project_name"
                      value={formData.project_name}
                      onChange={(e) => setFormData(prev => ({ ...prev, project_name: e.target.value }))}
                      placeholder="Ex: PraiaRide, EcoApp, MeuJogo"
                      className="h-12 text-lg"
                    />
                  </div>

                  <div className="space-y-3">
                    <Label className="text-base font-semibold">
                      Que tipo de projeto é? *
                    </Label>
                    <RadioGroup
                      value={formData.project_type}
                      onValueChange={(value) => setFormData(prev => ({ ...prev, project_type: value }))}
                    >
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {projectTypes.map((type) => (
                          <div
                            key={type.id}
                            className={`flex items-start space-x-3 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                              formData.project_type === type.id
                                ? 'border-blue-500 bg-blue-50'
                                : 'border-gray-200 hover:border-blue-300'
                            }`}
                            onClick={() => setFormData(prev => ({ ...prev, project_type: type.id }))}
                          >
                            <RadioGroupItem value={type.id} id={type.id} className="mt-1" />
                            <div className="flex-1">
                              <label htmlFor={type.id} className="font-semibold text-gray-900 cursor-pointer">
                                {type.label}
                              </label>
                              <p className="text-sm text-gray-600 mt-1">{type.description}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </RadioGroup>
                  </div>

                  <Button
                    onClick={handleNext}
                    disabled={!formData.project_name || !formData.project_type}
                    className="w-full h-12 text-base bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                  >
                    Continuar
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Step 2: Name Search */}
          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card className="border-none shadow-2xl">
                <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50">
                  <CardTitle className="flex items-center gap-3">
                    <Search className="w-6 h-6 text-purple-600" />
                    Etapa 2: Pesquisa de Existência
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-8 space-y-6">
                  <Alert className="border-blue-200 bg-blue-50">
                    <AlertTriangle className="h-4 w-4 text-blue-600" />
                    <AlertDescription className="text-blue-900">
                      Vamos verificar se o nome <strong>"{formData.project_name}"</strong> já está registrado no INPI
                    </AlertDescription>
                  </Alert>

                  {!searchPerformed ? (
                    <Button
                      onClick={handleSimulateSearch}
                      className="w-full h-14 text-lg bg-gradient-to-r from-purple-500 to-blue-600 hover:from-purple-600 hover:to-blue-700"
                    >
                      <Search className="w-5 h-5 mr-2" />
                      Realizar Busca no INPI
                    </Button>
                  ) : (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="space-y-6"
                    >
                      {nameAvailable ? (
                        <Alert className="border-emerald-200 bg-emerald-50">
                          <CheckCircle className="h-5 w-5 text-emerald-600" />
                          <AlertDescription className="text-emerald-900">
                            <strong className="block mb-2">Ótima notícia!</strong>
                            O nome "{formData.project_name}" está disponível para registro!
                          </AlertDescription>
                        </Alert>
                      ) : (
                        <Alert className="border-red-200 bg-red-50">
                          <AlertTriangle className="h-5 w-5 text-red-600" />
                          <AlertDescription className="text-red-900">
                            <strong className="block mb-2">Nome já registrado</strong>
                            Encontramos registros similares. Tente variar o nome ou adicionar um diferencial.
                          </AlertDescription>
                        </Alert>
                      )}

                      <div className="flex gap-4">
                        <Button
                          variant="outline"
                          onClick={() => {
                            setSearchPerformed(false);
                            setNameAvailable(null);
                            setStep(1);
                          }}
                          className="flex-1"
                        >
                          Tentar Outro Nome
                        </Button>
                        <Button
                          onClick={handleNext}
                          className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600"
                        >
                          Continuar Mesmo Assim
                          <ArrowRight className="w-5 h-5 ml-2" />
                        </Button>
                      </div>
                    </motion.div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Step 3: Description */}
          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card className="border-none shadow-2xl">
                <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50">
                  <CardTitle className="flex items-center gap-3">
                    <FileText className="w-6 h-6 text-emerald-600" />
                    Etapa 3: Detalhes do Projeto
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-8 space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="description" className="text-base font-semibold">
                      Descreva seu projeto *
                    </Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Explique o que seu projeto faz, seus diferenciais e seu propósito..."
                      className="min-h-32 text-base"
                    />
                    <p className="text-sm text-gray-500">
                      Esta descrição será usada no registro oficial
                    </p>
                  </div>

                  <Alert className="border-blue-200 bg-blue-50">
                    <Shield className="h-4 w-4 text-blue-600" />
                    <AlertDescription className="text-blue-900">
                      Tipo de proteção recomendada: <strong>{protectionMapping[formData.project_type]?.toUpperCase()}</strong>
                    </AlertDescription>
                  </Alert>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="needs_help"
                      checked={formData.needs_professional_help}
                      onCheckedChange={(checked) => setFormData(prev => ({ ...prev, needs_professional_help: checked }))}
                    />
                    <label
                      htmlFor="needs_help"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Desejo apoio de um profissional (contador ou consultor)
                    </label>
                  </div>

                  <div className="flex gap-4">
                    <Button
                      variant="outline"
                      onClick={() => setStep(2)}
                      className="flex-1"
                    >
                      <ArrowLeft className="w-5 h-5 mr-2" />
                      Voltar
                    </Button>
                    <Button
                      onClick={handleNext}
                      disabled={!formData.description}
                      className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600"
                    >
                      Ver Guia de Registro
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Step 4: Registration Guide */}
          {step === 4 && guideInfo && (
            <motion.div
              key="step4"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <Card className="border-none shadow-2xl">
                <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50">
                  <CardTitle className="flex items-center gap-3">
                    <CheckCircle className="w-6 h-6 text-emerald-600" />
                    Etapa 4: Guia para Registro
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-8 space-y-6">
                  <div className="p-6 bg-gradient-to-r from-emerald-50 to-blue-50 rounded-xl">
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">{guideInfo.title}</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
                      <div>
                        <p className="text-sm text-gray-600">Custo</p>
                        <p className="font-bold text-gray-900">{guideInfo.cost}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Prazo</p>
                        <p className="font-bold text-gray-900">{guideInfo.time}</p>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-bold text-gray-900 mb-4">Passo a Passo</h4>
                    <div className="space-y-3">
                      {guideInfo.steps.map((step, index) => (
                        <div key={index} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                          <div className="w-6 h-6 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 text-white flex items-center justify-center text-sm font-bold flex-shrink-0">
                            {index + 1}
                          </div>
                          <p className="text-gray-700">{step}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-bold text-gray-900 mb-4">Documentos Necessários</h4>
                    <div className="space-y-2">
                      {guideInfo.documents.map((doc, index) => (
                        <div key={index} className="flex items-center gap-2 text-gray-700">
                          <CheckCircle className="w-4 h-4 text-emerald-600" />
                          {doc}
                        </div>
                      ))}
                    </div>
                  </div>

                  <a
                    href={guideInfo.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block"
                  >
                    <Button variant="outline" className="w-full h-12">
                      <ExternalLink className="w-5 h-5 mr-2" />
                      Ir para Site Oficial
                    </Button>
                  </a>

                  {formData.needs_professional_help && (
                    <Alert className="border-yellow-200 bg-yellow-50">
                      <Users className="h-4 w-4 text-yellow-600" />
                      <AlertDescription className="text-yellow-900">
                        <strong className="block mb-2">Apoio Profissional Solicitado</strong>
                        Recomendamos buscar um contador ou consultor de propriedade intelectual para auxiliá-lo neste processo.
                      </AlertDescription>
                    </Alert>
                  )}

                  <div className="flex gap-4">
                    <Button
                      variant="outline"
                      onClick={() => setStep(3)}
                      className="flex-1"
                    >
                      <ArrowLeft className="w-5 h-5 mr-2" />
                      Voltar
                    </Button>
                    <Button
                      onClick={handleSave}
                      disabled={createRegistrationMutation.isPending || updateRegistrationMutation.isPending}
                      className="flex-1 bg-gradient-to-r from-emerald-500 to-blue-600 hover:from-emerald-600 hover:to-blue-700"
                    >
                      {createRegistrationMutation.isPending || updateRegistrationMutation.isPending ? (
                        "Salvando..."
                      ) : (
                        <>
                          <Download className="w-5 h-5 mr-2" />
                          Salvar Registro
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}