
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Heart,
  MessageCircle,
  Share2,
  TrendingUp,
  Sparkles,
  Users,
  Send,
  Image as ImageIcon,
  Video,
  FileText,
  Link as LinkIcon,
  X,
  Upload,
  ExternalLink,
  Download,
  Play,
  CheckCircle,
  Info,
  Search,
  Filter,
  Clock,
  ThumbsUp,
  Smile,
  Award,
  Flame,
  MoreHorizontal,
  Edit,
  Trash2,
  Flag,
  Bookmark
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

const postTypeInfo = {
  update: { label: "Atualização", color: "bg-blue-100 text-blue-800", icon: TrendingUp },
  milestone: { label: "Marco", color: "bg-purple-100 text-purple-800", icon: Sparkles },
  announcement: { label: "Anúncio", color: "bg-emerald-100 text-emerald-800", icon: Sparkles },
  question: { label: "Pergunta", color: "bg-yellow-100 text-yellow-800", icon: MessageCircle },
  achievement: { label: "Conquista", color: "bg-red-100 text-red-800", icon: Award }
};

const categoryInfo = {
  tecnologico: { name: "Tecnologia", color: "from-blue-500 to-blue-600" },
  cultural: { name: "Cultura", color: "from-purple-500 to-purple-600" },
  sustentabilidade: { name: "Sustentabilidade", color: "from-emerald-500 to-emerald-600" },
  infraestrutura: { name: "Infraestrutura", color: "from-orange-500 to-orange-600" },
  educacao: { name: "Educação", color: "from-pink-500 to-pink-600" }
};

const reactions = [
  { id: 'like', icon: ThumbsUp, label: 'Curtir', color: 'text-blue-600' },
  { id: 'love', icon: Heart, label: 'Amei', color: 'text-red-600' },
  { id: 'celebrate', icon: Award, label: 'Parabéns', color: 'text-yellow-600' },
  { id: 'fire', icon: Flame, label: 'Incrível', color: 'text-orange-600' },
  { id: 'smile', icon: Smile, label: 'Haha', color: 'text-green-600' }
];

const ImagePreviewModal = ({ image, isOpen, onClose }) => (
  <Dialog open={isOpen} onOpenChange={onClose}>
    <DialogContent className="max-w-6xl max-h-[90vh] p-0">
      <div className="relative">
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
          className="absolute top-4 right-4 z-10 bg-black/50 hover:bg-black/70 text-white rounded-full"
        >
          <X className="w-5 h-5" />
        </Button>
        <img 
          src={image} 
          alt="Preview" 
          className="w-full h-auto max-h-[85vh] object-contain rounded-lg"
        />
      </div>
    </DialogContent>
  </Dialog>
);

const PostCard = ({ post, onLike, onComment, onShare, currentUser, onDelete }) => {
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState("");
  const [selectedReaction, setSelectedReaction] = useState(null);
  const [showReactions, setShowReactions] = useState(false);
  const [showImagePreview, setShowImagePreview] = useState(false);
  const [showActions, setShowActions] = useState(false);

  const typeInfo = postTypeInfo[post.post_type];
  const TypeIcon = typeInfo.icon;

  const { data: comments = [] } = useQuery({
    queryKey: ['post-comments', post.id],
    queryFn: () => base44.entities.PostComment.filter({ post_id: post.id }, '-created_date'),
    enabled: showComments,
  });

  const handleReaction = (reactionId) => {
    setSelectedReaction(reactionId);
    setShowReactions(false);
    onLike(post.id, true);
  };

  const handleComment = () => {
    if (commentText.trim()) {
      onComment(post.id, commentText);
      setCommentText("");
    }
  };

  const getFileIcon = (filename) => {
    const ext = filename?.split('.').pop()?.toLowerCase();
    const iconMap = {
      pdf: '📕', doc: '📘', docx: '📘', xls: '📗', xlsx: '📗',
      ppt: '📙', pptx: '📙', txt: '📄', zip: '📦', rar: '📦'
    };
    return iconMap[ext] || '📄';
  };

  const renderMedia = () => {
    if (post.media_type === 'image' && post.media_url) {
      return (
        <div className="mb-4 rounded-xl overflow-hidden border-2 border-gray-200 group relative cursor-pointer"
             onClick={() => setShowImagePreview(true)}>
          <img 
            src={post.media_url} 
            alt="Post media" 
            className="w-full h-auto object-cover hover:opacity-95 transition-all"
          />
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all flex items-center justify-center">
            <div className="opacity-0 group-hover:opacity-100 transition-opacity bg-white/90 rounded-full p-3">
              <ExternalLink className="w-6 h-6 text-gray-900" />
            </div>
          </div>
        </div>
      );
    }

    if (post.media_type === 'video' && post.media_url) {
      return (
        <div className="mb-4 rounded-xl overflow-hidden border-2 border-gray-200 bg-black">
          <video controls className="w-full h-auto" src={post.media_url} preload="metadata">
            Seu navegador não suporta vídeo.
          </video>
        </div>
      );
    }

    if (post.media_type === 'document' && post.media_url) {
      const fileIcon = getFileIcon(post.document_name);
      return (
        <a href={post.media_url} target="_blank" rel="noopener noreferrer" className="mb-4 block">
          <motion.div 
            whileHover={{ scale: 1.02 }}
            className="p-5 rounded-xl bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-200 hover:border-blue-400 transition-all cursor-pointer shadow-md hover:shadow-lg"
          >
            <div className="flex items-center gap-4">
              <div className="p-4 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 shadow-lg">
                <FileText className="w-8 h-8 text-white" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-2xl">{fileIcon}</span>
                  <p className="font-bold text-gray-900">{post.document_name || 'Documento'}</p>
                </div>
                <p className="text-sm text-gray-600">Clique para abrir ou baixar</p>
              </div>
              <Download className="w-6 h-6 text-blue-600" />
            </div>
          </motion.div>
        </a>
      );
    }

    if (post.media_type === 'link' && post.link_url) {
      return (
        <a href={post.link_url} target="_blank" rel="noopener noreferrer" className="mb-4 block">
          <motion.div 
            whileHover={{ scale: 1.01 }}
            className="rounded-xl border-2 border-gray-200 hover:border-emerald-400 transition-all overflow-hidden cursor-pointer shadow-md hover:shadow-xl"
          >
            {post.link_image && (
              <div className="relative h-56 overflow-hidden">
                <img src={post.link_image} alt="Link preview" className="w-full h-full object-cover" />
                <div className="absolute top-4 right-4 p-2 rounded-full bg-white/90 backdrop-blur-sm">
                  <ExternalLink className="w-5 h-5 text-gray-700" />
                </div>
              </div>
            )}
            <div className="p-5 bg-gradient-to-br from-gray-50 to-white">
              <h4 className="font-bold text-lg text-gray-900 mb-2 line-clamp-2">
                {post.link_title || post.link_url}
              </h4>
              {post.link_description && (
                <p className="text-sm text-gray-600 line-clamp-3 mb-3">{post.link_description}</p>
              )}
              <div className="flex items-center gap-2">
                <LinkIcon className="w-4 h-4 text-gray-400" />
                <p className="text-xs text-gray-500 font-medium">
                  {new URL(post.link_url).hostname}
                </p>
              </div>
            </div>
          </motion.div>
        </a>
      );
    }

    return null;
  };

  const isMyPost = currentUser?.email === post.author_email;

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        layout
      >
        <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300">
          <CardContent className="p-6">
            {/* Header */}
            <div className="flex items-start gap-4 mb-4">
              <Avatar className="w-12 h-12 border-2 border-white shadow-md">
                {post.author_photo ? (
                  <AvatarImage src={post.author_photo} alt={post.author_name} />
                ) : (
                  <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-blue-500 text-white font-semibold">
                    {post.author_name?.substring(0, 2).toUpperCase() || 'US'}
                  </AvatarFallback>
                )}
              </Avatar>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-bold text-gray-900">{post.author_name}</h3>
                  {post.project_title && (
                    <Badge variant="outline" className="text-xs">
                      {post.project_title}
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <Clock className="w-3 h-3" />
                  <span>{format(new Date(post.created_date), "dd MMM 'às' HH:mm", { locale: ptBR })}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge className={typeInfo.color}>
                  <TypeIcon className="w-3 h-3 mr-1" />
                  {typeInfo.label}
                </Badge>
                <div className="relative">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setShowActions(!showActions)}
                  >
                    <MoreHorizontal className="w-5 h-5" />
                  </Button>
                  {showActions && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="absolute right-0 top-10 bg-white rounded-lg shadow-xl border border-gray-200 py-2 z-10 min-w-48"
                    >
                      <button className="w-full px-4 py-2 hover:bg-gray-100 flex items-center gap-3 text-left">
                        <Bookmark className="w-4 h-4" />
                        Salvar
                      </button>
                      {isMyPost && (
                        <>
                          <button className="w-full px-4 py-2 hover:bg-gray-100 flex items-center gap-3 text-left">
                            <Edit className="w-4 h-4" />
                            Editar
                          </button>
                          <button 
                            onClick={() => onDelete && onDelete(post.id)}
                            className="w-full px-4 py-2 hover:bg-red-50 flex items-center gap-3 text-left text-red-600"
                          >
                            <Trash2 className="w-4 h-4" />
                            Excluir
                          </button>
                        </>
                      )}
                      {!isMyPost && (
                        <button className="w-full px-4 py-2 hover:bg-gray-100 flex items-center gap-3 text-left">
                          <Flag className="w-4 h-4" />
                          Denunciar
                        </button>
                      )}
                    </motion.div>
                  )}
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="mb-4">
              <p className="text-gray-700 whitespace-pre-line leading-relaxed text-base">
                {post.content}
              </p>
            </div>

            {/* Media */}
            {renderMedia()}

            {/* Tags */}
            {post.tags && post.tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-4">
                {post.tags.map((tag, index) => (
                  <Badge key={index} variant="outline" className="text-xs cursor-pointer hover:bg-gray-100">
                    #{tag}
                  </Badge>
                ))}
              </div>
            )}

            {/* Category */}
            {post.category && (
              <Badge className={`bg-gradient-to-r ${categoryInfo[post.category].color} text-white border-none mb-4`}>
                {categoryInfo[post.category].name}
              </Badge>
            )}

            {/* Actions */}
            <div className="flex items-center gap-4 pt-4 border-t border-gray-200">
              <div className="relative">
                <Button
                  variant="ghost"
                  size="sm"
                  onMouseEnter={() => setShowReactions(true)}
                  onMouseLeave={() => setTimeout(() => setShowReactions(false), 200)}
                  className={`gap-2 ${selectedReaction ? reactions.find(r => r.id === selectedReaction)?.color : 'text-gray-600'}`}
                >
                  {selectedReaction ? (
                    React.createElement(reactions.find(r => r.id === selectedReaction)?.icon, { className: 'w-5 h-5' })
                  ) : (
                    <Heart className="w-5 h-5" />
                  )}
                  <span className="font-semibold">{(post.likes_count || 0) + (selectedReaction ? 1 : 0)}</span>
                </Button>
                
                <AnimatePresence>
                  {showReactions && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="absolute bottom-full left-0 mb-2 bg-white rounded-full shadow-2xl border-2 border-gray-200 px-3 py-2 flex gap-2"
                      onMouseEnter={() => setShowReactions(true)}
                      onMouseLeave={() => setShowReactions(false)}
                    >
                      {reactions.map((reaction) => (
                        <motion.button
                          key={reaction.id}
                          whileHover={{ scale: 1.3 }}
                          whileTap={{ scale: 0.9 }}
                          onClick={() => handleReaction(reaction.id)}
                          className={`p-2 rounded-full hover:bg-gray-100 ${reaction.color}`}
                          title={reaction.label}
                        >
                          <reaction.icon className="w-5 h-5" />
                        </motion.button>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowComments(!showComments)}
                className="gap-2 text-gray-600"
              >
                <MessageCircle className="w-5 h-5" />
                <span className="font-semibold">{post.comments_count || 0}</span>
              </Button>

              <Button
                variant="ghost"
                size="sm"
                onClick={() => onShare(post.id)}
                className="gap-2 text-gray-600"
              >
                <Share2 className="w-5 h-5" />
                <span className="font-semibold">{post.shares_count || 0}</span>
              </Button>
            </div>

            {/* Comments Section */}
            <AnimatePresence>
              {showComments && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-4 pt-4 border-t border-gray-200"
                >
                  <div className="space-y-3 mb-4 max-h-96 overflow-y-auto">
                    {comments.length > 0 ? (
                      comments.map((comment) => (
                        <motion.div 
                          key={comment.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="flex gap-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                        >
                          <Avatar className="w-8 h-8">
                            <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-500 text-white text-xs">
                              {comment.author_name?.substring(0, 2).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <p className="font-semibold text-sm text-gray-900">{comment.author_name}</p>
                            <p className="text-sm text-gray-700 mt-1">{comment.content}</p>
                            <div className="flex items-center gap-4 mt-2">
                              <button className="text-xs text-gray-500 hover:text-blue-600 font-medium">
                                Curtir
                              </button>
                              <button className="text-xs text-gray-500 hover:text-blue-600 font-medium">
                                Responder
                              </button>
                              <span className="text-xs text-gray-400">
                                {format(new Date(comment.created_date), "HH:mm", { locale: ptBR })}
                              </span>
                            </div>
                          </div>
                        </motion.div>
                      ))
                    ) : (
                      <p className="text-center text-gray-500 text-sm py-4">
                        Seja o primeiro a comentar! 💬
                      </p>
                    )}
                  </div>

                  <div className="flex gap-2">
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-blue-500 text-white text-xs">
                        {currentUser?.full_name?.substring(0, 2).toUpperCase() || 'US'}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 flex gap-2">
                      <Input
                        placeholder="Escreva um comentário..."
                        value={commentText}
                        onChange={(e) => setCommentText(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleComment())}
                        className="flex-1"
                      />
                      <Button 
                        onClick={handleComment} 
                        size="sm" 
                        disabled={!commentText.trim()}
                        className="bg-gradient-to-r from-emerald-500 to-blue-500"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </CardContent>
        </Card>
      </motion.div>

      <ImagePreviewModal 
        image={post.media_url}
        isOpen={showImagePreview}
        onClose={() => setShowImagePreview(false)}
      />
    </>
  );
};

export default function SocialFeed() {
  const [user, setUser] = useState(null);
  const [activeCategory, setActiveCategory] = useState("all");
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [uploadingMedia, setUploadingMedia] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("recent");
  const [newPost, setNewPost] = useState({
    content: "",
    post_type: "update",
    category: "",
    tags: [],
    media_type: "none",
    media_url: "",
    link_url: "",
    link_title: "",
    link_description: "",
    link_image: "",
    document_name: ""
  });
  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  const { data: posts = [], isLoading } = useQuery({
    queryKey: ['social-posts', activeCategory],
    queryFn: async () => {
      if (activeCategory === 'all') {
        return await base44.entities.SocialPost.list('-created_date');
      }
      return await base44.entities.SocialPost.filter({ category: activeCategory }, '-created_date');
    },
  });

  const createPostMutation = useMutation({
    mutationFn: (postData) => base44.entities.SocialPost.create(postData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['social-posts'] });
      setShowCreatePost(false);
      setNewPost({ 
        content: "", 
        post_type: "update", 
        category: "", 
        tags: [],
        media_type: "none",
        media_url: "",
        link_url: "",
        link_title: "",
        link_description: "",
        link_image: "",
        document_name: ""
      });
    },
  });

  const deletePostMutation = useMutation({
    mutationFn: (postId) => base44.entities.SocialPost.delete(postId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['social-posts'] });
    },
  });

  const likePostMutation = useMutation({
    mutationFn: async ({ postId, liked }) => {
      const post = posts.find(p => p.id === postId);
      await base44.entities.SocialPost.update(postId, {
        likes_count: (post.likes_count || 0) + (liked ? 1 : -1)
      });
      
      if (liked) {
        await base44.entities.PostLike.create({
          post_id: postId,
          user_email: user.email
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['social-posts'] });
    },
  });

  const commentPostMutation = useMutation({
    mutationFn: async ({ postId, content }) => {
      const post = posts.find(p => p.id === postId);
      
      await base44.entities.PostComment.create({
        post_id: postId,
        author_email: user.email,
        author_name: user.full_name,
        content
      });

      await base44.entities.SocialPost.update(postId, {
        comments_count: (post.comments_count || 0) + 1
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['social-posts'] });
      queryClient.invalidateQueries({ queryKey: ['post-comments'] });
    },
  });

  const sharePostMutation = useMutation({
    mutationFn: async (postId) => {
      const post = posts.find(p => p.id === postId);
      await base44.entities.SocialPost.update(postId, {
        shares_count: (post.shares_count || 0) + 1
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['social-posts'] });
    },
  });

  const handleFileUpload = async (e, type) => {
    const file = e.target.files[0];
    if (!file) return;

    if (file.size > 50 * 1024 * 1024) {
      alert("Arquivo muito grande! Tamanho máximo: 50MB");
      return;
    }

    setUploadingMedia(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setNewPost(prev => ({
        ...prev,
        media_type: type,
        media_url: file_url,
        document_name: type === 'document' ? file.name : ''
      }));
    } catch (error) {
      alert("Erro ao fazer upload do arquivo");
    } finally {
      setUploadingMedia(false);
    }
  };

  const clearMedia = () => {
    setNewPost(prev => ({
      ...prev,
      media_type: "none",
      media_url: "",
      link_url: "",
      link_title: "",
      link_description: "",
      link_image: "",
      document_name: ""
    }));
  };

  const handleCreatePost = () => {
    if (!newPost.content.trim()) {
      alert("Por favor, escreva algo antes de publicar");
      return;
    }

    const postData = {
      ...newPost,
      author_email: user.email,
      author_name: user.full_name,
      author_photo: user.profile_photo_url
    };
    createPostMutation.mutate(postData);
  };

  const filteredPosts = posts
    .filter(post => {
      if (searchQuery) {
        return post.content?.toLowerCase().includes(searchQuery.toLowerCase()) ||
               post.author_name?.toLowerCase().includes(searchQuery.toLowerCase());
      }
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'recent') return new Date(b.created_date) - new Date(a.created_date);
      if (sortBy === 'popular') return (b.likes_count || 0) - (a.likes_count || 0);
      if (sortBy === 'discussed') return (b.comments_count || 0) - (a.comments_count || 0);
      return 0;
    });

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-blue-50/30 via-purple-50/30 to-emerald-50/30">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500 via-purple-500 to-emerald-500 shadow-xl">
              <Users className="w-10 h-10 text-white" />
            </div>
            <div>
              <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-emerald-600 bg-clip-text text-transparent">
                Feed Social Global
              </h1>
              <p className="text-xl text-gray-600 mt-1">
                Compartilhe suas conquistas, fotos, vídeos e conecte-se com a comunidade
              </p>
            </div>
          </div>
        </motion.div>

        {/* Search and Filters */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="mb-6"
        >
          <Card className="border-none shadow-lg">
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Input
                    placeholder="Buscar posts, pessoas ou hashtags..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="recent">Mais recentes</SelectItem>
                    <SelectItem value="popular">Mais curtidos</SelectItem>
                    <SelectItem value="discussed">Mais comentados</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Feed */}
          <div className="lg:col-span-2 space-y-6">
            {/* Create Post */}
            <Card className="border-none shadow-xl">
              <CardContent className="p-6">
                {!showCreatePost ? (
                  <Button
                    onClick={() => setShowCreatePost(true)}
                    variant="outline"
                    className="w-full h-14 text-left justify-start text-gray-500 hover:bg-gradient-to-r hover:from-blue-50 hover:to-purple-50"
                  >
                    <Avatar className="w-8 h-8 mr-3">
                      {user?.profile_photo_url ? (
                        <AvatarImage src={user.profile_photo_url} alt={user.full_name} />
                      ) : (
                        <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-blue-500 text-white text-xs">
                          {user?.full_name?.substring(0, 2).toUpperCase() || 'US'}
                        </AvatarFallback>
                      )}
                    </Avatar>
                    Compartilhe suas conquistas, fotos ou ideias...
                  </Button>
                ) : (
                  <div className="space-y-4">
                    <Textarea
                      placeholder="O que você quer compartilhar com a comunidade?"
                      value={newPost.content}
                      onChange={(e) => setNewPost(prev => ({ ...prev, content: e.target.value }))}
                      className="min-h-32 text-base"
                    />

                    {/* Media Preview */}
                    {newPost.media_type !== 'none' && (
                      <div className="relative p-4 bg-gradient-to-br from-gray-50 to-blue-50 rounded-lg border-2 border-blue-200">
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={clearMedia}
                          className="absolute top-2 right-2 z-10"
                        >
                          <X className="w-4 h-4" />
                        </Button>

                        {newPost.media_type === 'image' && newPost.media_url && (
                          <div className="rounded-lg overflow-hidden">
                            <img src={newPost.media_url} alt="Preview" className="w-full rounded-lg" />
                            <p className="text-xs text-gray-600 mt-2 flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-emerald-600" />
                              Imagem carregada
                            </p>
                          </div>
                        )}

                        {newPost.media_type === 'video' && newPost.media_url && (
                          <div className="rounded-lg overflow-hidden bg-black">
                            <video src={newPost.media_url} controls className="w-full" />
                          </div>
                        )}

                        {newPost.media_type === 'document' && (
                          <div className="flex items-center gap-3 p-4 bg-white rounded-lg">
                            <FileText className="w-10 h-10 text-blue-600" />
                            <p className="font-semibold text-gray-900">{newPost.document_name}</p>
                          </div>
                        )}

                        {newPost.media_type === 'link' && (
                          <div className="space-y-3">
                            <Input
                              placeholder="🔗 Cole a URL"
                              value={newPost.link_url}
                              onChange={(e) => setNewPost(prev => ({ ...prev, link_url: e.target.value }))}
                            />
                            <Input
                              placeholder="📝 Título (opcional)"
                              value={newPost.link_title}
                              onChange={(e) => setNewPost(prev => ({ ...prev, link_title: e.target.value }))}
                            />
                          </div>
                        )}
                      </div>
                    )}
                    
                    <div className="flex flex-wrap gap-3">
                      <select
                        value={newPost.post_type}
                        onChange={(e) => setNewPost(prev => ({ ...prev, post_type: e.target.value }))}
                        className="px-4 py-2 border-2 border-gray-200 rounded-lg"
                      >
                        {Object.entries(postTypeInfo).map(([key, info]) => (
                          <option key={key} value={key}>{info.label}</option>
                        ))}
                      </select>

                      <select
                        value={newPost.category}
                        onChange={(e) => setNewPost(prev => ({ ...prev, category: e.target.value }))}
                        className="px-4 py-2 border-2 border-gray-200 rounded-lg"
                      >
                        <option value="">Categoria</option>
                        {Object.entries(categoryInfo).map(([key, info]) => (
                          <option key={key} value={key}>{info.name}</option>
                        ))}
                      </select>
                    </div>

                    {/* Media Buttons */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      <label className="cursor-pointer">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleFileUpload(e, 'image')}
                          className="hidden"
                          disabled={uploadingMedia}
                        />
                        <div className="p-4 text-center border-2 border-dashed border-blue-200 rounded-xl hover:border-blue-400 hover:bg-blue-50 transition-all">
                          <ImageIcon className="w-8 h-8 mx-auto mb-2 text-blue-600" />
                          <p className="text-sm font-semibold text-gray-700">Foto</p>
                        </div>
                      </label>

                      <label className="cursor-pointer">
                        <input
                          type="file"
                          accept="video/*"
                          onChange={(e) => handleFileUpload(e, 'video')}
                          className="hidden"
                          disabled={uploadingMedia}
                        />
                        <div className="p-4 text-center border-2 border-dashed border-purple-200 rounded-xl hover:border-purple-400 hover:bg-purple-50 transition-all">
                          <Video className="w-8 h-8 mx-auto mb-2 text-purple-600" />
                          <p className="text-sm font-semibold text-gray-700">Vídeo</p>
                        </div>
                      </label>

                      <label className="cursor-pointer">
                        <input
                          type="file"
                          accept=".pdf,.doc,.docx"
                          onChange={(e) => handleFileUpload(e, 'document')}
                          className="hidden"
                          disabled={uploadingMedia}
                        />
                        <div className="p-4 text-center border-2 border-dashed border-emerald-200 rounded-xl hover:border-emerald-400 hover:bg-emerald-50 transition-all">
                          <FileText className="w-8 h-8 mx-auto mb-2 text-emerald-600" />
                          <p className="text-sm font-semibold text-gray-700">Doc</p>
                        </div>
                      </label>

                      <div 
                        className="p-4 text-center border-2 border-dashed border-orange-200 rounded-xl hover:border-orange-400 hover:bg-orange-50 transition-all cursor-pointer"
                        onClick={() => setNewPost(prev => ({ ...prev, media_type: 'link' }))}
                      >
                        <LinkIcon className="w-8 h-8 mx-auto mb-2 text-orange-600" />
                        <p className="text-sm font-semibold text-gray-700">Link</p>
                      </div>
                    </div>

                    {uploadingMedia && (
                      <div className="text-center py-4">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2" />
                        <p className="text-sm text-gray-600">Enviando...</p>
                      </div>
                    )}

                    <div className="flex gap-3 pt-4 border-t">
                      <Button
                        variant="outline"
                        onClick={() => {
                          setShowCreatePost(false);
                          clearMedia();
                        }}
                        className="flex-1 h-12"
                      >
                        Cancelar
                      </Button>
                      <Button
                        onClick={handleCreatePost}
                        disabled={!newPost.content || createPostMutation.isPending || uploadingMedia}
                        className="flex-1 h-12 bg-gradient-to-r from-blue-500 via-purple-500 to-emerald-500"
                      >
                        {createPostMutation.isPending ? "Publicando..." : (
                          <>
                            <Sparkles className="w-5 h-5 mr-2" />
                            Publicar
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Posts List */}
            <div className="space-y-6">
              {isLoading ? (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4" />
                  <p className="text-gray-600">Carregando feed...</p>
                </div>
              ) : filteredPosts.length > 0 ? (
                <AnimatePresence mode="popLayout">
                  {filteredPosts.map((post) => (
                    <PostCard
                      key={post.id}
                      post={post}
                      currentUser={user}
                      onLike={(postId, liked) => likePostMutation.mutate({ postId, liked })}
                      onComment={(postId, content) => commentPostMutation.mutate({ postId, content })}
                      onShare={(postId) => sharePostMutation.mutate(postId)}
                      onDelete={(postId) => {
                        if (confirm('Excluir este post?')) {
                          deletePostMutation.mutate(postId);
                        }
                      }}
                    />
                  ))}
                </AnimatePresence>
              ) : (
                <Card className="p-12 text-center border-2 border-dashed">
                  <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    {searchQuery ? 'Nenhum resultado' : 'Seja o primeiro!'}
                  </h3>
                  <p className="text-gray-600">
                    {searchQuery ? 'Tente outro termo' : 'Compartilhe algo'}
                  </p>
                </Card>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Categories */}
            <Card className="border-none shadow-xl">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Filter className="w-5 h-5" />
                  Categorias
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <div className="space-y-2">
                  <Button
                    variant={activeCategory === 'all' ? 'default' : 'ghost'}
                    className="w-full justify-start"
                    onClick={() => setActiveCategory('all')}
                  >
                    Todas
                  </Button>
                  {Object.entries(categoryInfo).map(([key, info]) => (
                    <Button
                      key={key}
                      variant={activeCategory === key ? 'default' : 'ghost'}
                      className="w-full justify-start"
                      onClick={() => setActiveCategory(key)}
                    >
                      {info.name}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Stats */}
            <Card className="border-none shadow-xl bg-gradient-to-br from-blue-50 to-purple-50">
              <CardContent className="p-6">
                <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-yellow-500" />
                  Comunidade Global
                </h3>
                <div className="space-y-3">
                  <div>
                    <p className="text-sm text-gray-600">Posts ativos</p>
                    <p className="text-2xl font-bold text-gray-900">{posts.length}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Interações</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {posts.reduce((sum, p) => sum + (p.likes_count || 0) + (p.comments_count || 0), 0)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tips */}
            <Card className="border-none shadow-xl">
              <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Info className="w-4 h-4" />
                  Dicas
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 space-y-2 text-xs">
                <p>✨ Posts com mídia têm 3x mais engajamento</p>
                <p>💬 Responda aos comentários</p>
                <p>🎯 Use hashtags relevantes</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
