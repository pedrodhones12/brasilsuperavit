import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  GraduationCap, 
  Play,
  BookOpen,
  Lightbulb,
  Rocket,
  Target,
  Clock,
  Eye
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const categoryInfo = {
  empreendedorismo: {
    name: "Empreendedorismo & Sustentabilidade",
    color: "from-emerald-500 to-emerald-600",
    icon: Lightbulb,
    description: "Descubra seu potencial empreendedor e aprenda a criar projetos sustentáveis com impacto social"
  },
  tecnologia: {
    name: "Tecnologia & Startups",
    color: "from-blue-500 to-purple-600",
    icon: Rocket,
    description: "Transforme ideias em apps, jogos e startups de sucesso com inovação e tecnologia"
  }
};

const TutorialCard = ({ tutorial }) => {
  const categoryData = categoryInfo[tutorial.category];
  const Icon = categoryData.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      whileHover={{ y: -6 }}
      transition={{ duration: 0.3 }}
    >
      <Link to={createPageUrl(`TutorialView?id=${tutorial.id}`)}>
        <Card className="border-none shadow-lg hover:shadow-2xl transition-all duration-300 h-full overflow-hidden group cursor-pointer">
          <div className={`h-2 bg-gradient-to-r ${categoryData.color}`} />
          <CardHeader className="p-6 bg-gradient-to-br from-gray-50 to-white">
            <div className="flex items-start justify-between mb-3">
              <Badge className={`bg-gradient-to-r ${categoryData.color} text-white border-none font-semibold`}>
                Roteiro {tutorial.order}
              </Badge>
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <Eye className="w-4 h-4" />
                <span>{tutorial.views || 0}</span>
              </div>
            </div>
            <CardTitle className="text-xl mb-2 line-clamp-2 group-hover:text-emerald-600 transition-colors">
              {tutorial.title}
            </CardTitle>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Icon className="w-4 h-4" />
              <span className="font-medium">{tutorial.theme}</span>
            </div>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <div className="space-y-2">
              <div className="flex items-start gap-2">
                <Target className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-gray-700 line-clamp-3">{tutorial.objective}</p>
              </div>
            </div>

            {tutorial.key_points && tutorial.key_points.length > 0 && (
              <div className="space-y-2 pt-3 border-t border-gray-200">
                <p className="text-xs font-semibold text-gray-500 uppercase">Principais Tópicos</p>
                <ul className="space-y-1">
                  {tutorial.key_points.slice(0, 3).map((point, index) => (
                    <li key={index} className="text-sm text-gray-600 flex items-start gap-2">
                      <span className="text-emerald-600 font-bold">•</span>
                      <span className="line-clamp-1">{point}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="flex items-center justify-between pt-4 border-t border-gray-200">
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <Clock className="w-4 h-4" />
                <span>{tutorial.duration || '3-5 min'}</span>
              </div>
              <Button 
                size="sm" 
                className={`bg-gradient-to-r ${categoryData.color} hover:shadow-lg transition-all`}
              >
                <Play className="w-4 h-4 mr-1" />
                Assistir
              </Button>
            </div>
          </CardContent>
        </Card>
      </Link>
    </motion.div>
  );
};

export default function Education() {
  const [selectedCategory, setSelectedCategory] = useState("all");

  const { data: tutorials = [], isLoading } = useQuery({
    queryKey: ['tutorials'],
    queryFn: () => base44.entities.Tutorial.list('order'),
  });

  const filteredTutorials = selectedCategory === 'all' 
    ? tutorials 
    : tutorials.filter(t => t.category === selectedCategory);

  const tutorialsByCategory = {
    empreendedorismo: tutorials.filter(t => t.category === 'empreendedorismo'),
    tecnologia: tutorials.filter(t => t.category === 'tecnologia'),
  };

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-emerald-50/30 via-blue-50/30 to-purple-50/30">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-500 to-blue-600 shadow-xl">
              <GraduationCap className="w-10 h-10 text-white" />
            </div>
            <div>
              <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-emerald-600 via-blue-600 to-purple-600 bg-clip-text text-transparent">
                Empreendedor do Futuro
              </h1>
              <p className="text-xl text-gray-600 mt-1">Desenvolva Seu Projeto</p>
            </div>
          </div>
          <p className="text-lg text-gray-600 max-w-3xl">
            Aprenda através de tutoriais práticos e transforme suas ideias em projetos reais. 
            Do autoconhecimento à tecnologia, da sustentabilidade às startups.
          </p>
        </motion.div>

        {/* Category Overview Cards */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="grid md:grid-cols-2 gap-6 mb-10"
        >
          {Object.entries(categoryInfo).map(([key, info], index) => {
            const Icon = info.icon;
            const count = tutorialsByCategory[key]?.length || 0;
            return (
              <motion.div
                key={key}
                initial={{ opacity: 0, x: index === 0 ? -20 : 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 + index * 0.1 }}
              >
                <Card className="border-none shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden group cursor-pointer"
                      onClick={() => setSelectedCategory(key)}>
                  <div className={`h-2 bg-gradient-to-r ${info.color}`} />
                  <CardContent className="p-8">
                    <div className="flex items-start gap-4 mb-4">
                      <div className={`p-4 rounded-2xl bg-gradient-to-br ${info.color} shadow-lg group-hover:scale-110 transition-transform`}>
                        <Icon className="w-8 h-8 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-2xl font-bold text-gray-900 mb-2">{info.name}</h3>
                        <p className="text-gray-600 mb-4">{info.description}</p>
                        <div className="flex items-center gap-3">
                          <Badge variant="outline" className="font-semibold">
                            {count} {count === 1 ? 'Tutorial' : 'Tutoriais'}
                          </Badge>
                          <Badge className={`bg-gradient-to-r ${info.color} text-white border-none`}>
                            Gratuito
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="mb-8"
        >
          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <BookOpen className="w-5 h-5 text-gray-500" />
                  <span className="font-medium text-gray-700">
                    {filteredTutorials.length} {filteredTutorials.length === 1 ? 'tutorial disponível' : 'tutoriais disponíveis'}
                  </span>
                </div>
                <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
                  <TabsList className="bg-gray-100">
                    <TabsTrigger value="all" className="px-6">Todos</TabsTrigger>
                    <TabsTrigger value="empreendedorismo" className="px-6">Empreendedorismo</TabsTrigger>
                    <TabsTrigger value="tecnologia" className="px-6">Tecnologia</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Tutorials Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="h-96 animate-pulse bg-gray-100" />
            ))}
          </div>
        ) : filteredTutorials.length > 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            <AnimatePresence mode="wait">
              {filteredTutorials.map((tutorial) => (
                <TutorialCard key={tutorial.id} tutorial={tutorial} />
              ))}
            </AnimatePresence>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="p-16 text-center border-2 border-dashed border-gray-300">
              <BookOpen className="w-20 h-20 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Nenhum tutorial encontrado
              </h3>
              <p className="text-gray-600">
                Os tutoriais estarão disponíveis em breve
              </p>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
}