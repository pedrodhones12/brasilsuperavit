import React,{useState,useEffect}from"react";import{base44}from"@/api/base44Client";import{useQuery}from"@tanstack/react-query";import{Card,CardContent,CardHeader,CardTitle}from"@/components/ui/card";import{Button}from"@/components/ui/button";import{Badge}from"@/components/ui/badge";import{TrendingUp,DollarSign,Users,Rocket,Target,Award,BarChart3,Heart,Sparkles,ArrowRight,MapPin,Calendar,TrendingDown,Activity}from"lucide-react";import{motion}from"framer-motion";import{Link}from"react-router-dom";import{createPageUrl}from"@/utils";import ProjectRecommendations from"../components/recommendations/ProjectRecommendations";

const _0x1a2b=React.memo(({_0x3c4d,_0x5e6f,_0x7g8h})=>{const _0x9i0j=(_0x3c4d.current_funding/_0x3c4d.funding_goal)*100;const _0x2k3l=_0x3c4d.end_date?Math.max(0,Math.ceil((new Date(_0x3c4d.end_date)-new Date())/(1000*60*60*24))):0;return(<motion.div initial={{opacity:0,scale:0.95}}animate={{opacity:1,scale:1}}whileHover={{y:-4}}transition={{duration:0.2}}><Card className="overflow-hidden border-none shadow-lg hover:shadow-2xl transition-all duration-300 cursor-pointer"onClick={()=>window.location.href=createPageUrl("Invest")}><div className={`h-2 bg-gradient-to-r ${_0x5e6f>=80?'from-emerald-500 to-green-500':_0x5e6f>=60?'from-blue-500 to-cyan-500':'from-purple-500 to-pink-500'}`}/><CardContent className="p-6"><div className="flex items-start justify-between mb-4"><div className="flex-1 min-w-0"><h3 className="text-xl font-bold text-gray-900 mb-2 line-clamp-2 hover:text-emerald-600 transition-colors">{_0x3c4d.title}</h3><div className="flex items-center gap-2 mb-3"><MapPin className="w-4 h-4 text-gray-500"/><span className="text-sm text-gray-600">{_0x3c4d.city}/{_0x3c4d.state}</span></div></div>{_0x7g8h===0&&_0x5e6f>=80&&(<Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white border-none ml-2"><Award className="w-3 h-3 mr-1"/>Top Match</Badge>)}</div><div className="space-y-4"><div className="grid grid-cols-2 gap-4"><div className="p-3 bg-emerald-50 rounded-lg"><p className="text-xs text-emerald-700 mb-1">Meta</p><p className="text-lg font-bold text-emerald-900">R$ {(_0x3c4d.funding_goal/1000).toFixed(0)}k</p></div><div className="p-3 bg-blue-50 rounded-lg"><p className="text-xs text-blue-700 mb-1">Arrecadado</p><p className="text-lg font-bold text-blue-900">R$ {(_0x3c4d.current_funding/1000).toFixed(0)}k</p></div></div><div><div className="flex justify-between items-center mb-2"><span className="text-xs text-gray-600">Progresso</span><span className="text-xs font-semibold text-gray-900">{_0x9i0j.toFixed(0)}%</span></div><div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden"><div style={{width:`${Math.min(_0x9i0j,100)}%`}}className="h-full bg-gradient-to-r from-emerald-500 to-blue-500"/></div></div><div className="flex items-center justify-between pt-3 border-t border-gray-200"><div className="flex items-center gap-4 text-sm text-gray-600"><div className="flex items-center gap-1"><Users className="w-4 h-4"/><span className="font-semibold">{_0x3c4d.investors_count||0}</span></div>{_0x2k3l>0&&(<div className="flex items-center gap-1"><Calendar className="w-4 h-4"/><span className="font-semibold">{_0x2k3l}d</span></div>)}</div><Button size="sm"className="bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600">Ver Detalhes<ArrowRight className="w-4 h-4 ml-1"/></Button></div></div></CardContent></Card></motion.div>);});
_0x1a2b.displayName='QuickProjectCard';

export default function Dashboard(){
  const[_0x4m5n,_0x6o7p]=useState(null);
  const[_0x8q9r,_0xas1t]=useState({projects:0,investments:0,total_invested:0,total_received:0,active_partnerships:0});
  
  useEffect(()=>{
    const _0x2u3v=async()=>{
      try{
        const _0x4w5x=await base44.auth.me();
        _0x6o7p(_0x4w5x);
        const _0x6y7z=await base44.entities.Project.filter({created_by:_0x4w5x.email},'-created_date',3);
        const _0x8a9b=await base44.entities.Investment.filter({investor_email:_0x4w5x.email});
        const _0xcd1e=_0x8a9b.reduce((_0x2f,_0x3g)=>_0x2f+(_0x3g.amount||0),0);
        const _0x4h5i=await base44.entities.Partnership.filter({$or:[{investor_email:_0x4w5x.email},{entrepreneur_email:_0x4w5x.email}]});
        const _0x6j7k=_0x4h5i.filter(_0x8l=>_0x8l.status==='active').length;
        _0xas1t({projects:_0x6y7z.length,investments:_0x8a9b.length,total_invested:_0xcd1e,total_received:0,active_partnerships:_0x6j7k});
      }catch(_0x9m){}
    };
    _0x2u3v();
  },[]);

  const{data:_0xan1o=[]}=useQuery({
    queryKey:['trending-projects'],
    queryFn:async()=>{
      const _0x2p=await base44.entities.Project.filter({status:'ativa'},'-created_date',3);
      return _0x2p.sort((_0x3q,_0x4r)=>{
        const _0x5s=(_0x3q.current_funding/_0x3q.funding_goal)*100;
        const _0x6t=(_0x4r.current_funding/_0x4r.funding_goal)*100;
        return _0x6t-_0x5s;
      });
    },
    staleTime:10*60*1000,
    cacheTime:15*60*1000,
  });

  const _0x7u8v=[
    {_0x9w:"Total Investido",_0xax:_0x8q9r.total_invested,_0xby:DollarSign,_0xcz:"from-emerald-500 to-emerald-600",_0xd1:"emerald"},
    {_0x9w:"Meus Projetos",_0xax:_0x8q9r.projects,_0xby:Rocket,_0xcz:"from-blue-500 to-blue-600",_0xd1:"blue"},
    {_0x9w:"Investimentos",_0xax:_0x8q9r.investments,_0xby:TrendingUp,_0xcz:"from-purple-500 to-purple-600",_0xd1:"purple"},
    {_0x9w:"Parcerias Ativas",_0xax:_0x8q9r.active_partnerships,_0xby:Users,_0xcz:"from-orange-500 to-orange-600",_0xd1:"orange"}
  ];

  return(
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-emerald-50/50 to-blue-50/50">
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{opacity:0,y:-20}}animate={{opacity:1,y:0}}className="mb-8">
          <div className="flex items-center gap-4 mb-6">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-500 via-blue-500 to-purple-600 shadow-xl">
              <Sparkles className="w-10 h-10 text-white"/>
            </div>
            <div>
              <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-emerald-600 via-blue-600 to-purple-600 bg-clip-text text-transparent">
                Bem-vindo, {_0x4m5n?.full_name?.split(' ')[0]||'Investidor'}!
              </h1>
              <p className="text-xl text-gray-600 mt-1">Seu painel de controle completo</p>
            </div>
          </div>
        </motion.div>

        <motion.div initial={{opacity:0}}animate={{opacity:1}}transition={{delay:0.1}}className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {_0x7u8v.map((_0x2e3f,_0x4g5h)=>{
            const _0x6i=_0x2e3f._0xby;
            return(
              <motion.div key={_0x4g5h}initial={{opacity:0,y:20}}animate={{opacity:1,y:0}}transition={{delay:0.1+_0x4g5h*0.05}}>
                <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <p className="text-sm text-gray-500 mb-1">{_0x2e3f._0x9w}</p>
                        <p className="text-3xl font-bold text-gray-900">
                          {typeof _0x2e3f._0xax==='number'&&_0x2e3f._0x9w.includes('Investido')?`R$ ${_0x2e3f._0xax.toLocaleString('pt-BR')}`:_0x2e3f._0xax}
                        </p>
                      </div>
                      <div className={`p-4 rounded-xl bg-gradient-to-br ${_0x2e3f._0xcz} shadow-lg`}>
                        <_0x6i className="w-8 h-8 text-white"/>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <motion.div initial={{opacity:0}}animate={{opacity:1}}transition={{delay:0.2}}>
              <Card className="border-none shadow-xl">
                <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                  <CardTitle className="flex items-center gap-3">
                    <Activity className="w-6 h-6 text-emerald-600"/>
                    Projetos em Alta
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid gap-6">
                    {_0xan1o.slice(0,3).map((_0x7j8k,_0x9l)=>(
                      <_0x1a2b key={_0x7j8k.id}_0x3c4d={_0x7j8k}_0x5e6f={(_0x7j8k.current_funding/_0x7j8k.funding_goal)*100}_0x7g8h={_0x9l}/>
                    ))}
                  </div>
                  <Link to={createPageUrl("Projects")}>
                    <Button className="w-full mt-6 bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600">
                      Ver Todos os Projetos
                      <ArrowRight className="w-4 h-4 ml-2"/>
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          <div className="space-y-8">
            <motion.div initial={{opacity:0,x:20}}animate={{opacity:1,x:0}}transition={{delay:0.3}}>
              <ProjectRecommendations user={_0x4m5n}limit={2}/>
            </motion.div>

            <motion.div initial={{opacity:0,x:20}}animate={{opacity:1,x:0}}transition={{delay:0.4}}>
              <Card className="border-none shadow-xl bg-gradient-to-br from-purple-50 to-pink-50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Heart className="w-5 h-5 text-purple-600"/>
                    Ações Rápidas
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {[
                    {_0xm:"Criar Projeto",_0xn:createPageUrl("CreateProject"),_0xo:Rocket,_0xp:"from-emerald-500 to-blue-500"},
                    {_0xm:"Investir",_0xn:createPageUrl("Invest"),_0xo:TrendingUp,_0xp:"from-blue-500 to-purple-500"},
                    {_0xm:"Proteção Legal",_0xn:createPageUrl("IntellectualProperty"),_0xo:Award,_0xp:"from-purple-500 to-pink-500"},
                    {_0xm:"Educação",_0xn:createPageUrl("Education"),_0xo:Sparkles,_0xp:"from-orange-500 to-red-500"}
                  ].map((_0xq2r,_0xs3t)=>(
                    <Link key={_0xs3t}to={_0xq2r._0xn}>
                      <Button variant="outline"className="w-full justify-start hover:shadow-md transition-all">
                        <div className={`p-2 rounded-lg bg-gradient-to-br ${_0xq2r._0xp} mr-3`}>
                          <_0xq2r._0xo className="w-4 h-4 text-white"/>
                        </div>
                        {_0xq2r._0xm}
                      </Button>
                    </Link>
                  ))}
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}