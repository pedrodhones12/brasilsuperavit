
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Alert, AlertDescription } from "@/components/ui/alert"; // Added Alert import
import { 
  Globe,
  Send,
  Heart,
  MessageCircle,
  Share2,
  Image as ImageIcon,
  Video,
  Link as LinkIcon,
  Users,
  Sparkles,
  TrendingUp,
  MapPin,
  Flag,
  Play,
  Eye,
  Search,
  Filter,
  X,
  Loader2,
  CheckCircle,
  Info,
  Upload,
  UserPlus,
  Edit,
  Trash2,
  Smile,
  AtSign,
  MoreVertical
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

const categoryColors = {
  tecnologico: "from-blue-400 to-blue-600",
  cultural: "from-purple-400 to-purple-600",
  sustentabilidade: "from-emerald-400 to-emerald-600",
  infraestrutura: "from-orange-400 to-orange-600",
  educacao: "from-indigo-400 to-indigo-600"
};

const categoryLabels = {
  tecnologico: "Tecnológico",
  cultural: "Cultural",
  sustentabilidade: "Sustentabilidade",
  infraestrutura: "Infraestrutura",
  educacao: "Educação"
};

const postTypeIcons = {
  update: TrendingUp,
  milestone: Sparkles,
  announcement: Flag,
  question: MessageCircle,
  achievement: Heart
};

const EMOJI_LIST = ["❤️", "👍", "😂", "😮", "😢", "🎉", "🔥", "👏", "🙏", "💪", "✨", "🚀"];

const EmojiPicker = ({ onSelect }) => {
  return (
    <div className="grid grid-cols-6 gap-2 p-3">
      {EMOJI_LIST.map((emoji) => (
        <button
          key={emoji}
          onClick={() => onSelect(emoji)}
          className="text-2xl hover:scale-125 transition-transform"
        >
          {emoji}
        </button>
      ))}
    </div>
  );
};

const MentionInput = ({ value, onChange, placeholder, className }) => {
  const [showMentions, setShowMentions] = useState(false);
  const [mentionSearch, setMentionSearch] = useState("");
  const [cursorPosition, setCursorPosition] = useState(0);

  const { data: allUsers = [] } = useQuery({
    queryKey: ['all-users-for-mention'],
    queryFn: async () => {
      // Fetch all users to enable client-side filtering for mentions
      return await base44.entities.User.list();
    },
    enabled: showMentions // Only fetch users when the mention UI is potentially active
  });

  const handleInputChange = (e) => {
    const newValue = e.target.value;
    const cursor = e.target.selectionStart;
    
    onChange(newValue);
    setCursorPosition(cursor);

    // Check if @ was typed or if we're inside an @ mention
    const textBeforeCursor = newValue.substring(0, cursor);
    const lastAtIndex = textBeforeCursor.lastIndexOf('@');
    
    if (lastAtIndex !== -1 && cursor > lastAtIndex) {
      const searchText = textBeforeCursor.substring(lastAtIndex + 1);
      // Ensure the search text is not empty and does not contain spaces
      if (searchText.length > 0 && !searchText.includes(' ')) {
        setMentionSearch(searchText);
        setShowMentions(true);
        return;
      }
    }
    
    setShowMentions(false);
    setMentionSearch(""); // Clear search if no valid mention context
  };

  const insertMention = (user) => {
    const textBeforeCursor = value.substring(0, cursorPosition);
    const textAfterCursor = value.substring(cursorPosition);
    const lastAtIndex = textBeforeCursor.lastIndexOf('@');
    
    const beforeMention = value.substring(0, lastAtIndex);
    const mention = `@${user.full_name} `;
    const newValue = beforeMention + mention + textAfterCursor;
    
    onChange(newValue);
    setShowMentions(false);
    setMentionSearch("");
  };

  const filteredUsers = allUsers.filter(u => 
    u.full_name?.toLowerCase().includes(mentionSearch.toLowerCase())
  ).slice(0, 5); // Limit suggestions to 5

  return (
    <div className="relative">
      <Textarea
        value={value}
        onChange={handleInputChange}
        placeholder={placeholder}
        className={className}
      />
      
      {showMentions && filteredUsers.length > 0 && mentionSearch.length > 0 && (
        <Card className="absolute bottom-full left-0 w-full mb-2 z-50 shadow-xl">
          <CardContent className="p-2">
            {filteredUsers.map((user) => (
              <button
                key={user.email}
                onClick={() => insertMention(user)}
                className="w-full flex items-center gap-3 p-3 hover:bg-gray-100 rounded-lg transition-colors text-left"
              >
                <Avatar className="w-8 h-8">
                  {user.profile_photo_url ? (
                    <AvatarImage src={user.profile_photo_url} />
                  ) : (
                    <AvatarFallback className="bg-gradient-to-br from-blue-400 to-purple-400 text-white text-xs">
                      {user.full_name?.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  )}
                </Avatar>
                <div>
                  <p className="font-semibold text-sm">{user.full_name}</p>
                  <p className="text-xs text-gray-500">{user.email}</p>
                </div>
              </button>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
};

const PostCard = ({ post, onLike, onComment, onDelete, onEdit, currentUser, userLikes, comments }) => {
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const TypeIcon = postTypeIcons[post.post_type] || TrendingUp;

  const hasLiked = userLikes?.some(like => like.post_id === post.id) || false;
  const isAuthor = currentUser?.email === post.author_email;

  const handleSubmitComment = async () => {
    if (!commentText.trim() || !currentUser) return;
    
    setIsSubmitting(true);
    try {
      await onComment(post.id, commentText);
      setCommentText("");
      setShowEmojiPicker(false);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEmojiSelect = (emoji) => {
    setCommentText(prev => prev + emoji);
  };

  const postComments = comments?.filter(c => c.post_id === post.id) || [];

  // Render content with highlighted mentions
  const renderContentWithMentions = (text) => {
    if (!text) return null;
    
    const parts = text.split(/(@[^\s]+)/g); // Split by @word that doesn't contain spaces
    return parts.map((part, index) => {
      if (part.startsWith('@')) {
        return (
          <span key={index} className="text-blue-600 font-semibold">
            {part}
          </span>
        );
      }
      return <React.Fragment key={index}>{part}</React.Fragment>;
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
    >
      <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden bg-white">
        <CardHeader className="bg-gradient-to-r from-emerald-50 via-blue-50 to-purple-50 pb-4">
          <div className="flex items-start gap-3">
            <Avatar className="w-12 h-12 border-2 border-white shadow-md">
              {post.author_photo ? (
                <AvatarImage src={post.author_photo} alt={post.author_name} />
              ) : (
                <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-blue-500 text-white font-bold">
                  {post.author_name?.substring(0, 2).toUpperCase() || 'US'}
                </AvatarFallback>
              )}
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <p className="font-bold text-gray-900">{post.author_name}</p>
                {post.author_country && (
                  <Badge variant="outline" className="gap-1 bg-white">
                    <MapPin className="w-3 h-3" />
                    {post.author_country}
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <p className="text-xs text-gray-500">
                  {format(new Date(post.created_date), "dd MMM yyyy 'às' HH:mm", { locale: ptBR })}
                </p>
                {post.category && (
                  <Badge className={`bg-gradient-to-r ${categoryColors[post.category]} text-white border-none text-xs`}>
                    {categoryLabels[post.category]}
                  </Badge>
                )}
                <Badge variant="outline" className="gap-1 bg-blue-50 border-blue-200">
                  <TypeIcon className="w-3 h-3" />
                  {post.post_type}
                </Badge>
              </div>
            </div>

            {/* Edit/Delete Menu */}
            {isAuthor && (
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-48" align="end">
                  <div className="space-y-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full justify-start gap-2"
                      onClick={() => onEdit(post)}
                    >
                      <Edit className="w-4 h-4" />
                      Editar
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full justify-start gap-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                      onClick={() => {
                        if (window.confirm('Tem certeza que deseja excluir este post?')) {
                          onDelete(post.id);
                        }
                      }}
                    >
                      <Trash2 className="w-4 h-4" />
                      Excluir
                    </Button>
                  </div>
                </PopoverContent>
              </Popover>
            )}
          </div>
        </CardHeader>
        
        <CardContent className="p-6 space-y-4 bg-white">
          {post.project_title && (
            <div className="p-3 bg-gradient-to-r from-emerald-50 to-blue-50 rounded-lg border-l-4 border-emerald-500">
              <p className="text-sm text-gray-600">Projeto vinculado:</p>
              <p className="font-semibold text-emerald-700">{post.project_title}</p>
            </div>
          )}
          
          <p className="text-gray-800 leading-relaxed whitespace-pre-wrap">
            {renderContentWithMentions(post.content)}
          </p>
          
          {post.media_type === 'photo' && post.media_url && (
            <div className="rounded-xl overflow-hidden shadow-lg">
              <img 
                src={post.media_url} 
                alt="Post media" 
                className="w-full h-auto object-cover max-h-96"
                loading="lazy"
              />
            </div>
          )}
          
          {post.media_type === 'video' && post.media_url && (
            <div className="relative rounded-xl overflow-hidden shadow-lg bg-gray-100 aspect-video">
              <video 
                src={post.media_url} 
                controls 
                className="w-full h-full object-cover"
              />
            </div>
          )}
          
          {post.media_type === 'link' && post.link_url && (
            <a 
              href={post.link_url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="block p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl border-2 border-blue-200 hover:border-blue-400 transition-all group"
            >
              <div className="flex items-start gap-3">
                <div className="p-2 bg-white rounded-lg shadow-sm">
                  <LinkIcon className="w-5 h-5 text-blue-600" />
                </div>
                <div className="flex-1 min-w-0">
                  {post.link_title && (
                    <p className="font-bold text-gray-900 mb-1 group-hover:text-blue-600 transition-colors">
                      {post.link_title}
                    </p>
                  )}
                  {post.link_description && (
                    <p className="text-sm text-gray-600 line-clamp-2">{post.link_description}</p>
                  )}
                  <p className="text-xs text-blue-600 mt-2 truncate">{post.link_url}</p>
                </div>
              </div>
            </a>
          )}
          
          {post.tags && post.tags.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {post.tags.map((tag, index) => (
                <Badge key={index} variant="outline" className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
                  #{tag}
                </Badge>
              ))}
            </div>
          )}
          
          <div className="flex items-center justify-between pt-4 border-t border-gray-200">
            <div className="flex items-center gap-4">
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className={`gap-2 transition-all ${
                      hasLiked 
                        ? 'text-red-600 hover:text-red-700 hover:bg-red-50' 
                        : 'text-gray-600 hover:text-red-600 hover:bg-red-50'
                    }`}
                    disabled={!currentUser}
                  >
                    <Heart className={`w-5 h-5 ${hasLiked ? 'fill-current' : ''}`} />
                    <span className="font-semibold">{post.likes_count || 0}</span>
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-2" align="start">
                  <div className="flex gap-2">
                    {EMOJI_LIST.slice(0, 6).map((emoji) => (
                      <button
                        key={emoji}
                        onClick={() => onLike(post.id)} // For now, just triggers a generic like
                        className="text-2xl hover:scale-125 transition-transform"
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </PopoverContent>
              </Popover>
              
              <Button
                variant="ghost"
                size="sm"
                className="gap-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50"
                onClick={() => setShowComments(!showComments)}
              >
                <MessageCircle className="w-5 h-5" />
                <span className="font-semibold">{post.comments_count || 0}</span>
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                className="gap-2 text-gray-600 hover:text-emerald-600 hover:bg-emerald-50"
              >
                <Share2 className="w-5 h-5" />
                <span className="font-semibold">{post.shares_count || 0}</span>
              </Button>
            </div>
            
            <div className="flex items-center gap-1 text-gray-500">
              <Eye className="w-4 h-4" />
              <span className="text-sm">{post.views || 0}</span>
            </div>
          </div>
          
          <AnimatePresence>
            {showComments && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="pt-4 border-t border-gray-200 space-y-4"
              >
                {/* Existing Comments */}
                {postComments.length > 0 && (
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {postComments.map((comment) => (
                      <div key={comment.id} className="flex gap-3 p-3 bg-gray-50 rounded-lg">
                        <Avatar className="w-8 h-8 flex-shrink-0">
                          <AvatarFallback className="bg-gradient-to-br from-blue-400 to-purple-400 text-white text-xs">
                            {comment.author_name?.substring(0, 2).toUpperCase() || 'US'}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="font-semibold text-sm text-gray-900">{comment.author_name}</p>
                            <span className="text-xs text-gray-500">
                              {format(new Date(comment.created_date), "dd MMM 'às' HH:mm", { locale: ptBR })}
                            </span>
                          </div>
                          <p className="text-sm text-gray-700">{renderContentWithMentions(comment.content)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Comment Input */}
                {currentUser ? (
                  <div className="flex gap-3">
                    <Avatar className="w-8 h-8 flex-shrink-0">
                      {currentUser?.profile_photo_url ? (
                        <AvatarImage src={currentUser.profile_photo_url} />
                      ) : (
                        <AvatarFallback className="bg-gradient-to-br from-emerald-400 to-blue-400 text-white text-xs">
                          {currentUser?.full_name?.substring(0, 2).toUpperCase() || 'US'}
                        </AvatarFallback>
                      )}
                    </Avatar>
                    <div className="flex-1 space-y-2">
                      <MentionInput
                        value={commentText}
                        onChange={setCommentText}
                        placeholder="Escreva um comentário... (use @ para mencionar)"
                        className="border-2 border-gray-200 focus:border-blue-400 bg-white"
                      />
                      <div className="flex items-center justify-between">
                        <Popover open={showEmojiPicker} onOpenChange={setShowEmojiPicker}>
                          <PopoverTrigger asChild>
                            <Button variant="outline" size="sm" className="gap-2">
                              <Smile className="w-4 h-4" />
                              Emoji
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <EmojiPicker onSelect={handleEmojiSelect} />
                          </PopoverContent>
                        </Popover>
                        
                        <Button 
                          size="sm" 
                          onClick={handleSubmitComment}
                          disabled={!commentText.trim() || isSubmitting}
                          className="bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600"
                        >
                          {isSubmitting ? (
                            <>
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                              Enviando...
                            </>
                          ) : (
                            <>
                              <Send className="w-4 h-4 mr-2" />
                              Comentar
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-4 text-gray-500">
                    <p className="text-sm">Faça login para comentar</p>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default function GlobalFeed() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [newPostContent, setNewPostContent] = useState("");
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [postVisibility, setPostVisibility] = useState("international");
  const [editingPost, setEditingPost] = useState(null);
  
  // Media upload states
  const [uploadingMedia, setUploadingMedia] = useState(false);
  const [mediaFile, setMediaFile] = useState(null); // Stores { url, name, type }
  const [mediaType, setMediaType] = useState("none"); // "none", "photo", "video", "link"
  const [mediaPreview, setMediaPreview] = useState(null); // URL for image/video preview
  
  // Link states
  const [showLinkForm, setShowLinkForm] = useState(false);
  const [linkUrl, setLinkUrl] = useState("");
  const [linkTitle, setLinkTitle] = useState("");
  const [linkDescription, setLinkDescription] = useState("");

  useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (error) {
        console.log("User not authenticated");
      }
    };
    loadUser();
  }, []);

  const { data: posts = [], isLoading } = useQuery({
    queryKey: ['global-posts', selectedCategory],
    queryFn: async () => {
      const filter = selectedCategory === 'all' ? {} : { category: selectedCategory };
      return await base44.entities.SocialPost.filter(filter, '-created_date', 50);
    },
  });

  const { data: userLikes = [] } = useQuery({
    queryKey: ['user-likes', user?.email],
    queryFn: () => base44.entities.PostLike.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });

  const { data: allComments = [] } = useQuery({
    queryKey: ['post-comments'],
    queryFn: () => base44.entities.PostComment.list('-created_date', 200),
  });

  const createPostMutation = useMutation({
    mutationFn: (postData) => base44.entities.SocialPost.create(postData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['global-posts'] });
      setNewPostContent("");
      setShowCreatePost(false);
      setPostVisibility("international");
      // Reset media states
      setMediaFile(null);
      setMediaType("none");
      setMediaPreview(null);
      setShowLinkForm(false);
      setLinkUrl("");
      setLinkTitle("");
      setLinkDescription("");
      
      // Show success message
      alert("✅ Post publicado com sucesso!");
    },
    onError: (error) => {
      console.error("Error creating post:", error);
      alert("❌ Erro ao publicar. Tente novamente.");
    }
  });

  const likeMutation = useMutation({
    mutationFn: async (postId) => {
      const post = posts.find(p => p.id === postId);
      if (!post) throw new Error("Post not found");

      const existingLike = userLikes.find(like => like.post_id === postId && like.user_email === user.email);
      
      if (existingLike) {
        // Unlike
        await base44.entities.PostLike.delete(existingLike.id);
        await base44.entities.SocialPost.update(postId, {
          likes_count: Math.max(0, (post.likes_count || 0) - 1)
        });
      } else {
        // Like
        await base44.entities.PostLike.create({
          post_id: postId,
          user_email: user.email
        });
        await base44.entities.SocialPost.update(postId, {
          likes_count: (post.likes_count || 0) + 1
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['global-posts'] });
      queryClient.invalidateQueries({ queryKey: ['user-likes'] });
    },
  });

  const commentMutation = useMutation({
    mutationFn: async ({ postId, content }) => {
      const post = posts.find(p => p.id === postId);
      if (!post) throw new Error("Post not found");
      
      await base44.entities.PostComment.create({
        post_id: postId,
        author_email: user.email,
        author_name: user.full_name,
        created_date: new Date().toISOString(), // Add created_date for new comments
        content: content
      });

      await base44.entities.SocialPost.update(postId, {
        comments_count: (post.comments_count || 0) + 1
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['global-posts'] });
      queryClient.invalidateQueries({ queryKey: ['post-comments'] });
    },
  });

  const deletePostMutation = useMutation({
    mutationFn: (postId) => base44.entities.SocialPost.delete(postId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['global-posts'] });
      alert("✅ Post excluído com sucesso!");
    },
    onError: (error) => {
      console.error("Error deleting post:", error);
      alert("❌ Erro ao excluir o post. Tente novamente.");
    }
  });

  const updatePostMutation = useMutation({
    mutationFn: ({ postId, data }) => base44.entities.SocialPost.update(postId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['global-posts'] });
      setEditingPost(null);
      setShowCreatePost(false);
      setNewPostContent("");
      // Reset media states for update as well
      setMediaFile(null);
      setMediaType("none");
      setMediaPreview(null);
      setShowLinkForm(false);
      setLinkUrl("");
      setLinkTitle("");
      setLinkDescription("");
      alert("✅ Post atualizado com sucesso!");
    },
    onError: (error) => {
      console.error("Error updating post:", error);
      alert("❌ Erro ao atualizar o post. Tente novamente.");
    }
  });

  // Handle file upload
  const handleFileUpload = async (e, type) => {
    const file = e.target.files[0];
    if (!file) return;

    // Validate file size (max 50MB)
    if (file.size > 50 * 1024 * 1024) {
      alert("❌ Arquivo muito grande! Tamanho máximo: 50MB");
      e.target.value = null; // Clear the input
      return;
    }

    setUploadingMedia(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      setMediaFile({
        url: file_url,
        name: file.name,
        type: type
      });
      setMediaType(type);
      
      // Create preview for images/videos
      if (type === 'photo' || type === 'video') {
        setMediaPreview(file_url);
      }
      
      alert("✅ Arquivo enviado com sucesso!");
    } catch (error) {
      console.error("Upload error:", error);
      alert("❌ Erro ao fazer upload. Tente novamente.");
    } finally {
      setUploadingMedia(false);
      e.target.value = null; // Clear the input so same file can be selected again
    }
  };

  // Clear media
  const clearMedia = () => {
    setMediaFile(null);
    setMediaType("none");
    setMediaPreview(null);
    setShowLinkForm(false);
    setLinkUrl("");
    setLinkTitle("");
    setLinkDescription("");
  };

  // Handle link submission
  const handleAddLink = () => {
    if (!linkUrl.trim()) {
      alert("⚠️ Por favor, insira uma URL válida");
      return;
    }
    
    setMediaType("link");
    setShowLinkForm(false);
    alert("✅ Link adicionado!");
  };

  const handleEdit = (post) => {
    setEditingPost(post);
    setNewPostContent(post.content);
    setPostVisibility(post.visibility || "international");
    setMediaType(post.media_type || "none");
    if (post.media_type === 'photo' || post.media_type === 'video') {
      setMediaFile({ url: post.media_url, name: post.media_filename, type: post.media_type });
      setMediaPreview(post.media_url);
    } else if (post.media_type === 'link') {
      setLinkUrl(post.link_url);
      setLinkTitle(post.link_title || "");
      setLinkDescription(post.link_description || "");
      setShowLinkForm(true); // Open link form to show details
    }
    setShowCreatePost(true);
    
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCreatePost = () => {
    // Validate user is logged in
    if (!user) {
      alert("⚠️ Você precisa estar logado para publicar");
      base44.auth.redirectToLogin(window.location.pathname);
      return;
    }

    // Validate content
    if (!newPostContent.trim()) {
      alert("⚠️ Por favor, escreva algo antes de publicar");
      return;
    }
    // Prevent post creation if media is still uploading
    if (uploadingMedia) {
      alert("⚠️ Aguarde o upload do arquivo terminar");
      return;
    }

    const postData = {
      content: newPostContent,
      visibility: postVisibility,
      media_type: mediaType // Add media_type
    };

    // Add media data based on type
    if (mediaType === 'photo' || mediaType === 'video') {
      postData.media_url = mediaFile.url;
      postData.media_filename = mediaFile.name;
    } else if (mediaType === 'link') {
      postData.link_url = linkUrl;
      postData.link_title = linkTitle;
      postData.link_description = linkDescription;
    }

    if (editingPost) {
      // Update existing post
      updatePostMutation.mutate({ postId: editingPost.id, data: postData });
    } else {
      // Create new post
      const newPostData = {
        ...postData,
        author_email: user.email,
        author_name: user.full_name || "Usuário",
        author_photo: user.profile_photo_url || "",
        author_country: user.location || user.nationality || "Brasil",
        post_type: "update", // Default post type
        likes_count: 0,
        comments_count: 0,
        shares_count: 0,
      };
      createPostMutation.mutate(newPostData);
    }
  };

  const handleLike = (postId) => {
    if (!user) {
      alert("Faça login para curtir posts");
      return;
    }
    likeMutation.mutate(postId);
  };

  const handleComment = async (postId, content) => {
    if (!user) {
      alert("Faça login para comentar");
      return;
    }
    await commentMutation.mutateAsync({ postId, content });
  };

  const filteredPosts = posts.filter(post => 
    !searchQuery || 
    post.content?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    post.author_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-yellow-50 via-emerald-50 to-blue-50">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-400 via-blue-400 to-purple-400 shadow-xl">
              <Globe className="w-10 h-10 text-white" />
            </div>
            <div>
              <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-emerald-600 via-blue-600 to-purple-600 bg-clip-text text-transparent">
                Feed Social Global
              </h1>
              <p className="text-lg text-gray-700 mt-1">
                Compartilhe suas conquistas, fotos, vídeos e conecte-se com a comunidade
              </p>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="mb-6"
        >
          <Card className="border-none shadow-xl bg-white overflow-hidden">
            <div className="h-2 bg-gradient-to-r from-emerald-400 via-blue-400 to-purple-400" />
            <CardContent className="p-6">
              {!user ? (
                <div className="text-center py-8">
                  <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-lg font-semibold text-gray-900 mb-2">
                    Faça login para publicar
                  </p>
                  <Button 
                    onClick={() => base44.auth.redirectToLogin(window.location.pathname)}
                    className="bg-gradient-to-r from-emerald-500 to-blue-500"
                  >
                    <UserPlus className="w-4 h-4 mr-2" />
                    Entrar / Cadastrar
                  </Button>
                </div>
              ) : (
                <>
                  {editingPost && (
                    <Alert className="mb-4 border-blue-200 bg-blue-50">
                      <Edit className="h-4 w-4 text-blue-600" />
                      <AlertDescription className="text-blue-900">
                        <strong>Editando post</strong> - Faça suas alterações e clique em "Atualizar"
                      </AlertDescription>
                    </Alert>
                  )}

                  <div className="flex items-center gap-3 mb-4">
                    <Avatar className="w-12 h-12 border-2 border-emerald-300 shadow-md">
                      {user.profile_photo_url ? (
                        <AvatarImage src={user.profile_photo_url} />
                      ) : (
                        <AvatarFallback className="bg-gradient-to-br from-emerald-400 to-blue-400 text-white font-bold">
                          {user.full_name?.substring(0, 2).toUpperCase() || 'US'}
                        </AvatarFallback>
                      )}
                    </Avatar>
                    <Input
                      placeholder="Compartilhe suas conquistas, fotos ou ideias..."
                      value={newPostContent}
                      onChange={(e) => setNewPostContent(e.target.value)}
                      onFocus={() => setShowCreatePost(true)}
                      className="flex-1 h-12 border-2 border-gray-200 focus:border-emerald-400 bg-white"
                    />
                  </div>
                  
                  <AnimatePresence>
                    {showCreatePost && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="space-y-4"
                      >
                        <MentionInput
                          value={newPostContent}
                          onChange={setNewPostContent}
                          placeholder="O que você quer compartilhar? Use @ para mencionar pessoas..."
                          className="min-h-24 border-2 border-gray-200 focus:border-emerald-400 bg-white"
                        />

                        {/* Media Preview */}
                        {mediaType !== 'none' && (
                          <div className="relative p-4 bg-gray-50 rounded-xl border-2 border-gray-200">
                            <button
                              onClick={clearMedia}
                              className="absolute top-2 right-2 p-1 bg-red-500 rounded-full hover:bg-red-600 transition-colors z-10"
                            >
                              <X className="w-4 h-4 text-white" />
                            </button>

                            {mediaType === 'photo' && mediaPreview && (
                              <div className="space-y-2">
                                <p className="text-sm font-semibold text-gray-700">📷 Foto anexada:</p>
                                <img src={mediaPreview} alt="Preview" className="w-full max-h-64 object-cover rounded-lg" />
                              </div>
                            )}

                            {mediaType === 'video' && mediaPreview && (
                              <div className="space-y-2">
                                <p className="text-sm font-semibold text-gray-700">🎥 Vídeo anexado:</p>
                                <video src={mediaPreview} controls className="w-full max-h-64 rounded-lg" />
                              </div>
                            )}

                            {mediaType === 'link' && linkUrl && (
                              <div className="space-y-2">
                                <p className="text-sm font-semibold text-gray-700">🔗 Link anexado:</p>
                                <div className="p-3 bg-white rounded-lg">
                                  <p className="font-semibold text-purple-600 truncate">{linkTitle || linkUrl}</p>
                                  {linkDescription && (
                                    <p className="text-sm text-gray-600 mt-1">{linkDescription}</p>
                                  )}
                                  <p className="text-xs text-gray-400 mt-1 truncate">{linkUrl}</p>
                                </div>
                              </div>
                            )}
                          </div>
                        )}

                        {/* Link Form */}
                        <AnimatePresence>
                          {showLinkForm && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: "auto" }}
                              exit={{ opacity: 0, height: 0 }}
                              className="p-4 bg-purple-50 rounded-xl border-2 border-purple-200 space-y-3"
                            >
                              <div className="flex items-center justify-between mb-2">
                                <h4 className="font-bold text-gray-900">Adicionar Link</h4>
                                <button onClick={() => setShowLinkForm(false)} className="text-gray-500 hover:text-gray-700">
                                  <X className="w-5 h-5" />
                                </button>
                              </div>
                              
                              <div>
                                <Label className="text-sm font-semibold mb-1 block">URL *</Label>
                                <Input
                                  value={linkUrl}
                                  onChange={(e) => setLinkUrl(e.target.value)}
                                  placeholder="https://exemplo.com"
                                  className="border-2"
                                />
                              </div>

                              <div>
                                <Label className="text-sm font-semibold mb-1 block">Título (opcional)</Label>
                                <Input
                                  value={linkTitle}
                                  onChange={(e) => setLinkTitle(e.target.value)}
                                  placeholder="Título do link"
                                  className="border-2"
                                />
                              </div>

                              <div>
                                <Label className="text-sm font-semibold mb-1 block">Descrição (opcional)</Label>
                                <Textarea
                                  value={linkDescription}
                                  onChange={(e) => setLinkDescription(e.target.value)}
                                  placeholder="Breve descrição sobre o link"
                                  className="min-h-20 border-2"
                                />
                              </div>

                              <Button
                                onClick={handleAddLink}
                                disabled={!linkUrl.trim()}
                                className="w-full bg-gradient-to-r from-purple-500 to-blue-500"
                              >
                                Adicionar Link
                              </Button>
                            </motion.div>
                          )}
                        </AnimatePresence>
                        
                        {/* Visibility Selector */}
                        <div className="space-y-2">
                          <Label className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                            <Globe className="w-4 h-4" />
                            Visibilidade da Publicação
                          </Label>
                          <div className="grid grid-cols-2 gap-3">
                            <motion.div
                              whileHover={{ scale: 1.02 }}
                              whileTap={{ scale: 0.98 }}
                              onClick={() => setPostVisibility("local")}
                              className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                                postVisibility === "local"
                                  ? 'border-emerald-500 bg-emerald-50 shadow-lg'
                                  : 'border-gray-200 hover:border-emerald-300 bg-white'
                              }`}
                            >
                              <div className="flex items-center gap-3">
                                <div className={`p-2 rounded-lg ${
                                  postVisibility === "local" ? 'bg-emerald-500' : 'bg-gray-200'
                                }`}>
                                  <span className="text-2xl">🇧🇷</span>
                                </div>
                                <div className="flex-1">
                                  <h4 className="font-bold text-gray-900 text-sm">Nacional</h4>
                                  <p className="text-xs text-gray-600">Visível apenas no Brasil</p>
                                </div>
                                {postVisibility === "local" && (
                                  <CheckCircle className="w-5 h-5 text-emerald-600" />
                                )}
                              </div>
                            </motion.div>

                            <motion.div
                              whileHover={{ scale: 1.02 }}
                              whileTap={{ scale: 0.98 }}
                              onClick={() => setPostVisibility("international")}
                              className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                                postVisibility === "international"
                                  ? 'border-blue-500 bg-blue-50 shadow-lg'
                                  : 'border-gray-200 hover:border-blue-300 bg-white'
                              }`}
                            >
                              <div className="flex items-center gap-3">
                                <div className={`p-2 rounded-lg ${
                                  postVisibility === "international" ? 'bg-blue-500' : 'bg-gray-200'
                                }`}>
                                  <Globe className={`w-5 h-5 ${
                                    postVisibility === "international" ? 'text-white' : 'text-gray-400'
                                  }`} />
                                </div>
                                <div className="flex-1">
                                  <h4 className="font-bold text-gray-900 text-sm">Internacional</h4>
                                  <p className="text-xs text-gray-600">Visível globalmente</p>
                                </div>
                                {postVisibility === "international" && (
                                  <CheckCircle className="w-5 h-5 text-blue-600" />
                                )}
                              </div>
                            </motion.div>
                          </div>
                          <div className="flex items-start gap-2 p-3 bg-blue-50 rounded-lg border border-blue-200">
                            <Info className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                            <p className="text-xs text-blue-900">
                              <strong>Dica:</strong> Posts internacionais alcançam investidores de todo o mundo. 
                              Posts nacionais são ideais para projetos e parcerias locais.
                            </p>
                          </div>
                        </div>
                        
                        {/* Media Buttons */}
                        <div className="flex items-center justify-between">
                          <div className="flex gap-2">
                            {/* Hidden file inputs */}
                            <input
                              type="file"
                              accept="image/*"
                              onChange={(e) => handleFileUpload(e, 'photo')}
                              className="hidden"
                              id="photo-upload"
                              disabled={uploadingMedia || (mediaType !== 'none' && mediaType !== 'photo') || showLinkForm}
                            />
                            <input
                              type="file"
                              accept="video/*"
                              onChange={(e) => handleFileUpload(e, 'video')}
                              className="hidden"
                              id="video-upload"
                              disabled={uploadingMedia || (mediaType !== 'none' && mediaType !== 'video') || showLinkForm}
                            />

                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              className="gap-2 border-2 hover:border-emerald-400 hover:bg-emerald-50"
                              onClick={() => document.getElementById('photo-upload').click()}
                              disabled={uploadingMedia || (mediaType !== 'none' && mediaType !== 'photo') || showLinkForm}
                            >
                              {uploadingMedia && mediaType === 'photo' ? (
                                <Loader2 className="w-4 h-4 animate-spin" />
                              ) : (
                                <ImageIcon className="w-4 h-4" />
                              )}
                              Foto
                            </Button>

                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              className="gap-2 border-2 hover:border-blue-400 hover:bg-blue-50"
                              onClick={() => document.getElementById('video-upload').click()}
                              disabled={uploadingMedia || (mediaType !== 'none' && mediaType !== 'video') || showLinkForm}
                            >
                              {uploadingMedia && mediaType === 'video' ? (
                                <Loader2 className="w-4 h-4 animate-spin" />
                              ) : (
                                <Video className="w-4 h-4" />
                              )}
                              Vídeo
                            </Button>

                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              className="gap-2 border-2 hover:border-purple-400 hover:bg-purple-50"
                              onClick={() => setShowLinkForm(!showLinkForm)}
                              disabled={uploadingMedia || (mediaType !== 'none' && mediaType !== 'link')}
                            >
                              <LinkIcon className="w-4 h-4" />
                              Link
                            </Button>
                          </div>

                          <div className="flex gap-2">
                            <Button 
                              variant="outline" 
                              onClick={() => {
                                setShowCreatePost(false);
                                setNewPostContent("");
                                setEditingPost(null);
                                setPostVisibility("international");
                                clearMedia();
                              }}
                              className="border-2"
                            >
                              Cancelar
                            </Button>
                            <Button 
                              onClick={handleCreatePost}
                              disabled={!newPostContent.trim() || createPostMutation.isPending || updatePostMutation.isPending || uploadingMedia}
                              className="bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600 shadow-lg"
                            >
                              {uploadingMedia ? (
                                <>
                                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                  Enviando arquivo...
                                </>
                              ) : (createPostMutation.isPending || updatePostMutation.isPending) ? (
                                <>
                                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                  {editingPost ? "Atualizando..." : "Publicando..."}
                                </>
                              ) : (
                                <>
                                  <Send className="w-4 h-4 mr-2" />
                                  {editingPost ? "Atualizar" : "Publicar"}
                                </>
                              )}
                            </Button>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </>
              )}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mb-6"
        >
          <Card className="border-none shadow-lg bg-white">
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Input
                    placeholder="Buscar posts, pessoas ou hashtags..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 h-12 border-2 border-gray-200 focus:border-emerald-400 bg-white"
                  />
                </div>
                <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="w-full md:w-auto">
                  <TabsList className="bg-gradient-to-r from-emerald-100 to-blue-100 h-12">
                    <TabsTrigger value="all" className="data-[state=active]:bg-white">Todos</TabsTrigger>
                    <TabsTrigger value="tecnologico" className="data-[state=active]:bg-white">Tech</TabsTrigger>
                    <TabsTrigger value="cultural" className="data-[state=active]:bg-white">Cultural</TabsTrigger>
                    <TabsTrigger value="sustentabilidade" className="data-[state=active]:bg-white">Eco</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <div className="space-y-6">
          <AnimatePresence>
            {isLoading ? (
              <Card className="p-12 text-center bg-white">
                <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-4 border-emerald-600 mb-4" />
                <p className="text-gray-600 font-medium">Carregando posts...</p>
              </Card>
            ) : filteredPosts.length > 0 ? (
              filteredPosts.map((post) => (
                <PostCard
                  key={post.id}
                  post={post}
                  currentUser={user}
                  userLikes={userLikes}
                  comments={allComments}
                  onLike={handleLike}
                  onComment={handleComment}
                  onEdit={handleEdit}
                  onDelete={(postId) => deletePostMutation.mutate(postId)}
                />
              ))
            ) : (
              <Card className="p-16 text-center border-2 border-dashed border-emerald-300 bg-white">
                <Users className="w-20 h-20 text-emerald-400 mx-auto mb-4" />
                <h3 className="text-2xl font-semibold text-gray-900 mb-2">
                  Seja o primeiro!
                </h3>
                <p className="text-gray-600 mb-6">
                  Compartilhe algo com a comunidade
                </p>
                <Button 
                  onClick={() => setShowCreatePost(true)}
                  className="bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600 text-lg px-8 py-6"
                >
                  <Send className="w-5 h-5 mr-2" />
                  Criar Primeiro Post
                </Button>
              </Card>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
