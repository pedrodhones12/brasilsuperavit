import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Video,
  Users,
  Globe,
  Brain,
  Calendar,
  Clock,
  CheckCircle,
  Plus,
  X,
  Sparkles,
  Info
} from "lucide-react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

const languages = [
  { code: "pt", name: "Português 🇧🇷" },
  { code: "en", name: "English 🇺🇸" },
  { code: "es", name: "Español 🇪🇸" },
  { code: "fr", name: "Français 🇫🇷" },
  { code: "de", name: "Deutsch 🇩🇪" },
  { code: "it", name: "Italiano 🇮🇹" },
  { code: "zh", name: "中文 🇨🇳" },
  { code: "ja", name: "日本語 🇯🇵" },
  { code: "ar", name: "العربية 🇸🇦" }
];

const meetingTypes = [
  { value: "projeto", label: "💻 Reunião de Projeto", description: "Discutir progresso e próximos passos" },
  { value: "parceria", label: "🤝 Parceria e Investimento", description: "Negociar sociedades e investimentos" },
  { value: "mentoria", label: "🎓 Mentoria", description: "Sessão de orientação e aprendizado" },
  { value: "consultoria", label: "💡 Consultoria", description: "Consultoria técnica ou estratégica" },
  { value: "outro", label: "📋 Outro", description: "Reunião geral" }
];

const timezones = [
  "America/Sao_Paulo",
  "America/New_York",
  "Europe/London",
  "Europe/Paris",
  "Asia/Tokyo",
  "Asia/Shanghai"
];

export default function ScheduleMeeting() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [participantEmail, setParticipantEmail] = useState("");
  
  const [formData, setFormData] = useState({
    title: "",
    meeting_date: "",
    meeting_time: "",
    duration_minutes: 60,
    timezone: "America/Sao_Paulo",
    meeting_type: "projeto",
    primary_language: "pt",
    description: "",
    participants: [],
    translation_enabled: false,
    ai_notes_enabled: true,
    recording_enabled: false
  });

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  const createMeetingMutation = useMutation({
    mutationFn: async (meetingData) => {
      // Combine date and time
      const dateTime = `${meetingData.meeting_date}T${meetingData.meeting_time}:00`;
      
      const meeting = await base44.entities.Meeting.create({
        ...meetingData,
        meeting_date: dateTime,
        organizer_email: user.email,
        organizer_name: user.full_name,
        status: "agendada",
        meeting_link: `https://meet.jit.si/${Math.random().toString(36).substring(7)}`
      });

      return meeting;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['meetings'] });
      navigate(createPageUrl("Meetings"));
    },
  });

  const addParticipant = () => {
    if (participantEmail && !formData.participants.find(p => p.email === participantEmail)) {
      setFormData(prev => ({
        ...prev,
        participants: [...prev.participants, { email: participantEmail, confirmed: false }]
      }));
      setParticipantEmail("");
    }
  };

  const removeParticipant = (email) => {
    setFormData(prev => ({
      ...prev,
      participants: prev.participants.filter(p => p.email !== email)
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    createMeetingMutation.mutate(formData);
  };

  // Get minimum date (today)
  const today = new Date().toISOString().split('T')[0];

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-blue-50/30 via-purple-50/30 to-emerald-50/30">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500 via-purple-500 to-emerald-500 shadow-xl">
              <Video className="w-10 h-10 text-white" />
            </div>
            <div>
              <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-emerald-600 bg-clip-text text-transparent">
                Agendar Reunião
              </h1>
              <p className="text-xl text-gray-600 mt-1">
                Configure sua reunião inteligente com IA
              </p>
            </div>
          </div>
        </motion.div>

        <form onSubmit={handleSubmit}>
          <div className="space-y-6">
            {/* Basic Info */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Card className="border-none shadow-2xl">
                <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50">
                  <CardTitle className="flex items-center gap-3">
                    <Calendar className="w-6 h-6 text-blue-600" />
                    Informações Básicas
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="title">Título da Reunião *</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Ex: Discussão do Projeto Verde"
                      required
                      className="h-12"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="meeting_type">Tipo de Reunião *</Label>
                    <Select 
                      value={formData.meeting_type}
                      onValueChange={(value) => setFormData(prev => ({ ...prev, meeting_type: value }))}
                    >
                      <SelectTrigger className="h-12">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {meetingTypes.map(type => (
                          <SelectItem key={type.value} value={type.value}>
                            <div>
                              <div className="font-semibold">{type.label}</div>
                              <div className="text-xs text-gray-500">{type.description}</div>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="meeting_date">Data *</Label>
                      <Input
                        id="meeting_date"
                        type="date"
                        min={today}
                        value={formData.meeting_date}
                        onChange={(e) => setFormData(prev => ({ ...prev, meeting_date: e.target.value }))}
                        required
                        className="h-12"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="meeting_time">Hora *</Label>
                      <Input
                        id="meeting_time"
                        type="time"
                        value={formData.meeting_time}
                        onChange={(e) => setFormData(prev => ({ ...prev, meeting_time: e.target.value }))}
                        required
                        className="h-12"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="duration">Duração (min)</Label>
                      <Select 
                        value={formData.duration_minutes.toString()}
                        onValueChange={(value) => setFormData(prev => ({ ...prev, duration_minutes: parseInt(value) }))}
                      >
                        <SelectTrigger className="h-12">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="30">30 minutos</SelectItem>
                          <SelectItem value="60">1 hora</SelectItem>
                          <SelectItem value="90">1h 30min</SelectItem>
                          <SelectItem value="120">2 horas</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Agenda / Descrição</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Descreva os objetivos da reunião..."
                      className="min-h-24"
                    />
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Participants */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <Card className="border-none shadow-2xl">
                <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
                  <CardTitle className="flex items-center gap-3">
                    <Users className="w-6 h-6 text-purple-600" />
                    Participantes
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                  <div className="flex gap-2">
                    <Input
                      type="email"
                      value={participantEmail}
                      onChange={(e) => setParticipantEmail(e.target.value)}
                      placeholder="Email do participante"
                      onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addParticipant())}
                      className="flex-1"
                    />
                    <Button type="button" onClick={addParticipant} variant="outline">
                      <Plus className="w-4 h-4 mr-2" />
                      Adicionar
                    </Button>
                  </div>

                  {formData.participants.length > 0 && (
                    <div className="space-y-2">
                      {formData.participants.map((participant, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <span className="text-sm font-medium text-gray-900">{participant.email}</span>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeParticipant(participant.email)}
                          >
                            <X className="w-4 h-4 text-red-500" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Language & Timezone */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <Card className="border-none shadow-2xl">
                <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                  <CardTitle className="flex items-center gap-3">
                    <Globe className="w-6 h-6 text-emerald-600" />
                    Configurações Globais
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label>Idioma Principal</Label>
                      <Select 
                        value={formData.primary_language}
                        onValueChange={(value) => setFormData(prev => ({ ...prev, primary_language: value }))}
                      >
                        <SelectTrigger className="h-12">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {languages.map(lang => (
                            <SelectItem key={lang.code} value={lang.code}>
                              {lang.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Fuso Horário</Label>
                      <Select 
                        value={formData.timezone}
                        onValueChange={(value) => setFormData(prev => ({ ...prev, timezone: value }))}
                      >
                        <SelectTrigger className="h-12">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {timezones.map(tz => (
                            <SelectItem key={tz} value={tz}>
                              {tz.replace(/_/g, ' ')}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* AI Features */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <Card className="border-none shadow-2xl overflow-hidden">
                <div className="h-2 bg-gradient-to-r from-purple-500 via-blue-500 to-emerald-500" />
                <CardHeader className="bg-gradient-to-r from-purple-50 to-emerald-50">
                  <CardTitle className="flex items-center gap-3">
                    <Sparkles className="w-6 h-6 text-purple-600" />
                    Recursos de Inteligência Artificial
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-6">
                  <Alert className="border-blue-200 bg-blue-50">
                    <Info className="h-4 w-4 text-blue-600" />
                    <AlertDescription className="text-blue-900">
                      A IA auxilia, mas você tem controle total. Escolha quais recursos ativar.
                    </AlertDescription>
                  </Alert>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-white rounded-xl border-2 border-gray-200 hover:border-purple-400 transition-all">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Globe className="w-5 h-5 text-blue-600" />
                          <h4 className="font-semibold text-gray-900">Tradução em Tempo Real</h4>
                        </div>
                        <p className="text-sm text-gray-600">Traduza automaticamente entre idiomas durante a chamada</p>
                      </div>
                      <Switch
                        checked={formData.translation_enabled}
                        onCheckedChange={(checked) => setFormData(prev => ({ ...prev, translation_enabled: checked }))}
                      />
                    </div>

                    <div className="flex items-center justify-between p-4 bg-white rounded-xl border-2 border-emerald-200 hover:border-emerald-400 transition-all">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Brain className="w-5 h-5 text-emerald-600" />
                          <h4 className="font-semibold text-gray-900">Anotações Automáticas</h4>
                          <Badge className="bg-emerald-100 text-emerald-800 text-xs">Recomendado</Badge>
                        </div>
                        <p className="text-sm text-gray-600">A IA transcreve, resume e identifica tarefas automaticamente</p>
                      </div>
                      <Switch
                        checked={formData.ai_notes_enabled}
                        onCheckedChange={(checked) => setFormData(prev => ({ ...prev, ai_notes_enabled: checked }))}
                      />
                    </div>

                    <div className="flex items-center justify-between p-4 bg-white rounded-xl border-2 border-gray-200 hover:border-purple-400 transition-all">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Video className="w-5 h-5 text-purple-600" />
                          <h4 className="font-semibold text-gray-900">Gravar Reunião</h4>
                        </div>
                        <p className="text-sm text-gray-600">Grave a reunião para consulta futura (requer consentimento)</p>
                      </div>
                      <Switch
                        checked={formData.recording_enabled}
                        onCheckedChange={(checked) => setFormData(prev => ({ ...prev, recording_enabled: checked }))}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Submit */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="flex gap-4"
            >
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate(createPageUrl("Meetings"))}
                className="flex-1 h-14 text-lg"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                disabled={createMeetingMutation.isPending || !formData.title || !formData.meeting_date || !formData.meeting_time}
                className="flex-1 h-14 text-lg bg-gradient-to-r from-blue-500 via-purple-500 to-emerald-500 hover:from-blue-600 hover:via-purple-600 hover:to-emerald-600 shadow-lg"
              >
                {createMeetingMutation.isPending ? (
                  "Agendando..."
                ) : (
                  <>
                    <CheckCircle className="w-5 h-5 mr-2" />
                    Agendar Reunião
                  </>
                )}
              </Button>
            </motion.div>
          </div>
        </form>
      </div>
    </div>
  );
}