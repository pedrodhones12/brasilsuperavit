import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Handshake,
  Users,
  TrendingUp,
  Lightbulb,
  Globe,
  Heart,
  MessageCircle,
  Share2,
  FileText,
  Shield,
  Rocket,
  Target,
  CheckCircle,
  DollarSign,
  Award,
  Zap,
  BarChart3,
  Sparkles
} from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const partnershipTypes = [
  {
    title: "Investimento Conjunto",
    description: "Duas ou mais pessoas investem em um mesmo projeto com retorno proporcional ao aporte.",
    example: "Cinco investidores aplicam R$ 10.000 cada em um aplicativo de entrega local.",
    icon: DollarSign,
    color: "from-emerald-500 to-emerald-600"
  },
  {
    title: "Sociedade Criativa",
    description: "Parceria entre pessoas com talentos complementares (design, programação, marketing).",
    example: "Um designer, um programador e um economista criam um app de gestão financeira.",
    icon: Lightbulb,
    color: "from-purple-500 to-purple-600"
  },
  {
    title: "Parceria de Cidades",
    description: "Prefeituras, empresas e cidadãos se unem em um projeto urbano.",
    example: "Construção de uma ciclovia inteligente em parceria público-privada.",
    icon: Globe,
    color: "from-blue-500 to-blue-600"
  },
  {
    title: "Apoio Cultural",
    description: "Investidores apoiam artistas e projetos culturais com retorno simbólico ou percentual de lucro.",
    example: "Criação de um festival cultural sustentável apoiado por marcas locais.",
    icon: Award,
    color: "from-pink-500 to-pink-600"
  },
  {
    title: "Startup Comunitária",
    description: "Microempreendedores locais se unem para desenvolver produtos e dividir lucros.",
    example: "Pequenos produtores criam uma cooperativa digital de venda direta.",
    icon: Rocket,
    color: "from-orange-500 to-orange-600"
  }
];

const investmentTiers = [
  { amount: 5000, label: "Semente", color: "from-yellow-500 to-yellow-600", icon: "🌱" },
  { amount: 10000, label: "Crescimento", color: "from-blue-500 to-blue-600", icon: "🌿" },
  { amount: 15000, label: "Premium", color: "from-purple-500 to-purple-600", icon: "🌳" }
];

const steps = [
  {
    number: 1,
    title: "Criação do Projeto",
    description: "O empreendedor cadastra o projeto (app, produto, serviço sustentável)",
    icon: Rocket
  },
  {
    number: 2,
    title: "Abertura para Parcerias",
    description: "Define valor, quantidade de sócios e percentual de lucro",
    icon: Users
  },
  {
    number: 3,
    title: "Divulgação no Feed",
    description: "O projeto aparece no feed onde interessados podem curtir, comentar e enviar proposta",
    icon: MessageCircle
  },
  {
    number: 4,
    title: "Formação do Grupo",
    description: "Interessados confirmam investimento → contrato é gerado → parceria oficializada",
    icon: FileText
  },
  {
    number: 5,
    title: "Acompanhamento",
    description: "Cada sócio acompanha desempenho e resultados no painel compartilhado",
    icon: BarChart3
  }
];

const projectExamples = [
  {
    title: "Startup Verde (Tecnologia Sustentável)",
    investment: 50000,
    partners: 5,
    perPartner: 10000,
    description: "Aplicativo que conecta cooperativas de reciclagem com empresas de logística reversa.",
    profit: "40% do valor dos contratos firmados dividido entre os sócios",
    icon: "♻️",
    color: "from-emerald-500 to-emerald-600"
  },
  {
    title: "Plataforma de Turismo Inteligente",
    investment: 75000,
    partners: 3,
    perPartner: 25000,
    description: "Site e app que divulgam destinos de ecoturismo no litoral da Bahia com roteiros personalizados.",
    profit: "Retorno financeiro + incentivo fiscal de turismo regional",
    icon: "🏖️",
    color: "from-blue-500 to-blue-600"
  },
  {
    title: "Moda e Sustentabilidade",
    investment: 30000,
    partners: 4,
    perPartner: 7500,
    description: "Criação de uma linha de roupas feitas com tecidos reciclados e vendas via e-commerce colaborativo.",
    profit: "Lucro dividido em 25% para cada um",
    icon: "👗",
    color: "from-pink-500 to-pink-600"
  },
  {
    title: "Estúdio de Jogos Educacionais",
    investment: 60000,
    partners: 5,
    perPartner: 12000,
    description: "Desenvolvimento de jogos educativos sobre finanças e meio ambiente.",
    profit: "Royalties sobre vendas e licenciamento em escolas",
    icon: "🎮",
    color: "from-purple-500 to-purple-600"
  },
  {
    title: "Projeto de Energia Solar Comunitária",
    investment: 120000,
    partners: 5,
    perPartner: 24000,
    description: "Implantação de painéis solares em bairros carentes.",
    profit: "Redução de custos de energia e retorno sobre economia gerada",
    icon: "☀️",
    color: "from-yellow-500 to-yellow-600"
  }
];

const benefits = [
  { icon: Shield, text: "Redução de risco (investimento dividido)" },
  { icon: Lightbulb, text: "Acesso a novas ideias e contatos" },
  { icon: Globe, text: "Possibilidade de internacionalização de negócios" },
  { icon: BarChart3, text: "Transparência e acompanhamento em tempo real" },
  { icon: TrendingUp, text: "Incentivo ao desenvolvimento local e sustentável" },
  { icon: Users, text: "Networking com empreendedores e investidores" }
];

export default function PartnershipsInfo() {
  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-blue-50/30 via-purple-50/30 to-emerald-50/30">
      <div className="max-w-7xl mx-auto">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12 text-center"
        >
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 via-purple-500 to-emerald-500 mb-6 shadow-2xl">
            <Handshake className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-blue-600 via-purple-600 to-emerald-600 bg-clip-text text-transparent">
            Parcerias e Investimentos Conjuntos
          </h1>
          <p className="text-2xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            A colaboração é a nova moeda. Conecte-se com talentos, recursos e propósitos para transformar cidades em polos de inovação sustentável.
          </p>
        </motion.div>

        {/* Context Section */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mb-16"
        >
          <Card className="border-none shadow-2xl overflow-hidden">
            <div className="h-2 bg-gradient-to-r from-blue-500 via-purple-500 to-emerald-500" />
            <CardContent className="p-8 md:p-12">
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div>
                  <h2 className="text-3xl font-bold text-gray-900 mb-4 flex items-center gap-3">
                    <Globe className="w-8 h-8 text-blue-600" />
                    Contexto
                  </h2>
                  <p className="text-lg text-gray-700 leading-relaxed mb-4">
                    Vivemos uma era em que <strong>a colaboração é a nova moeda</strong>. Nenhum projeto cresce sozinho — e a força de uma cidade ou comunidade está na união de talentos, recursos e propósitos.
                  </p>
                  <p className="text-lg text-gray-700 leading-relaxed">
                    O módulo de <strong>Parcerias e Investimentos Conjuntos</strong> permite que empreendedores, investidores e cidadãos formem alianças estratégicas, compartilhem lucros, ideias e responsabilidades.
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-6 rounded-xl bg-gradient-to-br from-emerald-50 to-emerald-100 border border-emerald-200">
                    <DollarSign className="w-10 h-10 text-emerald-600 mb-2" />
                    <p className="font-bold text-gray-900">Investidores</p>
                    <p className="text-sm text-gray-600">trazem capital</p>
                  </div>
                  <div className="p-6 rounded-xl bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200">
                    <Lightbulb className="w-10 h-10 text-blue-600 mb-2" />
                    <p className="font-bold text-gray-900">Empreendedores</p>
                    <p className="text-sm text-gray-600">trazem ideias</p>
                  </div>
                  <div className="p-6 rounded-xl bg-gradient-to-br from-purple-50 to-purple-100 border border-purple-200">
                    <Zap className="w-10 h-10 text-purple-600 mb-2" />
                    <p className="font-bold text-gray-900">Profissionais</p>
                    <p className="text-sm text-gray-600">trazem expertise</p>
                  </div>
                  <div className="p-6 rounded-xl bg-gradient-to-br from-pink-50 to-pink-100 border border-pink-200">
                    <Heart className="w-10 h-10 text-pink-600 mb-2" />
                    <p className="font-bold text-gray-900">Cidadãos</p>
                    <p className="text-sm text-gray-600">trazem propósito</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Partnership Types */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="mb-16"
        >
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Formas de Parcerias</h2>
            <p className="text-xl text-gray-600">Diversos formatos dependendo da natureza do projeto</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {partnershipTypes.map((type, index) => {
              const Icon = type.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                  whileHover={{ y: -8 }}
                >
                  <Card className="border-none shadow-xl h-full hover:shadow-2xl transition-all duration-300">
                    <CardHeader className={`bg-gradient-to-r ${type.color} text-white`}>
                      <CardTitle className="flex items-center gap-3">
                        <Icon className="w-6 h-6" />
                        {type.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-6">
                      <p className="text-gray-700 mb-4">{type.description}</p>
                      <Alert className="border-gray-200 bg-gray-50">
                        <Sparkles className="h-4 w-4 text-yellow-500" />
                        <AlertDescription className="text-sm text-gray-700">
                          <strong>Exemplo:</strong> {type.example}
                        </AlertDescription>
                      </Alert>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Investment Tiers */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mb-16"
        >
          <Card className="border-none shadow-2xl">
            <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
              <CardTitle className="text-3xl flex items-center gap-3">
                <Target className="w-8 h-8 text-emerald-600" />
                Estrutura de Investimento
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8">
              <div className="grid md:grid-cols-3 gap-6 mb-8">
                {investmentTiers.map((tier, index) => (
                  <div
                    key={index}
                    className="p-8 rounded-2xl bg-white border-2 border-gray-200 hover:border-emerald-400 transition-all duration-300 text-center"
                  >
                    <div className="text-5xl mb-4">{tier.icon}</div>
                    <div className={`inline-block px-4 py-2 rounded-lg bg-gradient-to-r ${tier.color} text-white font-bold text-lg mb-3`}>
                      {tier.label}
                    </div>
                    <p className="text-3xl font-bold text-gray-900">
                      R$ {tier.amount.toLocaleString('pt-BR')}
                    </p>
                    <p className="text-sm text-gray-500 mt-2">investimento mínimo</p>
                  </div>
                ))}
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="p-6 bg-blue-50 rounded-xl border border-blue-200">
                  <h4 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                    <Users className="w-5 h-5 text-blue-600" />
                    Número de Sócios
                  </h4>
                  <p className="text-gray-700">De 2 a 5 sócios principais (expansível para cotistas adicionais)</p>
                </div>
                <div className="p-6 bg-purple-50 rounded-xl border border-purple-200">
                  <h4 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                    <FileText className="w-5 h-5 text-purple-600" />
                    Contrato Digital
                  </h4>
                  <p className="text-gray-700">Assinado eletronicamente com percentual de participação automático</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Steps */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="mb-16"
        >
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Como Criar uma Parceria</h2>
            <p className="text-xl text-gray-600">5 etapas simples para formar sua sociedade</p>
          </div>
          <div className="space-y-6">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.8 + index * 0.1 }}
                >
                  <Card className="border-none shadow-xl hover:shadow-2xl transition-all duration-300">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-6">
                        <div className="flex-shrink-0">
                          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-emerald-500 to-blue-500 flex items-center justify-center text-white text-2xl font-bold shadow-lg">
                            {step.number}
                          </div>
                        </div>
                        <div className="flex-1">
                          <h3 className="text-2xl font-bold text-gray-900 mb-2 flex items-center gap-3">
                            <Icon className="w-6 h-6 text-blue-600" />
                            {step.title}
                          </h3>
                          <p className="text-lg text-gray-700">{step.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Project Examples */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="mb-16"
        >
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Exemplos de Projetos</h2>
            <p className="text-xl text-gray-600">Ideias reais de parcerias bem-sucedidas</p>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            {projectExamples.map((project, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 1.1 + index * 0.1 }}
                whileHover={{ scale: 1.02 }}
              >
                <Card className="border-none shadow-xl h-full hover:shadow-2xl transition-all duration-300">
                  <div className={`h-2 bg-gradient-to-r ${project.color}`} />
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center gap-3 text-xl">
                      <span className="text-3xl">{project.icon}</span>
                      {project.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6 space-y-4">
                    <p className="text-gray-700">{project.description}</p>
                    
                    <div className="grid grid-cols-3 gap-4">
                      <div className="p-3 bg-gray-50 rounded-lg text-center">
                        <p className="text-xs text-gray-500 mb-1">Investimento</p>
                        <p className="font-bold text-gray-900">R$ {project.investment.toLocaleString('pt-BR')}</p>
                      </div>
                      <div className="p-3 bg-gray-50 rounded-lg text-center">
                        <p className="text-xs text-gray-500 mb-1">Sócios</p>
                        <p className="font-bold text-gray-900">{project.partners}</p>
                      </div>
                      <div className="p-3 bg-gray-50 rounded-lg text-center">
                        <p className="text-xs text-gray-500 mb-1">Por Sócio</p>
                        <p className="font-bold text-gray-900">R$ {project.perPartner.toLocaleString('pt-BR')}</p>
                      </div>
                    </div>

                    <Alert className="border-emerald-200 bg-emerald-50">
                      <TrendingUp className="h-4 w-4 text-emerald-600" />
                      <AlertDescription className="text-sm text-emerald-900">
                        <strong>Retorno:</strong> {project.profit}
                      </AlertDescription>
                    </Alert>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Benefits */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.3 }}
          className="mb-16"
        >
          <Card className="border-none shadow-2xl overflow-hidden">
            <div className="h-2 bg-gradient-to-r from-emerald-500 via-blue-500 to-purple-500" />
            <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
              <CardTitle className="text-3xl flex items-center gap-3">
                <Award className="w-8 h-8 text-emerald-600" />
                Benefícios das Parcerias
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {benefits.map((benefit, index) => {
                  const Icon = benefit.icon;
                  return (
                    <div
                      key={index}
                      className="flex items-start gap-4 p-4 rounded-xl bg-gradient-to-r from-gray-50 to-blue-50/50 border border-gray-200 hover:border-emerald-400 transition-all duration-300"
                    >
                      <div className="p-2 rounded-lg bg-gradient-to-br from-emerald-500 to-blue-500">
                        <Icon className="w-5 h-5 text-white" />
                      </div>
                      <p className="text-gray-700 font-medium">{benefit.text}</p>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.4 }}
          className="text-center"
        >
          <Card className="border-none shadow-2xl overflow-hidden">
            <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-emerald-600 p-12 text-white">
              <h2 className="text-4xl font-bold mb-4">Pronto para Formar sua Parceria?</h2>
              <p className="text-xl mb-8 text-white/90">
                Explore projetos disponíveis ou crie o seu próprio
              </p>
              <div className="flex flex-wrap gap-4 justify-center">
                <Link to={createPageUrl("Partnerships")}>
                  <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-6 text-lg">
                    <Handshake className="w-6 h-6 mr-2" />
                    Ver Minhas Parcerias
                  </Button>
                </Link>
                <Link to={createPageUrl("Projects")}>
                  <Button size="lg" variant="outline" className="bg-transparent border-2 border-white text-white hover:bg-white/10 px-8 py-6 text-lg">
                    <Rocket className="w-6 h-6 mr-2" />
                    Explorar Projetos
                  </Button>
                </Link>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}