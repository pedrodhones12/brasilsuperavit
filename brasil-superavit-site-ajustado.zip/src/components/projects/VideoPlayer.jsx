import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Play, Video as VideoIcon } from "lucide-react";
import { motion } from "framer-motion";

export default function VideoPlayer({ videoUrl, title = "Project Video" }) {
  const [isPlaying, setIsPlaying] = useState(false);

  if (!videoUrl) return null;

  // Extract video ID and platform
  const getVideoEmbed = (url) => {
    // YouTube
    const youtubeMatch = url.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/);
    if (youtubeMatch) {
      return {
        platform: 'youtube',
        embedUrl: `https://www.youtube.com/embed/${youtubeMatch[1]}?autoplay=1&rel=0`,
        thumbnailUrl: `https://img.youtube.com/vi/${youtubeMatch[1]}/maxresdefault.jpg`
      };
    }

    // Vimeo
    const vimeoMatch = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
    if (vimeoMatch) {
      return {
        platform: 'vimeo',
        embedUrl: `https://player.vimeo.com/video/${vimeoMatch[1]}?autoplay=1`,
        thumbnailUrl: null
      };
    }

    // Direct video URL
    if (url.match(/\.(mp4|webm|ogg)$/i)) {
      return {
        platform: 'direct',
        embedUrl: url,
        thumbnailUrl: null
      };
    }

    return null;
  };

  const videoData = getVideoEmbed(videoUrl);

  if (!videoData) {
    return (
      <Card className="p-6 bg-gray-50">
        <div className="flex items-center gap-3 text-gray-500">
          <VideoIcon className="w-5 h-5" />
          <span className="text-sm">Formato de vídeo não suportado</span>
        </div>
      </Card>
    );
  }

  if (!isPlaying && videoData.thumbnailUrl) {
    return (
      <motion.div
        whileHover={{ scale: 1.02 }}
        transition={{ duration: 0.2 }}
        className="relative aspect-video rounded-xl overflow-hidden cursor-pointer group"
        onClick={() => setIsPlaying(true)}
      >
        <img
          src={videoData.thumbnailUrl}
          alt={title}
          className="w-full h-full object-cover"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-black/40 group-hover:bg-black/50 transition-colors flex items-center justify-center">
          <motion.div
            whileHover={{ scale: 1.1 }}
            className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-2xl"
          >
            <Play className="w-10 h-10 text-emerald-600 ml-1" fill="currentColor" />
          </motion.div>
        </div>
        <div className="absolute bottom-4 left-4 right-4">
          <div className="bg-black/70 backdrop-blur-sm px-4 py-2 rounded-lg">
            <p className="text-white font-semibold text-sm line-clamp-1">{title}</p>
            <p className="text-white/80 text-xs mt-1">Clique para assistir o vídeo pitch</p>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="relative aspect-video rounded-xl overflow-hidden bg-black">
      {videoData.platform === 'direct' ? (
        <video
          src={videoData.embedUrl}
          controls
          autoPlay
          className="w-full h-full"
          title={title}
        >
          Seu navegador não suporta a tag de vídeo.
        </video>
      ) : (
        <iframe
          src={videoData.embedUrl}
          title={title}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          className="w-full h-full"
        />
      )}
    </div>
  );
}